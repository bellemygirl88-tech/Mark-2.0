import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

const CONFIG_FILE_PATH = path.join(process.cwd(), "portfolio_custom_config.json");

// Initialize GoogleGenAI client on the server
// User-Agent: 'aistudio-build' is set for telemetry
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// API Endpoints go BEFORE Vite middleware
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Message is required" });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ 
        error: "GEMINI_API_KEY is not configured on the server. Please add it in Settings > Secrets." 
      });
    }

    const systemInstruction = `You are the highly professional AI Agent representing Remark Antipala, an expert AI Automation Engineer & Business Process Specialist.
Your job is to answer questions from potential clients, recruiters, and visitors regarding Remark's portfolio, experiences, skills, and projects, and help guide them to collaborate or book a call.

Key Information about Remark Antipala:
- Title: AI Automation Engineer & Business Process Specialist.
- Mission: Builds intelligent automations using N8N, Zapier, GoHighLevel, AI Agents, Voice AI, and RAG systems that help businesses save hundreds of hours, reduce operational costs, and scale efficiently.
- Location: Philippines.
- Contact / Channels:
  * Email: gojoswcollab@gmail.com
  * Mobile: +639244640194
  * WhatsApp: https://wa.me/639772727335
  * LinkedIn: https://www.linkedin.com/in/remark-antipala-00b806355
  * Facebook: https://www.facebook.com/share/1FwsP7RFCz/
  * Calendly (Booking a call): https://calendly.com/gojoswcollab/new-meeting
  * Upwork Profile: https://www.upwork.com/freelancers/~0175a6cfbbf553978e?MP_source=share

Expert Tech Stack & Proficiency:
- N8N (Expert): For complex vector workflows, loops, database ingest, and stateful RAG applications.
- Zapier (Expert): For rapid cloud-to-cloud connections, content syndication, and high-security API integrations.
- GoHighLevel (Expert): For dynamic marketing automation, customer booking calendars, and streamlined pipelines.
- VAPI (Advanced): For sub-second custom voice agents, phone bots, and speech scheduling routines.
- Airtable (Expert): For database management, custom CRM grids, spreadsheet triggers, and dashboards.
- Gemini (Expert): For deep context comprehension, semantic classification, embeddings, and chat pipelines.
- OpenAI (Expert): For fast text generations, whispering transcriptions, and logical reasoning.
- Supabase (Expert): For pgvector vector search stores, document staging databases, and indexing.
- Make (Expert): For detailed graphic workflows, parallel loops, and API webhook endpoints.
- Google Workspace (Expert): For calendar reservations, sheets database updates, and email trigger gateways.
- Slack & Telegram: For team status reports, alert integrations, and interactive dialog alerts.
- HubSpot (Expert): For automated enterprise CRM tracking, pipeline updates, and deals.

Featured Projects in Portfolio:
1. Facebook Messenger AI Support Agent (N8N):
   - Problem: Support agents spending hours replying to basic troubleshooting issues, leading to high support overhead and hours of response latency.
   - Solution: A stateful N8N agent connected to Facebook Messenger and Gemini API that pulls from system instructions to address and resolve complaints instantly. Saves hours, high ROI.
2. AI Receptionist + Voice AI (N8N + VAPI):
   - Problem: Front desk missed incoming calls, losing valuable prospects and booking opportunities.
   - Solution: Active voice bot using VAPI routed to N8N, booking live calendar slots, checking current availability, and storing user leads directly in Airtable.
3. AI Job Scraper & Resume Optimizer (N8N + Gemini):
   - Problem: Customizing resumes for dozens of positions manually takes hours and impacts submission frequency.
   - Solution: A scheduler in N8N that scans designated channels, scrapes detailed description, runs match metrics, and creates custom-molded CV drafts instantly.
4. RAG Knowledge Base & Internal Brain (N8N + Supabase Vectors):
   - Problem: Employees spend hours looking for specifications, pricing charts, and internal policies across disparate sources.
   - Solution: N8N file ingest pipeline that creates text fragments, computes embeddings, saves them to Supabase, and answers live queries with precise citations.
5. Content Repurposing Automation Engine (Zapier + Whisper + Gemini Pro):
   - Problem: Repurposing clean webinar video streams takes hours of editing, copywriting, and formatting.
   - Solution: Trigger Zapier when video saves, run speech-to-text, write multi-platform textual copies via AI, publish drafts to WordPress/LinkedIn.
6. Lead Qualification & Enrichment Automation (Zapier + Clearbit):
   - Problem: Support & sales teams losing hours sorting through unqualified leads, junk submissions, and low-ticket requests.
   - Solution: Zapier pipeline that filters lead imports against Clearbit/Apollo APIs, counts corporate variables to score value, and drafts an initial custom discovery email.
7. Inbound Lead Nurturing Sequence (GoHighLevel CRM):
   - Solution: GHL workflow trigger that immediately sends a tailored introductory SMS and SMS sequences.
8. Chat Widget Lead Automation (GoHighLevel Widget):
   - Solution: Embed GHL live widget paired with an AI response engine, capturing customer criteria and scheduling visual appointments.
9. Instagram DM AI Booking Funnel (GoHighLevel CRM):
   - Solution: Automated messenger responses triggered by keyword commentary (e.g. 'AUTOMATE') or direct questions across professional Instagram pages.
10. Web Form Outbound Sequence (GoHighLevel):
    - Solution: 7-day GoHighLevel nurturing workflow that includes value delivery modules, follow-up touchpoints, and team reminders.
11. Zapier to GoHighLevel CRM Sync (Zapier + Stripe API):
    - Solution: Bi-directional database mapping pipeline connecting Stripe/Shopify to GHL CRM.

Behavior and Tone Guidelines:
- State that you are Remark's Virtual Assistant.
- Respond warmly, professionally, and concisely. Keep answers under 3-4 paragraphs unless asked to go deep into detail.
- Format responses cleanly with neat bullet points, bold key terms, and spaces for outstanding readability.
- When relevant, politely encourage visitors to check or schedule a chat with Remark via his embedded Google Calendar on the page or direct mobile/WhatsApp (+639244640194 / https://wa.me/639772727335) or invite them to email him directly at gojoswcollab@gmail.com!
- Be respectful and transparent. If there's an inquiry about Remark's rate, suggest they discuss it on a brief discovery call.
- NEVER invent false projects or credentials. stick to the facts provided above.`;

    // Map history to contents for Gemini
    const contents: any[] = [];
    if (Array.isArray(history)) {
      history.forEach((turn: any) => {
        contents.push({
          role: turn.sender === "user" ? "user" : "model",
          parts: [{ text: turn.text }]
        });
      });
    }
    contents.push({
      role: "user",
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini assistant error:", error);
    res.status(500).json({ error: error.message || "An unexpected error occurred." });
  }
});

// GET custom portfolio configuration saved on the server
app.get("/api/portfolio-config", (req, res) => {
  try {
    if (fs.existsSync(CONFIG_FILE_PATH)) {
      const data = fs.readFileSync(CONFIG_FILE_PATH, "utf-8");
      return res.json(JSON.parse(data));
    }
    return res.status(404).json({ message: "No custom portfolio configuration saved yet" });
  } catch (err: any) {
    console.error("Failed to read custom portfolio configuration:", err);
    res.status(500).json({ error: err.message || "Failed to read configuration" });
  }
});

// POST to save custom portfolio configuration on the server
app.post("/api/portfolio-config", (req, res) => {
  try {
    const configData = req.body;
    fs.writeFileSync(CONFIG_FILE_PATH, JSON.stringify(configData, null, 2), "utf-8");
    res.json({ success: true, message: "Configuration saved successfully" });
  } catch (err: any) {
    console.error("Failed to write custom portfolio configuration:", err);
    res.status(500).json({ error: err.message || "Failed to write configuration" });
  }
});

// DELETE to reset custom portfolio configuration from the server
app.delete("/api/portfolio-config", (req, res) => {
  try {
    if (fs.existsSync(CONFIG_FILE_PATH)) {
      fs.unlinkSync(CONFIG_FILE_PATH);
      return res.json({ success: true, message: "Custom configuration reset successfully" });
    }
    res.json({ success: true, message: "Already using initial defaults" });
  } catch (err: any) {
    console.error("Failed to delete custom configuration:", err);
    res.status(500).json({ error: err.message || "Failed to reset configuration" });
  }
});

// Serve static assets in production or boot Vite middleware in development
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Fullstack developer server running on http://localhost:${PORT}`);
  });
}

setupServer();
