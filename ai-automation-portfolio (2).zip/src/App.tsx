import React, { useState, useEffect } from 'react';
import { 
  INITIAL_PROFILE, INITIAL_CONTACT, INITIAL_PROJECTS 
} from './data/portfolioData';
import { Project, ContactInfo, UserProfile } from './types';

// Component imports
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import ProjectsTabs from './components/ProjectsTabs';
import VideoGallery from './components/VideoGallery';
import Results from './components/Results';
import TechStack from './components/TechStack';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import CustomizerDrawer from './components/CustomizerDrawer';
import ResumeModal from './components/ResumeModal';
import AIChatWidget from './components/AIChatWidget';
import CalendlyEmbed from './components/CalendlyEmbed';
import { Sliders, Sparkles, X, Pin } from 'lucide-react';

export default function App() {
  const [isLoadedFromServer, setIsLoadedFromServer] = useState(false);

  // 1. Core States
  const [isDark, setIsDark] = useState<boolean>(() => {
    const saved = localStorage.getItem('portfolio-dark-theme');
    return saved !== null ? saved === 'true' : true; // Default to eye-safe dark theme
  });

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [hourlyRate, setHourlyRate] = useState<number>(() => {
    const saved = localStorage.getItem('portfolio-hourly-rate');
    return saved !== null ? Number(saved) : 35; // Default rate
  });

  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('portfolio-profile');
    return saved !== null ? JSON.parse(saved) : INITIAL_PROFILE;
  });

  const [contact, setContact] = useState<ContactInfo>(() => {
    const saved = localStorage.getItem('portfolio-contact');
    return saved !== null ? JSON.parse(saved) : INITIAL_CONTACT;
  });

  const [projects, setProjects] = useState<Project[]>(() => {
    const saved = localStorage.getItem('portfolio-projects');
    return saved !== null ? JSON.parse(saved) : INITIAL_PROJECTS;
  });

  const [hasCustomizations, setHasCustomizations] = useState(false);

  // 1.5 Live Pinterest Background Wallpaper States
  const [showWallpaper, setShowWallpaper] = useState<boolean>(() => {
    const saved = localStorage.getItem('portfolio-show-wallpaper');
    return saved !== null ? saved === 'true' : true; 
  });

  const [bgStreamPinned, setBgStreamPinned] = useState<boolean>(() => {
    const saved = localStorage.getItem('portfolio-wallpaper-pinned');
    return saved !== null ? saved === 'true' : true; // Default pinned as ambient page background
  });

  const [wallpaperOpacity, setWallpaperOpacity] = useState<number>(() => {
    const saved = localStorage.getItem('portfolio-wallpaper-opacity');
    return saved !== null ? Number(saved) : 0.35; // Soft default opacity
  });

  const [wallpaperType, setWallpaperType] = useState<'video' | 'pinterest'>(() => {
    const saved = localStorage.getItem('portfolio-wallpaper-type');
    return saved !== null ? (saved as 'video' | 'pinterest') : 'pinterest'; // Default directly to Pinterest Pin
  });

  const [wallpaperVideoUrl, setWallpaperVideoUrl] = useState<string>(() => {
    const saved = localStorage.getItem('portfolio-wallpaper-video-url');
    // A beautiful cyberpunk neon glowing tunnel loop matching user's uploaded video perfectly
    return saved !== null ? saved : 'https://cdn.pixabay.com/video/2021/08/21/85732-591461947_large.mp4';
  });

  const [pinterestPinId, setPinterestPinId] = useState<string>(() => {
    const saved = localStorage.getItem('portfolio-pinterest-pin-id');
    return saved !== null ? saved : '342062534216906522';
  });

  const [resumeModalOpen, setResumeModalOpen] = useState(false);
  const [customResumeUrl, setCustomResumeUrl] = useState<string>(() => {
    return localStorage.getItem('portfolio-custom-resume-url') || '';
  });

  // Load custom configuration from server on mount to hydrate preview/published app
  useEffect(() => {
    fetch('/api/portfolio-config')
      .then(res => {
        if (res.ok) return res.json();
        throw new Error('No custom config exists on server');
      })
      .then(data => {
        if (data) {
          if (data.profile) setProfile(data.profile);
          if (data.contact) setContact(data.contact);
          if (data.projects) setProjects(data.projects);
          if (data.hourlyRate) setHourlyRate(data.hourlyRate);
          if (typeof data.showWallpaper === 'boolean') setShowWallpaper(data.showWallpaper);
          if (typeof data.bgStreamPinned === 'boolean') setBgStreamPinned(data.bgStreamPinned);
          if (typeof data.wallpaperOpacity === 'number') setWallpaperOpacity(data.wallpaperOpacity);
          if (data.wallpaperType) setWallpaperType(data.wallpaperType);
          if (data.wallpaperVideoUrl) setWallpaperVideoUrl(data.wallpaperVideoUrl);
          if (data.pinterestPinId) setPinterestPinId(data.pinterestPinId);
          if (data.customResumeUrl) setCustomResumeUrl(data.customResumeUrl);
        }
        setIsLoadedFromServer(true);
      })
      .catch(err => {
        console.log("No custom config fetched from server. Using local/defaults:", err.message);
        setIsLoadedFromServer(true);
      });
  }, []);

  // Sync state edits to the server in real-time, debounced by 1 second to avoid excessive disk I/O
  useEffect(() => {
    if (!isLoadedFromServer) return;

    const savePayload = {
      profile,
      contact,
      projects,
      hourlyRate,
      showWallpaper,
      bgStreamPinned,
      wallpaperOpacity,
      wallpaperType,
      wallpaperVideoUrl,
      pinterestPinId,
      customResumeUrl
    };

    const delayDebounceFn = setTimeout(() => {
      fetch('/api/portfolio-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(savePayload)
      })
      .then(res => {
        if (res.ok) console.log("Real-time portfolio backup synchronized to server.");
      })
      .catch(err => console.error("Error auto-syncing portfolio config to server:", err));
    }, 1000);

    return () => clearTimeout(delayDebounceFn);
  }, [
    isLoadedFromServer,
    profile,
    contact,
    projects,
    hourlyRate,
    showWallpaper,
    bgStreamPinned,
    wallpaperOpacity,
    wallpaperType,
    wallpaperVideoUrl,
    pinterestPinId,
    customResumeUrl
  ]);

  useEffect(() => {
    localStorage.setItem('portfolio-custom-resume-url', customResumeUrl);
  }, [customResumeUrl]);

  // 2. Handle Theme toggles
  useEffect(() => {
    localStorage.setItem('portfolio-dark-theme', String(isDark));
    if (isDark) {
      document.documentElement.classList.add('dark');
      document.documentElement.style.colorScheme = 'dark';
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.style.colorScheme = 'light';
    }
  }, [isDark]);

  // 3. Save adjustments to localStorage
  useEffect(() => {
    localStorage.setItem('portfolio-hourly-rate', String(hourlyRate));
  }, [hourlyRate]);

  useEffect(() => {
    localStorage.setItem('portfolio-profile', JSON.stringify(profile));
    checkCustomizationStatus();
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('portfolio-contact', JSON.stringify(contact));
    checkCustomizationStatus();
  }, [contact]);

  useEffect(() => {
    localStorage.setItem('portfolio-projects', JSON.stringify(projects));
    checkCustomizationStatus();
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('portfolio-show-wallpaper', String(showWallpaper));
  }, [showWallpaper]);

  useEffect(() => {
    localStorage.setItem('portfolio-wallpaper-pinned', String(bgStreamPinned));
  }, [bgStreamPinned]);

  useEffect(() => {
    localStorage.setItem('portfolio-wallpaper-opacity', String(wallpaperOpacity));
  }, [wallpaperOpacity]);

  useEffect(() => {
    localStorage.setItem('portfolio-wallpaper-type', wallpaperType);
  }, [wallpaperType]);

  useEffect(() => {
    localStorage.setItem('portfolio-wallpaper-video-url', wallpaperVideoUrl);
  }, [wallpaperVideoUrl]);

  useEffect(() => {
    localStorage.setItem('portfolio-pinterest-pin-id', pinterestPinId);
  }, [pinterestPinId]);

  const checkCustomizationStatus = () => {
    const isProfileModified = JSON.stringify(profile) !== JSON.stringify(INITIAL_PROFILE);
    const isContactModified = JSON.stringify(contact) !== JSON.stringify(INITIAL_CONTACT);
    const isProjectsModified = JSON.stringify(projects) !== JSON.stringify(INITIAL_PROJECTS);
    setHasCustomizations(isProfileModified || isContactModified || isProjectsModified);
  };

  // 4. Reset customization utility
  const handleResetDefaults = () => {
    if (window.confirm("Do you want to reset all custom uploaded images, video links, or contact info to defaults?")) {
      setIsLoadedFromServer(false);
      
      setProfile(INITIAL_PROFILE);
      setContact(INITIAL_CONTACT);
      setProjects(INITIAL_PROJECTS);
      setHourlyRate(35);
      setShowWallpaper(true);
      setBgStreamPinned(true);
      setWallpaperOpacity(0.35);
      setWallpaperType('pinterest');
      setWallpaperVideoUrl('https://cdn.pixabay.com/video/2021/08/21/85732-591461947_large.mp4');
      setPinterestPinId('1037516832923726528');
      setCustomResumeUrl('');

      localStorage.removeItem('portfolio-profile');
      localStorage.removeItem('portfolio-contact');
      localStorage.removeItem('portfolio-projects');
      localStorage.removeItem('portfolio-hourly-rate');
      localStorage.removeItem('portfolio-show-wallpaper');
      localStorage.removeItem('portfolio-wallpaper-pinned');
      localStorage.removeItem('portfolio-wallpaper-opacity');
      localStorage.removeItem('portfolio-wallpaper-type');
      localStorage.removeItem('portfolio-wallpaper-video-url');
      localStorage.removeItem('portfolio-pinterest-pin-id');
      localStorage.removeItem('portfolio-custom-resume-url');
      
      setHasCustomizations(false);

      // Reset on server too
      fetch('/api/portfolio-config', { method: 'DELETE' })
        .then(() => {
          setIsLoadedFromServer(true);
          alert("All parameters restored successfully.");
        })
        .catch(err => {
          console.error("Failed to delete server portfolio configurations:", err);
          setIsLoadedFromServer(true);
          alert("All parameters restored locally, but server config was not deleted.");
        });
    }
  };

  if (!isLoadedFromServer) {
    return (
      <div className="min-h-screen bg-zinc-950 text-zinc-50 flex flex-col items-center justify-center space-y-4 font-sans select-none">
        <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
        <p className="font-mono text-[10px] text-zinc-400 tracking-widest uppercase animate-pulse">
          Loading Remark's Portfolio...
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-brand-dark text-zinc-900 dark:text-zinc-50 transition-colors duration-300 antialiased overflow-x-hidden selection:bg-brand-accent selection:text-white">
      
      {/* Dynamic Ambient Blur overlays (hidden when wallpaper pins in background) */}
      {!bgStreamPinned && (
        <div className="absolute top-1/4 left-1/10 w-96 h-96 rounded-full bg-brand-accent/5 filter blur-[120px] pointer-events-none" />
      )}

      {/* 1. Header Navigation System */}
      <Navbar 
        contact={contact}
        isDark={isDark}
        onThemeToggle={() => setIsDark(!isDark)}
        onCustomizerToggle={() => setDrawerOpen(true)}
        hasCustomizations={hasCustomizations}
        onViewResume={() => setResumeModalOpen(true)}
        onBookCall={() => document.getElementById('book-call')?.scrollIntoView({ behavior: 'smooth' })}
      />

      {/* 2. Interactive Section Slots */}
      <main className="space-y-0 relative z-10">
        
        {/* Banner */}
        <Hero 
          profile={profile}
          contact={contact}
          onViewResume={() => setResumeModalOpen(true)}
          onBookCall={() => document.getElementById('book-call')?.scrollIntoView({ behavior: 'smooth' })}
        />

        {/* Ownership pitch highlights */}
        <About 
          profile={profile}
        />

        {/* Tabbed workflow cards + Cost calculator maps */}
        <ProjectsTabs 
          projects={projects}
          hourlyRate={hourlyRate}
          setHourlyRate={setHourlyRate}
        />

        {/* Loom / YouTube Showcase reels */}
        <VideoGallery />

        {/* Ticking achievements results blocks & Interactive ROI Calculator */}
        <Results />

        {/* Tool integrations bento grids */}
        <TechStack />

        {/* Customer reviews slider boxes */}
        <Testimonials />

        {/* Embedded Book a Free Discovery Call custom section */}
        <section 
          id="book-call" 
          className="py-20 px-4 bg-zinc-50 dark:bg-zinc-950 border-t border-b border-zinc-150 dark:border-zinc-900 transition-all relative"
        >
          <div className="max-w-4xl mx-auto text-center space-y-4 mb-10">
            <h2 className="text-3xl sm:text-4xl font-bold font-display tracking-tight text-zinc-900 dark:text-white">
              Book a Free Discovery Call
            </h2>
            <p className="max-w-2xl mx-auto text-xs sm:text-sm text-zinc-650 dark:text-zinc-400 leading-relaxed">
              Schedule a free consultation to discuss AI automation, workflow optimization, and business process improvements.
            </p>
          </div>

          <div className="max-w-4xl mx-auto bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-850 rounded-3xl overflow-hidden shadow-xl p-2 sm:p-4 relative">
            <CalendlyEmbed 
              url={contact.calendly || "https://calendly.com/gojoswcollab/new-meeting"} 
              height="750px" 
            />
          </div>
        </section>

        {/* Form estimator dispatch grids */}
        <Contact 
          contact={contact}
        />

      </main>

      {/* 5. Ambient Process Stream (Pinterest Iframe Background/Backdrop) */}
      {showWallpaper && (
        <div 
          id="bg-process-iframe-container"
          className={`transition-all duration-700 ease-in-out ${
            bgStreamPinned 
              ? 'fixed inset-0 w-full h-full z-1 pointer-events-none flex items-center justify-center select-none bg-zinc-950/5' 
              : 'fixed bottom-24 left-6 z-30 pointer-events-auto shadow-2xl'
          }`}
        >
          <div 
            className={`relative transition-all duration-500 overflow-hidden ${
              bgStreamPinned 
                ? 'bg-transparent border-none p-0 w-full max-w-[600px] h-[1167px] flex items-center justify-center saturate-75' 
                : 'bg-zinc-950/95 backdrop-blur-md p-3 rounded-2xl border border-zinc-800 w-[320px]'
            }`}
            style={{
              opacity: bgStreamPinned ? wallpaperOpacity : 1
            }}
          >
            {/* Absolute Controls overlying the floating frame (Strictly no letters/words) */}
            {!bgStreamPinned && (
              <div className="absolute top-3 right-3 z-50 flex items-center gap-1.5">
                <button
                  onClick={() => setBgStreamPinned(true)}
                  className="p-1.5 bg-zinc-900/90 hover:bg-zinc-800 text-zinc-300 hover:text-white rounded-lg border border-zinc-800 transition cursor-pointer"
                  title="Pin"
                >
                  <Pin className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setShowWallpaper(false)}
                  className="p-1.5 bg-zinc-900/90 hover:bg-zinc-800 text-zinc-300 hover:text-white rounded-lg border border-zinc-800 transition cursor-pointer"
                  title="Close"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Iframe or Video Frame container matching requested 600x1167 layout */}
            <div 
              className={`rounded-xl overflow-hidden bg-black flex items-center justify-center relative ${
                bgStreamPinned 
                  ? 'w-[600px] max-w-full h-[1167px] max-h-[85vh] shadow-[0_0_80px_rgba(255,87,34,0.12)] border border-zinc-200/5 dark:border-zinc-800/10' 
                  : 'h-[480px] w-full border border-zinc-850'
              }`}
            >
              {wallpaperType === 'video' ? (
                <video 
                  src={wallpaperVideoUrl}
                  autoPlay
                  loop
                  muted
                  playsInline
                  crossOrigin="anonymous"
                  className="absolute inset-0 w-full h-full object-cover select-none pointer-events-none"
                />
              ) : (
                <iframe 
                  src={`https://assets.pinterest.com/ext/embed.html?id=${pinterestPinId}`} 
                  height={bgStreamPinned ? "1167" : "1167"} 
                  width={bgStreamPinned ? "600" : "600"} 
                  frameBorder="0" 
                  scrolling="no"
                  title="Pinterest Dynamic Automation Feed"
                  className="absolute inset-0 w-full h-full object-cover select-none pointer-events-none"
                />
              )}
            </div>

            {/* Compact non-text Opacity range slider representing controls with no words/letters */}
            {!bgStreamPinned && (
              <div className="mt-2.5 flex items-center justify-center px-1">
                <input 
                  type="range" 
                  min="0.05" 
                  max="0.80" 
                  step="0.05"
                  value={wallpaperOpacity}
                  onChange={(e) => setWallpaperOpacity(Number(e.target.value))}
                  className="w-full h-1 bg-zinc-800 rounded accent-brand-accent cursor-pointer"
                />
              </div>
            )}

          </div>
        </div>
      )}

      {/* 3. Global Footer copyright blocks */}
      <Footer 
        contact={contact}
        onViewResume={() => setResumeModalOpen(true)}
      />

      {/* 4. Settings slider controller block */}
      <CustomizerDrawer 
        isOpen={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        profile={profile}
        setProfile={setProfile}
        contact={contact}
        setContact={setContact}
        projects={projects}
        setProjects={setProjects}
        hourlyRate={hourlyRate}
        setHourlyRate={setHourlyRate}
        onReset={handleResetDefaults}
        showWallpaper={showWallpaper}
        setShowWallpaper={setShowWallpaper}
        bgStreamPinned={bgStreamPinned}
        setBgStreamPinned={setBgStreamPinned}
        wallpaperOpacity={wallpaperOpacity}
        setWallpaperOpacity={setWallpaperOpacity}
        wallpaperType={wallpaperType}
        setWallpaperType={setWallpaperType}
        wallpaperVideoUrl={wallpaperVideoUrl}
        setWallpaperVideoUrl={setWallpaperVideoUrl}
        pinterestPinId={pinterestPinId}
        setPinterestPinId={setPinterestPinId}
        customResumeUrl={customResumeUrl}
        setCustomResumeUrl={setCustomResumeUrl}
      />

      {/* 5. Resume & CV Interactive Downloader Modal */}
      <ResumeModal 
        isOpen={resumeModalOpen}
        onClose={() => setResumeModalOpen(false)}
        profile={profile}
        contact={contact}
        customResumeUrl={customResumeUrl}
        setCustomResumeUrl={setCustomResumeUrl}
      />

      {/* Floating settings nudge indicator */}
      {!drawerOpen && (
        <button
          onClick={() => setDrawerOpen(true)}
          title="Open Customizer Panel"
          className="fixed bottom-24 right-6 z-30 p-3.5 bg-brand-accent text-white rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all outline-none flex items-center justify-center cursor-pointer group"
        >
          <Sliders className="w-5 h-5 group-hover:rotate-12 transition-transform duration-300 text-white" />
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 text-xs font-bold font-mono pl-0 group-hover:pl-2 whitespace-nowrap text-white">
            Live Customize Tools
          </span>
          {hasCustomizations && (
            <span className="absolute top-0 right-0 w-3 h-3 bg-indigo-500 rounded-full border-2 border-white dark:border-zinc-950 animate-pulse" />
          )}
        </button>
      )}

      {/* Floating Interactive Portfolio AI Chat Widget */}
      <AIChatWidget />

    </div>
  );
}
