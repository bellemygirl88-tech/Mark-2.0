export interface SVGWorkflowStep {
  id: string;
  label: string;
  type: 'trigger' | 'action' | 'ai' | 'condition' | 'target';
  description: string;
}

export interface SVGWorkflowEdge {
  from: string;
  to: string;
  label?: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  category: 'n8n' | 'zapier' | 'ghl';
  businessProblem: string;
  solution: string;
  timeSavedValue: number; // hours/month
  laborSavingsValue: number; // USD/month
  roiValue: number; // e.g. 300
  technologies: string[];
  loomUrl: string;
  screenshotUrl: string; // standard or base64
  workflowSteps?: SVGWorkflowStep[];
  workflowEdges?: SVGWorkflowEdge[];
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  text: string;
  avatarUrl?: string;
  rating: number;
}

export interface ContactInfo {
  name: string;
  email: string;
  whatsapp: string;
  linkedin: string;
  facebook: string;
  mobile: string;
  calendly: string;
  upwork: string;
}

export interface UserProfile {
  name: string;
  title: string;
  headline: string;
  subheadline: string;
  avatarUrl: string;
}
