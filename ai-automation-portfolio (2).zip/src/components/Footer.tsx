import React from 'react';
import { Mail, Linkedin, Github, MessageSquare, ShieldCheck, ArrowUp, Facebook, Briefcase, FileText } from 'lucide-react';
import { ContactInfo } from '../types';

interface FooterProps {
  contact: ContactInfo;
  onViewResume: () => void;
}

export default function Footer({ contact, onViewResume }: FooterProps) {
  
  const handleScrollToTop = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer 
      id="footer-root" 
      className="bg-zinc-50 dark:bg-zinc-950 border-t border-zinc-200/50 dark:border-zinc-800/50 text-zinc-600 dark:text-zinc-400 py-12 transition-colors duration-300"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center md:items-start text-left">
          
          {/* L: Brand bio (5 columns) */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-zinc-900 dark:bg-zinc-100 flex items-center justify-center text-white dark:text-zinc-950 font-bold text-base font-display">
                R
              </div>
              <div className="leading-none text-left">
                <span className="text-sm font-bold tracking-tight block text-zinc-900 dark:text-white">Remark Antipala</span>
                <span className="text-[10px] text-zinc-500 font-mono">Process Engineer</span>
              </div>
            </div>
            
            <p className="text-xs leading-relaxed max-w-sm">
              Providing enterprise-wide operational efficiency, automated lead qualification, and voice receptionist agents using stateful N8N, Zapier, and GoHighLevel CRM workflows.
            </p>

            <div className="flex items-center gap-1 text-[10px] text-zinc-400 font-mono font-medium">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>Full compliance with secure workspace regulations</span>
            </div>
          </div>

          {/* M: Quick scrolling lists (4 columns) */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 font-mono">Operations Directory</h4>
            
            <div className="grid grid-cols-2 gap-2 text-xs">
              <a href="#why-me" className="hover:text-zinc-900 dark:hover:text-zinc-200 transition">Why Work With Me?</a>
              <a href="#projects" className="hover:text-zinc-900 dark:hover:text-zinc-200 transition">Tabs Portfolio</a>
              <a href="#showcase" className="hover:text-zinc-900 dark:hover:text-zinc-200 transition">Video Walkthroughs</a>
              <a href="#solutions" className="hover:text-zinc-900 dark:hover:text-zinc-200 transition">Metrics Impact</a>
              <a href="#tech-stack" className="hover:text-zinc-900 dark:hover:text-zinc-200 transition">Supported Tech</a>
              <a href="#contact" className="hover:text-zinc-900 dark:hover:text-zinc-200 transition">Inquire Draft</a>
              <button 
                onClick={onViewResume} 
                className="hover:text-zinc-900 dark:hover:text-zinc-200 transition flex items-center gap-1 cursor-pointer text-left focus:outline-none"
              >
                <FileText className="w-3 h-3 text-brand-accent shrink-0" />
                <span>View CV / Resume</span>
              </button>
            </div>
          </div>

          {/* R: Direct call buttons & Social shortcuts (3 columns) */}
          <div className="md:col-span-3 space-y-4 flex flex-col items-start">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 font-mono">Connections</h4>
            
            <div className="flex flex-wrap gap-2">
              <a 
                href={contact.linkedin} 
                target="_blank" 
                rel="noopener noreferrer"
                title="Connect on LinkedIn" 
                className="p-2 border border-zinc-200 dark:border-zinc-800 rounded-lg bg-white dark:bg-zinc-900 hover:bg-zinc-100 dark:hover:bg-zinc-800 hover:text-zinc-900 dark:hover:text-zinc-100 transition shadow-sm"
              >
                <Linkedin className="w-3.5 h-3.5" />
              </a>
              <a 
                href={contact.upwork} 
                target="_blank" 
                rel="noopener noreferrer"
                title="Connect on Upwork" 
                className="p-2 border border-zinc-200 dark:border-zinc-800 rounded-lg bg-white dark:bg-zinc-900 hover:bg-zinc-100 dark:hover:bg-zinc-800 hover:text-zinc-900 dark:hover:text-zinc-100 transition shadow-sm"
              >
                <Briefcase className="w-3.5 h-3.5" />
              </a>
              <a 
                href={contact.facebook} 
                target="_blank" 
                rel="noopener noreferrer"
                title="Connect on Facebook" 
                className="p-2 border border-zinc-200 dark:border-zinc-800 rounded-lg bg-white dark:bg-zinc-900 hover:bg-zinc-100 dark:hover:bg-zinc-800 hover:text-zinc-900 dark:hover:text-zinc-100 transition shadow-sm"
              >
                <Facebook className="w-3.5 h-3.5" />
              </a>
              <a 
                href={`mailto:${contact.email}`} 
                title="Send direct email" 
                className="p-2 border border-zinc-200 dark:border-zinc-800 rounded-lg bg-white dark:bg-zinc-900 hover:bg-zinc-100 dark:hover:bg-zinc-800 hover:text-zinc-900 dark:hover:text-zinc-100 transition shadow-sm"
              >
                <Mail className="w-3.5 h-3.5" />
              </a>
              <a 
                href={contact.whatsapp} 
                target="_blank" 
                rel="noopener noreferrer"
                title="Message on WhatsApp" 
                className="p-2 border border-zinc-200 dark:border-zinc-800 rounded-lg bg-white dark:bg-zinc-900 hover:bg-zinc-100 dark:hover:bg-zinc-800 hover:text-zinc-900 dark:hover:text-zinc-100 transition shadow-sm"
              >
                <MessageSquare className="w-3.5 h-3.5" />
              </a>
              <a 
                href="https://github.com/remark-antipala" 
                target="_blank" 
                rel="noopener noreferrer"
                title="View code portfolio" 
                className="p-2 border border-zinc-200 dark:border-zinc-800 rounded-lg bg-white dark:bg-zinc-900 hover:bg-zinc-100 dark:hover:bg-zinc-800 hover:text-zinc-900 dark:hover:text-zinc-100 transition shadow-sm"
              >
                <Github className="w-3.5 h-3.5" />
              </a>
            </div>

            <button
              onClick={handleScrollToTop}
              className="px-3 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 text-[10px] font-semibold bg-white dark:bg-zinc-900 hover:bg-zinc-100 dark:hover:bg-zinc-805 transition flex items-center gap-1 select-none"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3 h-3" />
            </button>
          </div>

        </div>

        {/* Bottom copyright row */}
        <div className="pt-8 border-t border-zinc-200/50 dark:border-zinc-850 mt-12 flex flex-col sm:flex-row items-center justify-between text-[11px] text-zinc-400">
          <p>© {currentYear} Remark Antipala — AI Automation Engineer. All rights preserved.</p>
          <div className="flex gap-4 pt-2 sm:pt-0">
            <span className="font-mono text-[10px]">Coded in React + Tailwind CSS v4</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
