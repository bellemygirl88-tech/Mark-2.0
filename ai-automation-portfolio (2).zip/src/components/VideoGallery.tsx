import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, Video, FileVideo, Cpu, Sparkles, MonitorPlay, ExternalLink, ShieldCheck
} from 'lucide-react';

interface ShowcaseVideo {
  id: string;
  title: string;
  summary: string;
  roi: string;
  tools: string[];
  videoType: 'loom' | 'youtube' | 'mp4' | 'screenpal';
  videoUrl: string;
  screenpalId?: string;
  screenpalScript?: string;
  aspectRatio?: string;
}

export default function VideoGallery() {
  const [activeMedia, setActiveMedia] = useState<ShowcaseVideo | null>(null);

  useEffect(() => {
    if (activeMedia?.videoType === 'screenpal' && activeMedia.screenpalScript) {
      const script = document.createElement('script');
      script.src = activeMedia.screenpalScript;
      script.async = true;
      document.body.appendChild(script);
      return () => {
        if (document.body.contains(script)) {
          document.body.removeChild(script);
        }
      };
    }
  }, [activeMedia]);

  const showcaseVideos: ShowcaseVideo[] = [
    {
      id: "v-0",
      title: "Automated Lead Management and Booking Scheduling",
      summary: "End-to-end walkthrough of a high-efficiency lead digestion and routing process coordinating instant CRM logging and automated booking scheduling.",
      roi: "350% ROI / Saves 15+ hours of manual client intake dispatch weekly.",
      tools: ["N8N", "GoHighLevel", "OpenAI", "Webhooks"],
      videoType: "screenpal",
      videoUrl: "https://go.screenpal.com/player/cO1fDgnuIe2?ff=1&ahc=1&dcc=1&tl=1&bg=transparent&share=1&download=1&embed=1&cl=1",
      screenpalId: "cO1fDgnuIe2",
      screenpalScript: "https://go.screenpal.com/consumption/player_appearance/cO1fDgnuIe2/1.777778",
      aspectRatio: "1.777778"
    },
    {
      id: "v-1",
      title: "VAPI + N8N Multi-channel Voice AI Agent",
      summary: "Live recorded call demonstration where our AI Receptionist answers questions, parses appointment requests, and writes records directly to a scheduling calendar.",
      roi: "500% ROI / Slashing 40+ missed sales calls of high-ticket leads.",
      tools: ["VAPI", "N8N", "Airtable", "Google Calendar", "OpenAI"],
      videoType: "screenpal",
      videoUrl: "https://go.screenpal.com/player/cO1f3nnuIE7?ff=1&ahc=1&dcc=1&tl=1&bg=transparent&share=1&download=1&embed=1&cl=1",
      screenpalId: "cO1f3nnuIE7",
      screenpalScript: "https://go.screenpal.com/consumption/player_appearance/cO1f3nnuIE7/1.777778",
      aspectRatio: "1.777778"
    },
    {
      id: "v-2",
      title: "GoHighLevel Dashboard walkthrough",
      summary: "Step-by-step tour of a high-converting GoHighLevel platform customizing automation pipelines, custom dashboards, and user experience analytics.",
      roi: "500% ROI / Drives a 60% increase in brand authority and custom workspace engagement.",
      tools: ["GoHighLevel", "Custom CSS", "Lead Snapshots", "API Integrations"],
      videoType: "screenpal",
      videoUrl: "https://go.screenpal.com/player/cO1hIRnuoqP?ff=1&ahc=1&dcc=1&tl=1&bg=transparent&share=1&download=1&embed=1&cl=1",
      screenpalId: "cO1hIRnuoqP",
      screenpalScript: "https://go.screenpal.com/consumption/player_appearance/cO1hIRnuoqP/1.777778",
      aspectRatio: "1.777778"
    },
    {
      id: "v-3",
      title: "Messenger AI Agent Chat Diagnostics",
      summary: "Close-up capture of a Facebook direct message customer thread being answered instantaneously by a retrieval-augmented Gemini diagnostics agent.",
      roi: "300% ROI / 80+ customer support tickets answered without agents.",
      tools: ["N8N", "Messenger API", "Gemini API", "Supabase Vectors"],
      videoType: "screenpal",
      videoUrl: "https://go.screenpal.com/player/cO1frRnuIEy?ff=1&ahc=1&dcc=1&a=1&tl=1&bg=transparent&share=1&download=1&embed=1&cl=1",
      screenpalId: "cO1frRnuIEy",
      screenpalScript: "https://go.screenpal.com/consumption/player_appearance/cO1frRnuIEy/1.777778",
      aspectRatio: "1.777778"
    }
  ];

  const formatVideoSource = (item: ShowcaseVideo) => {
    if (item.videoType === 'loom') {
      if (item.videoUrl.includes('demo') || item.videoUrl.includes('receptionist')) {
        return 'mock'; // Render our high-fidelity mock player for placeholders
      }
      return item.videoUrl;
    }
    return item.videoUrl;
  };

  return (
    <section 
      id="showcase" 
      className="py-20 bg-zinc-900 text-zinc-100 transition-colors duration-300 relative overflow-hidden"
    >
      {/* Visual Mesh Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(255,79,0,0.06),transparent_40%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(99,102,241,0.06),transparent_40%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Gallery Header */}
        <div className="max-w-3xl mx-auto text-center space-y-3 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-zinc-800 border border-zinc-700/80 rounded-full">
            <MonitorPlay className="w-3.5 h-3.5 text-brand-accent" />
            <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-300 font-mono">Live Video Showcase</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight font-display text-white">
            System Showcases & Walking Tours
          </h2>
          <p className="text-xs sm:text-sm text-zinc-400">
            Click any demonstration block below to launch a close-up walkthrough of a functioning AI Agent or CRM sync in real action.
          </p>
        </div>

        {/* Video Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-left">
          {showcaseVideos.map((video) => (
            <motion.div
              key={video.id}
              whileHover={{ y: -4 }}
              transition={{ duration: 0.3 }}
              className="bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden flex flex-col justify-between shadow-lg group/card"
            >
              {/* Media Thumbnail Poster view */}
              <div 
                onClick={() => setActiveMedia(video)}
                className="relative aspect-video bg-zinc-900 group cursor-pointer flex items-center justify-center border-b border-zinc-800 overflow-hidden"
              >
                {/* Decorative Tech Image canvas overlays */}
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 to-transparent opacity-65 z-10" />
                
                {video.videoType === 'screenpal' ? (
                  <div className="absolute inset-0 bg-zinc-950 flex flex-col items-center justify-center p-4">
                    <div className="absolute inset-0 bg-gradient-to-tr from-brand-accent/25 via-indigo-500/10 to-transparent opacity-45 pointer-events-none" />
                    <LaptopIcon className="w-14 h-14 text-brand-accent/60 mb-1 group-hover/card:scale-105 transition duration-300" />
                    <span className="text-[9px] font-mono font-bold text-brand-accent tracking-widest uppercase truncate max-w-full px-2">
                      {video.id === 'v-0' ? 'Lead Flow Live' : video.id === 'v-1' ? 'Voice AI Live' : video.id === 'v-2' ? 'GHL Dashboard Live' : 'Messenger Bot Live'}
                    </span>
                  </div>
                ) : video.videoType === 'mp4' ? (
                  <video 
                    src={video.videoUrl} 
                    className="absolute inset-0 w-full h-full object-cover opacity-45 grayscale group-hover:grayscale-0 transition duration-500" 
                    muted 
                    loop 
                    playsInline
                    autoPlay
                  />
                ) : (
                  <div className="absolute inset-0 bg-zinc-900 flex items-center justify-center opacity-40">
                    <LaptopIcon className="w-16 h-16 text-zinc-700" />
                  </div>
                )}

                {/* Glowing play button anchor */}
                <div className="relative z-20 w-12 h-12 rounded-full bg-brand-accent text-white flex items-center justify-center shadow-lg group-hover:scale-110 group-hover:bg-brand-accent/90 transition duration-300">
                  <Play className="w-5 h-5 fill-white" />
                </div>

                {/* Video tag indicator */}
                <span className="absolute bottom-3 left-3 z-20 bg-zinc-900/80 backdrop-blur-md border border-zinc-700 font-mono px-2 py-0.5 rounded text-[8.5px] uppercase font-bold text-zinc-300">
                  {video.videoType} SHOWCASE
                </span>
              </div>

              {/* Card Meta Content */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <h3 className="font-bold text-sm tracking-tight text-white line-clamp-1 group-hover:text-brand-accent">
                    {video.title}
                  </h3>
                  <p className="text-[11px] leading-relaxed text-zinc-400">
                    {video.summary}
                  </p>
                </div>

                <div className="space-y-3.5 pt-3 border-t border-zinc-800/80">
                  {/* ROI metric block */}
                  <div className="space-y-0.5">
                    <span className="text-[8px] font-mono uppercase tracking-wider text-zinc-500 block">Durable Savings Return</span>
                    <span className="text-xs font-bold text-brand-accent flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 shrink-0" />
                      <span>{video.roi}</span>
                    </span>
                  </div>

                  {/* Tools list badges */}
                  <div className="flex flex-wrap gap-1">
                    {video.tools.map(tool => (
                      <span 
                        key={tool}
                        className="text-[9px] font-mono text-zinc-300 bg-zinc-900 border border-zinc-800 px-1.5 py-0.5 rounded"
                      >
                        {tool}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

            </motion.div>
          ))}
        </div>

      </div>

      {/* Lightbox Media Player Modal overlay */}
      <AnimatePresence>
        {activeMedia && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm pointer-events-auto"
            onClick={() => setActiveMedia(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className={`bg-zinc-950 border border-zinc-805 rounded-2xl w-full overflow-hidden shadow-2xl ${
                activeMedia.aspectRatio && parseFloat(activeMedia.aspectRatio) < 1 
                  ? 'max-w-xs sm:max-w-sm' 
                  : 'max-w-4xl'
              }`}
            >
              <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
                <div className="text-left">
                  <span className="text-[9px] font-semibold text-brand-accent uppercase font-mono tracking-wider">
                    {activeMedia.videoType.toUpperCase()} Video Active
                  </span>
                  <h4 className="font-bold text-sm text-white tracking-tight">
                    {activeMedia.title}
                  </h4>
                </div>
                <button 
                  onClick={() => setActiveMedia(null)}
                  className="px-2 py-1 bg-zinc-900 hover:bg-zinc-800 text-xs font-mono font-bold text-zinc-400 hover:text-white rounded border border-zinc-800"
                >
                  DISMISS [X]
                </button>
              </div>

              {/* Player Iframe container slot */}
              <div 
                className="relative bg-black w-full"
                style={{ aspectRatio: activeMedia.aspectRatio || '1.777778' }}
              >
                {formatVideoSource(activeMedia) === 'mock' ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-zinc-400 space-y-4 bg-zinc-900">
                    <Video className="w-12 h-12 text-zinc-700 animate-pulse" />
                    <div className="space-y-1.5 text-center max-w-sm">
                      <p className="text-xs font-bold text-zinc-200">{activeMedia.title} Demo Active</p>
                      <p className="text-[10px] text-zinc-500 leading-relaxed">
                        Loom/YouTube player mock layer is rendering. In production development, you can assign custom demonstration clips through the <strong>Customizer settings</strong> panel in the navbar.
                      </p>
                    </div>
                  </div>
                ) : activeMedia.videoType === 'mp4' ? (
                  <video 
                    src={activeMedia.videoUrl} 
                    className="absolute inset-0 w-full h-full object-contain" 
                    controls 
                    autoPlay
                  />
                ) : activeMedia.videoType === 'screenpal' ? (
                  <div 
                    className="sp-embed-player absolute inset-0 w-full h-full" 
                    data-id={activeMedia.screenpalId} 
                    data-aspect-ratio={activeMedia.aspectRatio || '1.777778'} 
                    style={{ position: 'absolute', width: '100%', height: '100%', top: 0, left: 0 }}
                  >
                    <iframe 
                      style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', border: 0 }}  
                      scrolling="no" 
                      src={activeMedia.videoUrl} 
                      allowFullScreen={true}
                      allow="autoplay; fullscreen"
                    />
                  </div>
                ) : (
                  <iframe 
                    src={activeMedia.videoUrl} 
                    frameBorder="0" 
                    webkitallowfullscreen="true" 
                    mozallowfullscreen="true" 
                    allowFullScreen 
                    className="absolute inset-0 w-full h-full"
                  />
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </section>
  );
}

// Minimal desktop svg vector placeholder icon inside file
function LaptopIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="1" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      {...props}
    >
      <rect width="18" height="12" x="3" y="4" rx="2" ry="2" />
      <line x1="2" x2="22" y1="20" y2="20" />
      <line x1="5" x2="19" y1="20" y2="16" />
    </svg>
  );
}
