import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  TrendingUp, Clock, ShieldCheck, Cpu, ArrowUpRight, Sliders, DollarSign, Calculator, HelpCircle
} from 'lucide-react';

type ComplexityType = 'simple' | 'medium' | 'complex';

export default function Results() {
  // 1. Ticking stats core counters (on mount)
  const [hoursSavedTotal, setHoursSavedTotal] = useState(0);
  const [dollarsSavedTotal, setDollarsSavedTotal] = useState(0);

  useEffect(() => {
    let active = true;
    const duration = 1500; // ms
    const steps = 40;
    const stepTime = duration / steps;
    
    let currentStep = 0;
    const timer = setInterval(() => {
      if (!active) return;
      currentStep++;
      
      setHoursSavedTotal(Math.min(100, Math.floor((100 / steps) * currentStep)));
      setDollarsSavedTotal(Math.min(5000, Math.floor((5000 / steps) * currentStep)));

      if (currentStep >= steps) {
        clearInterval(timer);
      }
    }, stepTime);

    return () => {
      active = false;
      clearInterval(timer);
    };
  }, []);

  // 2. Interactive ROI Calculator States
  const [hoursSavedInput, setHoursSavedInput] = useState<number>(80);
  const [hourlyWageInput, setHourlyWageInput] = useState<number>(35);
  const [complexity, setComplexity] = useState<ComplexityType>('medium');

  // Dynamic cost structures based on complexity
  const getComplexitySpec = (c: ComplexityType) => {
    switch (c) {
      case 'simple':
        return {
          label: "Simple API Sync (Zapier/Make)",
          desc: "Linear automated flows connecting 2-3 standard cloud apps.",
          buildCost: 1500,
          monthlyFees: 35,
          maintenanceRate: "Low (Minimal monitoring)"
        };
      case 'complex':
        return {
          label: "Enterprise Voice AI & RAG Agents (VAPI + N8N)",
          desc: "Full-duplex real-time telephone systems & indexing of vector corporate data.",
          buildCost: 6800,
          monthlyFees: 195,
          maintenanceRate: "High (Multi-agent nodes & API limits)"
        };
      case 'medium':
      default:
        return {
          label: "Advanced Workflow Logic (N8N System)",
          desc: "Stateful loops, data enrichment filters, custom webhook routing.",
          buildCost: 3200,
          monthlyFees: 75,
          maintenanceRate: "Medium (Regular updates & error handling)"
        };
    }
  };

  const currentSpec = getComplexitySpec(complexity);

  // ROI Computations
  const grossMonthlySavings = hoursSavedInput * hourlyWageInput;
  const grossYearlySavings = grossMonthlySavings * 12;
  const netMonthlySavings = Math.max(0, grossMonthlySavings - currentSpec.monthlyFees);
  const netYearlySavings = netMonthlySavings * 12;
  
  const firstYearNetProfit = netYearlySavings - currentSpec.buildCost;
  
  // Payback period in months
  const paybackPeriodMonths = netMonthlySavings > 0 
    ? Number((currentSpec.buildCost / netMonthlySavings).toFixed(1))
    : 0;

  // First year ROI percentage
  const firstYearRoiPercent = currentSpec.buildCost > 0 
    ? Number(((netYearlySavings / currentSpec.buildCost) * 100).toFixed(0))
    : 0;

  const bentoMetrics = [
    {
      id: "res-hours",
      title: "Hours Saved Monthly",
      label: "Autonomous Business Time",
      value: hoursSavedTotal + "+",
      color: "from-brand-accent/20 to-amber-500/5 hover:border-brand-accent/30",
      icon: <Clock className="w-5 h-5 text-brand-accent" />,
      tagline: "Directly replaces expensive manual data entry pipelines"
    },
    {
      id: "res-dollars",
      title: "Potential Monthly Labor Saved",
      label: "Operational Reinvestment",
      value: "$" + dollarsSavedTotal.toLocaleString() + "+",
      color: "from-emerald-500/20 to-teal-500/5 hover:border-emerald-500/30",
      icon: <TrendingUp className="w-5 h-5 text-emerald-500" />,
      tagline: "Replacing repetitive labor with $25-$50 developer-grade code"
    },
    {
      id: "res-flows",
      title: "Automation Workflows Built",
      label: "Production Pipelines",
      value: "20+",
      color: "from-indigo-500/20 to-violet-500/5 hover:border-indigo-500/30",
      icon: <Cpu className="w-5 h-5 text-indigo-500" />,
      tagline: "Across N8N core grids, Zapier, and GoHighLevel web CRM"
    },
    {
      id: "res-systems",
      title: "24/7 Active AI Agents",
      label: "Continuous Business Systems",
      value: "100%",
      color: "from-purple-500/20 to-fuchsia-500/5 hover:border-purple-500/30",
      icon: <ShieldCheck className="w-5 h-5 text-purple-500" />,
      tagline: "Constant lead capturing, qualified scores, and phone bookings"
    }
  ];

  return (
    <section 
      id="solutions" 
      className="py-20 bg-zinc-50 dark:bg-zinc-900/40 border-y border-zinc-200/50 dark:border-zinc-800/50 transition-colors duration-300 relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center space-y-3 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-zinc-150 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-850 rounded-full">
            <TrendingUp className="w-3.5 h-3.5 text-brand-accent" />
            <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-600 dark:text-zinc-300 font-mono">Business Dividends</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight font-display text-zinc-900 dark:text-white">
            Measurable Operational Results
          </h2>
          <p className="text-xs sm:text-sm text-zinc-500">
            Automating business processes removes repetitive workflows and guarantees direct financial returns on your operational budgets.
          </p>
        </div>

        {/* Results Bento Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-left">
          {bentoMetrics.map((metric, index) => (
            <motion.div
              key={metric.id}
              initial={{ opacity: 0, scale: 0.98 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className={`p-6 rounded-2xl bg-gradient-to-br bg-white dark:bg-zinc-950 border border-zinc-200/60 dark:border-zinc-850 hover:shadow-md transition duration-300 flex flex-col justify-between group ${metric.color}`}
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="p-2 rounded-xl bg-zinc-100 dark:bg-zinc-900 border border-zinc-200/50 dark:border-zinc-800/50">
                    {metric.icon}
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-zinc-400 group-hover:text-zinc-650 dark:group-hover:text-zinc-350 transition" />
                </div>

                <div className="space-y-1">
                  <h4 className="text-xs font-mono uppercase tracking-wider text-zinc-400 dark:text-zinc-500">
                    {metric.label}
                  </h4>
                  <span className="text-3xl font-extrabold tracking-tight font-display block text-zinc-900 dark:text-zinc-50 font-mono">
                    {metric.value}
                  </span>
                </div>
              </div>

              <div className="space-y-1.5 pt-6 border-t border-zinc-100 dark:border-zinc-800/80 mt-6">
                <span className="text-xs font-bold text-zinc-900 dark:text-zinc-200 leading-tight block">
                  {metric.title}
                </span>
                <p className="text-[10px] leading-relaxed text-zinc-500 dark:text-zinc-400">
                  {metric.tagline}
                </p>
              </div>

            </motion.div>
          ))}
        </div>

        {/* INTERACTIVE ROI CALCULATOR DASHBOARD */}
        <div className="mt-16 text-left">
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-zinc-950 border border-zinc-200/70 dark:border-zinc-850 shadow-lg space-y-8">
            
            {/* Header section in card */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-zinc-150 dark:border-zinc-800">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-brand-accent/10 border border-brand-accent/20 rounded-lg text-brand-accent">
                    <Calculator className="w-4 h-4" />
                  </div>
                  <h3 className="font-extrabold text-lg sm:text-xl font-display text-zinc-900 dark:text-white leading-none">
                    Enterprise Automation Savings Estimator
                  </h3>
                </div>
                <p className="text-xs text-zinc-500">
                  Calculate real-time labor, expense-replacement, and break-even periods based on operational parameters.
                </p>
              </div>
              <div className="inline-flex py-1 px-1.5 bg-zinc-50 dark:bg-zinc-900 rounded-xl border border-zinc-150 dark:border-zinc-800 self-start md:self-center">
                <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-500 px-2 py-1">Complexity Match</span>
              </div>
            </div>

            {/* Main calculator grid panel */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Sliders Input Block (7 columns) */}
              <div className="lg:col-span-7 space-y-6">
                
                {/* 1. Hours Saved Slider */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-xs sm:text-sm font-semibold">
                    <span className="text-zinc-650 dark:text-zinc-350">1. Labor Hours Saved Per Month</span>
                    <span className="font-mono bg-brand-accent/10 border border-brand-accent/20 text-brand-accent px-2.5 py-1 rounded-md text-xs font-bold">
                      {hoursSavedInput} hours
                    </span>
                  </div>
                  
                  <input 
                    type="range" 
                    min="5" 
                    max="400" 
                    step="5"
                    value={hoursSavedInput}
                    onChange={(e) => setHoursSavedInput(Number(e.target.value))}
                    className="w-full h-1.5 bg-zinc-100 dark:bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-brand-accent focus:outline-none"
                  />
                  <div className="flex justify-between text-[9px] text-zinc-400 font-mono">
                    <span>5 hrs (Small Task)</span>
                    <span>150 hrs (Part-time FTE)</span>
                    <span>400 hrs (2.5 Full-time Staff)</span>
                  </div>
                </div>

                {/* 2. Hourly Wage Slider */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-xs sm:text-sm font-semibold">
                    <span className="text-zinc-650 dark:text-zinc-350">2. Average Employee Cost per Hour</span>
                    <span className="font-mono bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-450 px-2.5 py-1 rounded-md text-xs font-bold">
                      ${hourlyWageInput}/hr
                    </span>
                  </div>
                  
                  <input 
                    type="range" 
                    min="15" 
                    max="150" 
                    step="5"
                    value={hourlyWageInput}
                    onChange={(e) => setHourlyWageInput(Number(e.target.value))}
                    className="w-full h-1.5 bg-zinc-100 dark:bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-brand-accent focus:outline-none"
                  />
                  <div className="flex justify-between text-[9px] text-zinc-400 font-mono">
                    <span>$15/hr (Basic Admin Desk)</span>
                    <span>$50/hr (Managerial Tier)</span>
                    <span>$150/hr (Niche Technical Developer)</span>
                  </div>
                </div>

                {/* 3. Project Complexity Select Blocks */}
                <div className="space-y-3.5">
                  <label className="block text-xs sm:text-sm font-semibold text-zinc-650 dark:text-zinc-350">
                    3. Select Automation Pipeline Architecture
                  </label>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {(['simple', 'medium', 'complex'] as ComplexityType[]).map((c) => {
                      const spec = getComplexitySpec(c);
                      const isSelected = complexity === c;
                      
                      return (
                        <button
                          key={c}
                          onClick={() => setComplexity(c)}
                          className={`p-3.5 rounded-xl border text-left flex flex-col justify-between transition-all duration-300 relative cursor-pointer ${
                            isSelected 
                              ? 'border-brand-accent bg-brand-accent/5 shadow-xs ring-1 ring-brand-accent' 
                              : 'border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-900/30 hover:bg-zinc-100/50 dark:hover:bg-zinc-900/50'
                          }`}
                        >
                          <div className="space-y-1">
                            <span className={`text-[8.5px] uppercase font-mono tracking-wider font-bold ${
                              c === 'simple' ? 'text-amber-500' : c === 'medium' ? 'text-brand-accent' : 'text-indigo-500'
                            }`}>
                              {c} setup
                            </span>
                            <h4 className="font-bold text-xs text-zinc-900 dark:text-zinc-100">
                              {c === 'simple' ? 'Zapier Integration' : c === 'medium' ? 'N8N System Logic' : 'Voice AI & Agents'}
                            </h4>
                            <p className="text-[10px] text-zinc-500 leading-snug mt-1">
                              {spec.monthlyFees > 0 ? `$${spec.monthlyFees}/mo tech stack fee` : 'Free'}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                  
                  {/* Selected Spec details note */}
                  <p className="text-[10px] font-semibold text-zinc-450 leading-relaxed bg-zinc-50 dark:bg-zinc-900 p-2.5 rounded-lg border border-zinc-150 dark:border-zinc-850 font-mono">
                    <span className="text-zinc-900 dark:text-zinc-200">System Spec: </span>
                    {currentSpec.desc} One-time build investment: <strong className="text-zinc-900 dark:text-white">${currentSpec.buildCost}</strong>.
                  </p>
                </div>

              </div>

              {/* Outputs Summary Cards (5 columns) */}
              <div className="lg:col-span-5 space-y-4">
                <div className="p-5.5 rounded-2xl bg-zinc-50 dark:bg-zinc-900/80 border border-zinc-200 dark:border-zinc-850 space-y-5 flex flex-col justify-between h-full">
                  
                  <div className="space-y-4">
                    <span className="text-[10px] font-bold text-zinc-400 font-mono uppercase tracking-wider block">PROJECTED ROI METRICS</span>
                    
                    {/* 1. Large ROI Box */}
                    <div className="p-4 bg-gradient-to-r from-brand-accent to-indigo-600 rounded-xl text-white space-y-1">
                      <span className="text-[9px] uppercase tracking-wider font-mono opacity-80 block">Standard 1st-Year Return</span>
                      <div className="flex items-baseline justify-between">
                        <span className="text-3xl font-black tracking-tight font-mono">
                          {firstYearRoiPercent.toLocaleString()}% ROI
                        </span>
                        <TrendingUp className="w-6 h-6 opacity-80" />
                      </div>
                      <p className="text-[9px] opacity-90 leading-tight">
                        Break-even expected in <strong className="font-mono">{paybackPeriodMonths}</strong> months. Net monthly gains of <strong>${netMonthlySavings.toLocaleString()}</strong>.
                      </p>
                    </div>

                    {/* 2. Savings breakdown Grid list */}
                    <div className="space-y-2.5">
                      
                      {/* Monthly Net Savings item */}
                      <div className="flex items-center justify-between p-2.5 bg-white dark:bg-zinc-950 border border-zinc-150 dark:border-zinc-800 rounded-xl">
                        <div className="flex items-center gap-2">
                          <DollarSign className="w-3.5 h-3.5 text-emerald-500" />
                          <span className="text-xs font-semibold text-zinc-650 dark:text-zinc-350">Net Monthly Savings:</span>
                        </div>
                        <span className="font-mono text-xs font-bold text-emerald-600 dark:text-emerald-400">
                          ${netMonthlySavings.toLocaleString()}
                        </span>
                      </div>

                      {/* 1st Year Net Profit */}
                      <div className="flex items-center justify-between p-2.5 bg-white dark:bg-zinc-950 border border-zinc-150 dark:border-zinc-800 rounded-xl">
                        <div className="flex items-center gap-2">
                          <TrendingUp className="w-3.5 h-3.5 text-indigo-500" />
                          <span className="text-xs font-semibold text-zinc-650 dark:text-zinc-350">1st Year Net Profit:</span>
                        </div>
                        <span className={`font-mono text-xs font-bold ${firstYearNetProfit >= 0 ? 'text-indigo-650 dark:text-indigo-400' : 'text-red-500'}`}>
                          {firstYearNetProfit < 0 ? '-' : ''}${Math.abs(firstYearNetProfit).toLocaleString()}
                        </span>
                      </div>

                      {/* Estimated Back payback Period */}
                      <div className="flex items-center justify-between p-2.5 bg-white dark:bg-zinc-950 border border-zinc-150 dark:border-zinc-800 rounded-xl">
                        <div className="flex items-center gap-2">
                          <CheckCircle2Icon className="w-3.5 h-3.5 text-amber-500" />
                          <span className="text-xs font-semibold text-zinc-650 dark:text-zinc-350">Break-even Window:</span>
                        </div>
                        <span className="font-mono text-xs font-bold text-zinc-900 dark:text-zinc-100">
                          {paybackPeriodMonths || 'Instant'} Months
                        </span>
                      </div>

                    </div>

                    {/* Payback timeline bar */}
                    {netMonthlySavings > 0 && (
                      <div className="space-y-1.5 text-left pt-1">
                        <div className="flex justify-between text-[9px] text-zinc-400 font-semibold font-mono">
                          <span>Payback Timeline Progress</span>
                          <span>{Math.round(Math.min(100, (paybackPeriodMonths ? (12 / paybackPeriodMonths) * 10 : 0)))}% / Yr</span>
                        </div>
                        <div className="relative w-full h-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-full overflow-hidden">
                          <div 
                            className="absolute top-0 left-0 h-full bg-brand-accent transition-all duration-500"
                            style={{ width: `${Math.min(100, paybackPeriodMonths > 0 ? (1.5 / paybackPeriodMonths) * 100 : 100)}%` }}
                          />
                        </div>
                      </div>
                    )}

                  </div>

                  {/* Summary prompt footer inside card box */}
                  <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800 text-[10px] text-zinc-500 text-center leading-snug">
                    Savings calculations based on standard human replacement metrics at a ${hourlyWageInput}/hr fully loaded wage rate.
                  </div>

                </div>
              </div>

            </div>

          </div>
        </div>

        {/* Business Partner ROI reassurance section */}
        <div className="mt-12 p-6 rounded-2xl bg-white dark:bg-zinc-950 border border-zinc-200/60 dark:border-zinc-850 shadow-sm grid grid-cols-1 lg:grid-cols-12 gap-6 items-center max-w-4xl mx-auto">
          <div className="lg:col-span-8 space-y-1.5 text-left">
            <h4 className="font-bold text-sm text-zinc-900 dark:text-zinc-100 tracking-tight flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-brand-accent shrink-0 animate-pulse" />
              <span>Free Discovery & ROI Analysis Included</span>
            </h4>
            <p className="text-xs leading-relaxed text-zinc-500 dark:text-zinc-455">
              Before writing any code or linking API triggers, I will map out your current business systems and draft an exact ROI spreadsheet displaying potential labor, license, and accuracy dividends.
            </p>
          </div>
          <div className="lg:col-span-4 flex justify-end">
            <a 
              href="#contact"
              className="w-full sm:w-auto px-5 py-2.5 bg-zinc-900 dark:bg-white text-white dark:text-zinc-950 rounded-xl text-xs font-semibold hover:bg-zinc-800 dark:hover:bg-zinc-100 transition shadow-sm text-center"
            >
              Request Free System Audit
            </a>
          </div>
        </div>

      </div>
    </section>
  );
}

// Check icon vector inside file
function CheckCircle2Icon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      {...props}
    >
      <circle cx="12" cy="12" r="10" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}
