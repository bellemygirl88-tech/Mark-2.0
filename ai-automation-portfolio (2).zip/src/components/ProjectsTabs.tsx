import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Clock, DollarSign, TrendingUp, Sparkles, AlertCircle, CheckCircle, 
  Play, Laptop, Sliders, ChevronRight, HelpCircle, FileVideo, ExternalLink, 
  Map, MessageSquare, Video, Landmark, Grid3X3, Layers, Database
} from 'lucide-react';
import { Project, SVGWorkflowStep } from '../types';

interface ProjectsTabsProps {
  projects: Project[];
  hourlyRate: number;
  setHourlyRate: (r: number) => void;
}

type CardSubTab = 'blueprint' | 'video' | 'roi';
type GalleryFilter = 'all' | 'n8n' | 'zapier' | 'ghl';

export default function ProjectsTabs({ projects, hourlyRate, setHourlyRate }: ProjectsTabsProps) {
  const [activeTab, setActiveTab] = useState<'n8n' | 'zapier' | 'ghl'>('n8n');
  const [selectedVideoUrl, setSelectedVideoUrl] = useState<string | null>(null);
  const [localRates, setLocalRates] = useState<{ [key: string]: number }>({});
  const [activeWorkflowHover, setActiveWorkflowHover] = useState<string | null>(null);

  // Per-card inner tab state
  const [cardInnerTabs, setCardInnerTabs] = useState<{ [key: string]: CardSubTab }>({});
  
  // Blueprint Gallery Filter
  const [galleryFilter, setGalleryFilter] = useState<GalleryFilter>('all');

  // Filter projects by current tab
  const filteredProjects = projects.filter(p => p.category === activeTab);

  // Handle local customized hourly rates per card or global sync
  const getHourlyRateForProject = (projId: string) => {
    return localRates[projId] !== undefined ? localRates[projId] : hourlyRate;
  };

  const handleLocalRateChange = (projId: string, val: number) => {
    setLocalRates({ ...localRates, [projId]: val });
  };

  const getActiveInnerTab = (projId: string): CardSubTab => {
    return cardInnerTabs[projId] || 'blueprint';
  };

  const setActiveInnerTab = (projId: string, tab: CardSubTab) => {
    setCardInnerTabs({ ...cardInnerTabs, [projId]: tab });
  };

  // Helper to extract Loom Embed or Video URL
  const formatLoomEmbedUrl = (url: string) => {
    if (!url) return '';
    if (url.includes('/embed/')) return url;
    const match = url.match(/loom\.com\/(?:share|embed)\/([a-zA-Z0-9_-]+)/);
    if (match && match[1]) {
      return `https://www.loom.com/embed/${match[1]}?autoplay=0&hide_owner=true`;
    }
    return url;
  };

  const formatYoutubeEmbedUrl = (url: string) => {
    if (!url) return '';
    if (url.includes('/embed/')) return url;
    const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]+)/);
    if (match && match[1]) {
      return `https://www.youtube.com/embed/${match[1]}`;
    }
    return url;
  };

  // Node Color styles based on type
  const getNodeColor = (type: SVGWorkflowStep['type']) => {
    switch (type) {
      case 'trigger':
        return 'border-amber-500/30 bg-amber-500/5 text-amber-600 dark:text-amber-400';
      case 'ai':
        return 'border-indigo-500/30 bg-indigo-500/5 text-indigo-600 dark:text-indigo-400';
      case 'condition':
        return 'border-sky-500/30 bg-sky-500/5 text-sky-600 dark:text-sky-400';
      case 'action':
        return 'border-violet-500/30 bg-violet-500/5 text-violet-600 dark:text-violet-400';
      case 'target':
        return 'border-emerald-500/30 bg-emerald-500/5 text-emerald-600 dark:text-emerald-400';
      default:
        return 'border-zinc-500/30 bg-zinc-500/5';
    }
  };

  // Filtered list for the grand gallery
  const galleryProjects = galleryFilter === 'all' 
    ? projects 
    : projects.filter(p => p.category === galleryFilter);

  return (
    <section id="projects" className="py-20 bg-white dark:bg-brand-dark transition-colors duration-300 relative">
      <div className="absolute inset-0 bg-[linear-gradient(to_bottom,transparent,#80808003_80%,transparent)] pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        
        {/* Section Heading */}
        <div className="max-w-3xl mx-auto text-center space-y-3 mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-full">
            <Sparkles className="w-3.5 h-3.5 text-brand-accent" />
            <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-650 dark:text-zinc-350 font-mono">Completed Systems</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight font-display text-zinc-900 dark:text-white">
            Automation Ecosystem Portfolio
          </h2>
          <p className="text-xs sm:text-sm text-zinc-500 max-w-xl mx-auto">
            Interactive breakdowns of production-ready integrations. Slide hourly metrics to estimate direct operational labor savings, or switch card tabs to watch live walkthroughs directly.
          </p>
        </div>

        {/* Tab Selection Row */}
        <div className="flex justify-center mb-10">
          <div className="inline-flex p-1 bg-zinc-100 dark:bg-zinc-900/80 rounded-xl border border-zinc-200/60 dark:border-zinc-800/80 shadow-sm select-none">
            {[
              { id: 'n8n', label: 'N8N Workflows', count: projects.filter(p => p.category === 'n8n').length },
              { id: 'zapier', label: 'Zapier Pipelines', count: projects.filter(p => p.category === 'zapier').length },
              { id: 'ghl', label: 'GoHighLevel CRM', count: projects.filter(p => p.category === 'ghl').length }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as 'n8n' | 'zapier' | 'ghl')}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-200 flex items-center gap-1.5 cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-50 shadow-xs border border-zinc-200/35 dark:border-zinc-700/30'
                    : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-300'
                }`}
              >
                <span>{tab.label}</span>
                <span className="text-[10px] bg-zinc-200/50 dark:bg-zinc-700/50 px-1.5 py-0.5 rounded font-mono font-medium">
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Active Tab Panel */}
        <div className="space-y-12">
          {filteredProjects.map((p, pIdx) => {
            const currentProjRate = getHourlyRateForProject(p.id);
            const calculatedMonthlySavings = p.timeSavedValue * currentProjRate;
            const calculatedYearlySavings = calculatedMonthlySavings * 12;
            const activeInnerTab = getActiveInnerTab(p.id);

            return (
              <motion.div
                key={p.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: pIdx * 0.1 }}
                className="bg-white dark:bg-zinc-900/60 border border-zinc-200/65 dark:border-zinc-850 rounded-2xl shadow-md hover:shadow-lg transition p-5 sm:p-7 space-y-6"
              >
                
                {/* 1. Header: Title, Category tag, and Loom Live Action */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-150 dark:border-zinc-800">
                  <div className="space-y-1.5 text-left">
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-mono font-black uppercase tracking-widest px-2.5 py-0.5 rounded bg-brand-accent/15 text-brand-accent border border-brand-accent/20">
                        {p.category.toUpperCase()} CORE ENGINE
                      </span>
                    </div>
                    <h3 className="text-xl sm:text-2xl font-bold font-display tracking-tight text-zinc-900 dark:text-white">
                      {p.title}
                    </h3>
                    <p className="text-xs text-zinc-500 max-w-2xl leading-relaxed">
                      {p.description}
                    </p>
                  </div>

                  {/* Dedicated Card Inner Tab Selector (Blueprint vs Video vs ROI breakdown) */}
                  <div className="flex p-0.5 bg-zinc-100 dark:bg-zinc-900 border border-zinc-200/50 dark:border-zinc-800/50 rounded-lg self-start sm:self-center shrink-0 shadow-xs">
                    {[
                      { id: 'blueprint', label: 'Blueprint', icon: <Map className="w-3.5 h-3.5" /> },
                      { id: 'video', label: 'Watch Video', icon: <Play className="w-3.5 h-3.5" /> },
                      { id: 'roi', label: 'ROI Savings', icon: <TrendingUp className="w-3.5 h-3.5" /> }
                    ].map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveInnerTab(p.id, tab.id as CardSubTab)}
                        className={`px-3 py-1.5 text-[10.5px] font-bold rounded flex items-center gap-1.5 cursor-pointer transition ${
                          activeInnerTab === tab.id
                            ? 'bg-white dark:bg-zinc-850 text-zinc-900 dark:text-white shadow-xs'
                            : 'text-zinc-550 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
                        }`}
                      >
                        {tab.icon}
                        <span>{tab.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  
                  {/* LEFT COLUMN: Main content viewport governed by inner tabs (8 Columns) */}
                  <div className="lg:col-span-8 space-y-6 text-left">
                    
                    <AnimatePresence mode="wait">
                      {/* Sub-tab 1: Blueprint Map + Screenshot */}
                      {activeInnerTab === 'blueprint' && (
                        <motion.div
                          key="blueprint-tab"
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          className="space-y-6"
                        >
                          {/* Problem/Solution Section */}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="p-4 bg-red-500/5 rounded-xl border border-red-500/10 space-y-2">
                              <div className="flex items-center gap-2 text-red-650 dark:text-red-400 font-bold text-xs">
                                <AlertCircle className="w-4 h-4" />
                                <span>BUSINESS CHALLENGE</span>
                              </div>
                              <p className="text-[11px] leading-relaxed text-zinc-650 dark:text-zinc-300">
                                {p.businessProblem}
                              </p>
                            </div>

                            <div className="p-4 bg-emerald-500/5 rounded-xl border border-emerald-500/10 space-y-2">
                              <div className="flex items-center gap-2 text-emerald-650 dark:text-emerald-400 font-bold text-xs">
                                <CheckCircle className="w-4 h-4" />
                                <span>AUTOMATED SYSTEM IMPLEMENTED</span>
                              </div>
                              <p className="text-[11px] leading-relaxed text-zinc-650 dark:text-zinc-300">
                                {p.solution}
                              </p>
                            </div>
                          </div>

                          {/* Steps Diagram */}
                          {p.workflowSteps && p.workflowSteps.length > 0 && (
                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <h4 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 font-mono">
                                  System Flow Node Blueprint
                                </h4>
                                <span className="text-[9px] text-zinc-400 font-mono font-medium">Interactive preview mode</span>
                              </div>
                              
                              <div className="p-4 bg-zinc-50 dark:bg-zinc-900 rounded-xl border border-zinc-150 dark:border-zinc-800">
                                <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-4 gap-3 relative">
                                  {p.workflowSteps.map((step, sIdx) => (
                                    <div 
                                      key={step.id} 
                                      className="relative flex flex-col items-stretch"
                                      onMouseEnter={() => setActiveWorkflowHover(step.id)}
                                      onMouseLeave={() => setActiveWorkflowHover(null)}
                                    >
                                      {sIdx < p.workflowSteps!.length - 1 && (
                                        <div className="hidden md:block absolute top-[18px] -right-2 w-4 h-[1px] bg-zinc-250 dark:bg-zinc-700 z-10 pointer-events-none" />
                                      )}

                                      <div className={`p-3 rounded-lg border text-left space-y-1 transition duration-300 ${getNodeColor(step.type)} ${
                                        activeWorkflowHover === step.id 
                                          ? 'scale-[1.01] shadow-xs border-zinc-400' 
                                          : 'opacity-90 hover:opacity-100'
                                      }`}>
                                        <div className="flex items-center justify-between">
                                          <span className="text-[7.5px] uppercase tracking-wider font-bold opacity-60 font-mono">
                                            Node 0{sIdx + 1}
                                          </span>
                                          <span className="text-[7px] font-semibold uppercase tracking-wider opacity-80 bg-zinc-400/10 px-1 rounded font-mono">
                                            {step.type}
                                          </span>
                                        </div>
                                        <h5 className="font-bold text-xs tracking-tight line-clamp-1 text-zinc-900 dark:text-white">
                                          {step.label}
                                        </h5>
                                        <p className="text-[9px] text-zinc-500 leading-snug line-clamp-2">
                                          {step.description}
                                        </p>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>
                          )}

                          {/* Screenshot Container */}
                          <div>
                            {p.screenshotUrl ? (
                              <div className="relative group rounded-xl overflow-hidden border border-zinc-200 dark:border-zinc-805 shadow-sm aspect-[16/9]">
                                <img 
                                  src={p.screenshotUrl} 
                                  alt={`${p.title} workflow schema`} 
                                  className="w-full h-full object-cover group-hover:scale-[1.01] transition-transform duration-500"
                                />
                                <div className="absolute top-2.5 left-2.5 bg-zinc-950/80 backdrop-blur-md px-2 py-0.5 text-[9px] text-zinc-200 rounded font-mono">
                                  WORKSPACE SCHEMA PREVIEW
                                </div>
                              </div>
                            ) : (
                              <div className="p-5 rounded-xl border border-dashed border-zinc-200 dark:border-zinc-800 bg-zinc-50/20 dark:bg-zinc-900/20 flex flex-col items-center justify-center text-center py-7">
                                <Laptop className="w-8 h-8 text-zinc-400 mb-2" />
                                <h5 className="text-[11px] font-bold text-zinc-700 dark:text-zinc-300">Sandbox Workspace Active</h5>
                                <p className="text-[10px] text-zinc-505 max-w-xs mt-1 leading-relaxed">
                                  Default blueprint template is loaded. Custom screenshots from actual {p.category.toUpperCase()} system setups can be uploaded instantly inside the <strong>Customizer Panel</strong>.
                                </p>
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}

                      {/* Sub-tab 2: Embedded Video Player (Matches 'Watch Video' inside card!) */}
                      {activeInnerTab === 'video' && (
                        <motion.div
                          key="video-tab"
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          className="space-y-4"
                        >
                          <div className="p-3 bg-brand-accent/5 border border-brand-accent/10 rounded-xl text-left flex items-start gap-2.5">
                            <FileVideo className="w-4 h-4 text-brand-accent mt-0.5" />
                            <div className="space-y-0.5">
                              <h5 className="text-xs font-bold text-zinc-800 dark:text-zinc-200">Embedded System Walkthrough</h5>
                              <p className="text-[10px] text-zinc-550 leading-relaxed">
                                Watch a recorded video demonstrating how this automation processes lead events and handles third-party APIs.
                              </p>
                            </div>
                          </div>

                          <div className="relative aspect-video w-full bg-black rounded-xl overflow-hidden border border-zinc-200 dark:border-zinc-800 shadow-lg">
                            {p.loomUrl.includes('demo') ? (
                              <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-zinc-400 bg-zinc-900 text-center">
                                <Laptop className="w-12 h-12 text-zinc-700 animate-pulse mb-3" />
                                <p className="text-xs font-bold text-zinc-200">Video Integration Sandbox Standby</p>
                                <p className="text-[10px] text-zinc-500 max-w-xs mt-1 leading-relaxed">
                                  No client video link is specified for this project. Provide any live YouTube or Loom embed link inside the <strong>Settings Customizer Panel</strong> to load the real video frame!
                                </p>
                              </div>
                            ) : p.loomUrl.includes('youtube.com') || p.loomUrl.includes('youtu.be') ? (
                              <iframe 
                                src={formatYoutubeEmbedUrl(p.loomUrl)} 
                                frameBorder="0" 
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                allowFullScreen 
                                className="absolute inset-0 w-full h-full"
                              />
                            ) : (
                              <iframe 
                                src={formatLoomEmbedUrl(p.loomUrl)} 
                                frameBorder="0" 
                                webkitallowfullscreen="true" 
                                mozallowfullscreen="true" 
                                allowFullScreen 
                                className="absolute inset-0 w-full h-full"
                              />
                            )}
                          </div>
                        </motion.div>
                      )}

                      {/* Sub-tab 3: In-Card Detailed ROI savings projections */}
                      {activeInnerTab === 'roi' && (
                        <motion.div
                          key="roi-tab"
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          className="space-y-5"
                        >
                          <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-xl space-y-2">
                            <h4 className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                              <Landmark className="w-4 h-4" />
                              <span>Calculated System Return Projections</span>
                            </h4>
                            <p className="text-[11px] leading-relaxed text-zinc-650 dark:text-zinc-350">
                              By replacing manual data entries, transcription setups, or repetitive CRM admin tasks with this autonomous {p.category.toUpperCase()} system, the corporate budget yields direct returns:
                            </p>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            
                            {/* Box 1 */}
                            <div className="p-4 bg-zinc-50 dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-800 rounded-xl space-y-1 text-left">
                              <Clock className="w-4 h-4 text-brand-accent" />
                              <span className="text-[8.5px] uppercase font-mono tracking-wider text-zinc-400 block pt-1.5">Monthly Saved Hours</span>
                              <span className="text-xl font-bold block text-zinc-900 dark:text-white font-mono">{p.timeSavedValue} Hours / Mo</span>
                              <p className="text-[9px] text-zinc-500 leading-tight">Directly re-invested into core client acquisitions</p>
                            </div>

                            {/* Box 2 */}
                            <div className="p-4 bg-zinc-50 dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-800 rounded-xl space-y-1 text-left">
                              <DollarSign className="w-4 h-4 text-emerald-500" />
                              <span className="text-[8.5px] uppercase font-mono tracking-wider text-zinc-400 block pt-1.5">Annual Replaced Cost</span>
                              <span className="text-xl font-bold block text-emerald-600 dark:text-emerald-400 font-mono">
                                ${(p.timeSavedValue * currentProjRate * 12).toLocaleString()} / Yr
                              </span>
                              <p className="text-[9px] text-zinc-500 leading-tight">Extrapolated against current custom wage of ${currentProjRate}/hr</p>
                            </div>

                            {/* Box 3 */}
                            <div className="p-4 bg-brand-accent/5 border border-brand-accent/10 rounded-xl space-y-1 text-left">
                              <Sparkles className="w-4 h-4 text-indigo-500 animate-pulse" />
                              <span className="text-[8.5px] uppercase font-mono tracking-wider text-zinc-500 block pt-1.5">Durable System ROI</span>
                              <span className="text-xl font-black block text-brand-accent font-mono">
                                {(((p.timeSavedValue * currentProjRate) / 45) * 100).toFixed(0)}% ROI
                              </span>
                              <p className="text-[9px] text-zinc-500 leading-tight">Calculated against standard system maintenance parameters</p>
                            </div>

                          </div>

                          <div className="p-3.5 bg-zinc-100/50 dark:bg-zinc-900/60 rounded-xl border border-zinc-150 dark:border-zinc-800/80 text-[10px] text-zinc-500 leading-relaxed font-mono">
                            <strong>ROI Philosophy Notes: </strong> Unlike simple marketing agency ads, these systems provide compounding leverage as long-term software assets. The payback period of this {p.title} system setup is estimated at just <strong className="text-zinc-900 dark:white">{(3200 / Math.max(1, p.timeSavedValue * currentProjRate)).toFixed(1)} months</strong> relative to the setup fee.
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Tech Stacks Tags footer */}
                    <div className="flex flex-wrap gap-1.5 pt-3 border-t border-zinc-100 dark:border-zinc-850">
                      {p.technologies.map(t => (
                        <span 
                          key={t}
                          className="text-[9px] font-mono tracking-tight text-zinc-650 dark:text-zinc-300 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200/50 dark:border-zinc-800/50 px-2 py-0.5 rounded-md"
                        >
                          {t}
                        </span>
                      ))}
                    </div>

                  </div>

                  {/* RIGHT COLUMN: Interactive Slider Controller on Card (4 Columns) */}
                  <div className="lg:col-span-4 space-y-4">
                    <div className="bg-zinc-50 dark:bg-zinc-900 p-4.5 rounded-2xl border border-zinc-200/65 dark:border-zinc-850 space-y-4">
                      
                      {/* Widget Header */}
                      <div className="flex items-center justify-between border-b border-zinc-150 dark:border-zinc-800 pb-3">
                        <div className="text-left space-y-1">
                          <h4 className="font-bold text-xs tracking-wider uppercase font-mono text-zinc-400">Card Calculator</h4>
                          <span className="text-[9.5px] text-zinc-500 block font-medium">Fine-tune labor charge rate</span>
                        </div>
                        <Sliders className="w-4 h-4 text-brand-accent" />
                      </div>

                      {/* Interactive Rate Slider */}
                      <div className="space-y-2 text-left">
                        <div className="flex justify-between text-xs font-mono font-medium">
                          <span className="text-zinc-505 dark:text-zinc-400">Wage / Hour:</span>
                          <span className="text-zinc-900 dark:text-white font-black">${currentProjRate}/hr</span>
                        </div>
                        
                        <input 
                          type="range" 
                          min="15" 
                          max="120" 
                          step="5"
                          value={currentProjRate}
                          onChange={(e) => handleLocalRateChange(p.id, Number(e.target.value))}
                          className="w-full h-1 bg-zinc-200 dark:bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-brand-accent focus:outline-none"
                        />
                        
                        <div className="flex justify-between text-[8px] font-mono text-zinc-400">
                          <span>$15/hr</span>
                          <span>$120/hr</span>
                        </div>
                      </div>

                      {/* Metrics Summary Rows */}
                      <div className="space-y-2 pt-1 font-mono">
                        
                        {/* Time Saved Meter */}
                        <div className="p-2.5 bg-white dark:bg-zinc-950 border border-zinc-150 dark:border-zinc-800/80 rounded-xl flex items-center justify-between">
                          <div className="flex items-center gap-1.5 shrink-0">
                            <Clock className="w-3.5 h-3.5 text-brand-accent" />
                            <span className="text-[10px] font-bold text-zinc-500">Hours Reclaimed:</span>
                          </div>
                          <span className="text-xs font-bold text-zinc-900 dark:text-white shrink-0">
                            {p.timeSavedValue} hrs/mo
                          </span>
                        </div>

                        {/* Calculated Monthly Savings */}
                        <div className="p-2.5 bg-white dark:bg-zinc-950 border border-zinc-150 dark:border-zinc-800/80 rounded-xl flex items-center justify-between">
                          <div className="flex items-center gap-1.5 shrink-0">
                            <DollarSign className="w-3.5 h-3.5 text-emerald-500" />
                            <span className="text-[10px] font-bold text-zinc-500">Monthly Saved:</span>
                          </div>
                          <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 shrink-0">
                            ${calculatedMonthlySavings.toLocaleString()}
                          </span>
                        </div>

                        {/* Extrapolated Yearly Cost replaced */}
                        <div className="p-2.5 bg-white dark:bg-zinc-950 border border-zinc-150 dark:border-zinc-800/80 rounded-xl flex items-center justify-between">
                          <div className="flex items-center gap-1.5 shrink-0">
                            <TrendingUp className="w-3.5 h-3.5 text-indigo-500 animate-pulse" />
                            <span className="text-[10px] font-bold text-zinc-500">Annual Savings:</span>
                          </div>
                          <span className="text-xs font-bold text-indigo-650 dark:text-indigo-400 shrink-0">
                            ${calculatedYearlySavings.toLocaleString()}
                          </span>
                        </div>

                        {/* Active system quotient badge */}
                        <div className="p-3 bg-brand-accent/5 rounded-xl border border-brand-accent/10 space-y-1 text-center">
                          <span className="text-[8.5px] uppercase font-bold text-zinc-550 block leading-none">
                            NET PIPELINE OUTCOME
                          </span>
                          <span className="text-xl font-black block text-brand-accent">
                            {(((calculatedMonthlySavings / 45) * 100)).toFixed(0)}% ROI
                          </span>
                          <span className="text-[8px] text-zinc-500 block leading-tight">
                            Opposed to fully loaded $45/mo hosting active rates
                          </span>
                        </div>

                      </div>

                    </div>
                  </div>

                </div>

              </motion.div>
            );
          })}
        </div>

        {/* GRAND PRODUCTION WORKFLOW BLUEPRINT GALLERY */}
        <div id="blueprint-gallery" className="mt-20 pt-16 border-t border-zinc-200/50 dark:border-zinc-800/50 text-left space-y-8">
          
          <div className="max-w-3xl space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-850 rounded-full">
              <Grid3X3 className="w-3.5 h-3.5 text-brand-accent" />
              <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-650 dark:text-zinc-350 font-mono">Operations Directory</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-bold font-display tracking-tight text-zinc-900 dark:text-white">
              Enterprise System Blueprint Gallery
            </h3>
            <p className="text-xs sm:text-sm text-zinc-500 leading-relaxed">
              Browse through Remark's automated library of workflows, database mappings, and voice platforms. Filter by core cloud orchestrator below.
            </p>
          </div>

          {/* Filter Sub Bar buttons */}
          <div className="flex flex-wrap items-center gap-2 select-none">
            {[
              { id: 'all', label: 'All Systems' },
              { id: 'n8n', label: 'N8N Blueprints' },
              { id: 'zapier', label: 'Zapier Pipelines' },
              { id: 'ghl', label: 'GoHighLevel Funnels' }
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setGalleryFilter(f.id as GalleryFilter)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition border cursor-pointer ${
                  galleryFilter === f.id
                    ? 'bg-zinc-900 text-white border-zinc-900 dark:bg-white dark:text-zinc-950 dark:border-white shadow-sm'
                    : 'bg-zinc-50 hover:bg-zinc-100 text-zinc-600 border-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 dark:text-zinc-400 dark:border-zinc-800'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Gallery Items Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {galleryProjects.map((p, idx) => (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, scale: 0.98 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: idx * 0.05 }}
                className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200/60 dark:border-zinc-850 rounded-2xl p-5 flex flex-col justify-between hover:shadow-md transition-all duration-300 space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[8px] font-mono font-bold px-1.5 py-0.5 rounded bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300">
                      {p.category.toUpperCase()} WORKFLOW
                    </span>
                    <span className="text-[10px] font-bold text-brand-accent font-mono">
                      {p.timeSavedValue} hrs/mo saved
                    </span>
                  </div>

                  <div className="space-y-1">
                    <h4 className="font-extrabold text-sm text-zinc-900 dark:text-white leading-tight font-display tracking-tight line-clamp-1">
                      {p.title}
                    </h4>
                    <p className="text-[10px] text-zinc-500 leading-snug line-clamp-3">
                      {p.description}
                    </p>
                  </div>
                </div>

                <div className="space-y-3.5 pt-4.5 border-t border-zinc-200 dark:border-zinc-800/80">
                  
                  {/* Stats snippet */}
                  <div className="flex justify-between items-center text-[10px] font-mono">
                    <span className="text-zinc-400">Est. Year Return:</span>
                    <span className="font-bold text-emerald-600 dark:text-emerald-400">
                      +${(p.timeSavedValue * hourlyRate * 12).toLocaleString()}
                    </span>
                  </div>

                  {/* Launch action link */}
                  <button
                    onClick={() => {
                      setActiveTab(p.category);
                      setActiveInnerTab(p.id, 'blueprint');
                      // Scroll smoothly to item card
                      const element = document.querySelector('#projects');
                      if (element) {
                        element.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                    className="w-full py-2 bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-850 text-zinc-700 dark:text-zinc-300 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <span>Inspect Step Blueprint</span>
                    <ChevronRight className="w-3 h-3" />
                  </button>

                </div>
              </motion.div>
            ))}
          </div>

        </div>

      </div>

      {/* Loom Embed Video Lightbox modal overlay (kept as fallback / maximize option!) */}
      <AnimatePresence>
        {selectedVideoUrl && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm pointer-events-auto"
            onClick={() => setSelectedVideoUrl(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="relative bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl w-full max-w-4xl overflow-hidden shadow-2xl"
            >
              <div className="p-4 border-b border-zinc-150 dark:border-zinc-800 flex items-center justify-between bg-zinc-50 dark:bg-zinc-950/80">
                <h4 className="font-bold text-sm tracking-tight flex items-center gap-2 text-zinc-900 dark:text-white">
                  <FileVideo className="w-4 h-4 text-brand-accent" />
                  <span>Maximize System Video Demonstration</span>
                </h4>
                <button 
                  onClick={() => setSelectedVideoUrl(null)}
                  className="p-1 text-zinc-555 hover:text-zinc-900 dark:hover:text-zinc-200 text-xs font-mono font-bold cursor-pointer"
                >
                  [ CLOSE X ]
                </button>
              </div>
              <div className="relative aspect-video bg-black w-full">
                {selectedVideoUrl.includes('demo') ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-zinc-400 space-y-4">
                    <Laptop className="w-16 h-16 text-zinc-600 animate-pulse" />
                    <div className="space-y-1.5 text-center max-w-md bg-zinc-900 duration-300 p-5 rounded-lg border border-zinc-800">
                      <p className="text-sm font-bold text-zinc-300">Video Integration Standby</p>
                      <p className="text-xs text-zinc-500 leading-relaxed">
                        Loom embed placeholder: <code>{selectedVideoUrl}</code> is active.
                        Configure actual customer-facing Loom URLs inside the customizer.
                      </p>
                    </div>
                  </div>
                ) : selectedVideoUrl.includes('youtube.com') || selectedVideoUrl.includes('youtu.be') ? (
                  <iframe 
                    src={formatYoutubeEmbedUrl(selectedVideoUrl)} 
                    frameBorder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowFullScreen 
                    className="absolute inset-0 w-full h-full"
                  />
                ) : (
                  <iframe 
                    src={formatLoomEmbedUrl(selectedVideoUrl)} 
                    frameBorder="0" 
                    webkitallowfullscreen="true" 
                    mozallowfullscreen="true" 
                    allowFullScreen 
                    className="absolute inset-0 w-full h-full"
                  />
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </section>
  );
}
