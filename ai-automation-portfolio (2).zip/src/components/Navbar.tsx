import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sun, Moon, Settings2, Mail, Menu, X, ArrowRight, Activity, FileText, Calendar
} from 'lucide-react';
import { ContactInfo } from '../types';

interface NavbarProps {
  contact: ContactInfo;
  isDark: boolean;
  onThemeToggle: () => void;
  onCustomizerToggle: () => void;
  hasCustomizations: boolean;
  onViewResume: () => void;
  onBookCall: () => void;
}

export default function Navbar({
  contact,
  isDark,
  onThemeToggle,
  onCustomizerToggle,
  hasCustomizations,
  onViewResume,
  onBookCall
}: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '#why-me', label: 'Why Me?' },
    { href: '#projects', label: 'Portfolio' },
    { href: '#showcase', label: 'Video Showcase' },
    { href: '#solutions', label: 'Metrics' },
    { href: '#tech-stack', label: 'Tech Stack' },
    { href: '#contact', label: 'Contact' }
  ];

  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const element = document.querySelector(href);
    if (element) {
      const topOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - topOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
      setMobileMenuOpen(false);
    }
  };

  return (
    <nav 
      id="navbar-root"
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled 
          ? 'bg-white/80 dark:bg-zinc-950/80 backdrop-blur-md shadow-sm border-b border-zinc-200/50 dark:border-zinc-800/50 py-3' 
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Logo Brand */}
          <a 
            href="#" 
            onClick={(e) => handleScrollTo(e, '#')}
            className="flex items-center gap-2 group focus:outline-none"
          >
            <div className="w-9 h-9 rounded-lg bg-zinc-900 dark:bg-zinc-100 flex items-center justify-center text-white dark:text-zinc-950 font-bold text-lg font-display group-hover:scale-105 transition-transform duration-300 shadow-sm">
              R
            </div>
            <div className="leading-none text-left">
              <span className="text-sm font-semibold tracking-tight block">Remark Antipala</span>
              <span className="text-[10px] text-zinc-500 font-mono">AI Automation Engineer</span>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <div className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleScrollTo(e, link.href)}
                className="text-xs font-medium text-zinc-600 hover:text-zinc-950 dark:text-zinc-400 dark:hover:text-zinc-50 transition"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Toolbar Actions */}
          <div className="hidden md:flex items-center gap-3">
            {/* Theme Toggle Button Group */}
            <div className="flex p-0.5 bg-zinc-100 dark:bg-zinc-900 rounded-lg border border-zinc-200/50 dark:border-zinc-800/10 shadow-sm shrink-0">
              <button
                onClick={onThemeToggle}
                className={`p-1.5 rounded-md flex items-center justify-center transition-all cursor-pointer ${
                  !isDark 
                    ? 'bg-white dark:bg-zinc-850 text-amber-500 shadow-xs' 
                    : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-300'
                }`}
                title="Use Light Theme Preference"
              >
                <Sun className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={onThemeToggle}
                className={`p-1.5 rounded-md flex items-center justify-center transition-all cursor-pointer ${
                  isDark 
                    ? 'bg-zinc-250 dark:bg-zinc-800 text-indigo-500 dark:text-indigo-400 shadow-xs' 
                    : 'text-zinc-400 hover:text-zinc-900'
                }`}
                title="Use Dark Theme Preference"
              >
                <Moon className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Customizer Button with Badge indicator if adjustments exist */}
            <button
              onClick={onCustomizerToggle}
              title="Customize Portfolio Presentation"
              className={`p-2 rounded-lg transition relative ${
                hasCustomizations
                  ? 'bg-brand-accent/10 hover:bg-brand-accent/20 text-brand-accent'
                  : 'bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:text-zinc-950 dark:hover:text-zinc-100'
              }`}
            >
              <Settings2 className="w-4 h-4" />
              {hasCustomizations && (
                <span className="absolute -top-1 -right-0.5 w-2.5 h-2.5 bg-brand-accent rounded-full animate-pulse border border-white dark:border-zinc-950" />
              )}
            </button>

            {/* CV Download / View Action */}
            <button
              onClick={onViewResume}
              className="px-3 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 text-[11px] font-semibold text-zinc-650 dark:text-zinc-300 hover:text-zinc-950 dark:hover:text-zinc-50 hover:bg-zinc-50 dark:hover:bg-zinc-900 transition flex items-center gap-1.5 shadow-xs cursor-pointer shrink-0"
              title="View, Print / Download Resume"
            >
              <FileText className="w-3.5 h-3.5 text-zinc-405" />
              <span>Resume</span>
            </button>

            {/* Book Call Button */}
            {onBookCall && (
              <button
                onClick={onBookCall}
                className="px-3 py-1.5 rounded-lg border border-brand-accent/20 dark:border-brand-accent/15 bg-brand-accent/5 dark:bg-brand-accent/5 hover:bg-brand-accent/10 hover:text-brand-accent dark:hover:bg-brand-accent/10 transition flex items-center gap-1.5 text-[11px] font-bold text-brand-accent shadow-xs cursor-pointer shrink-0"
                title="Schedule 30min Discovery Session"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Book Call</span>
              </button>
            )}

            {/* Main Email Action Button */}
            <a
              href={`mailto:${contact.email}`}
              className="px-3.5 py-1.5 rounded-lg bg-zinc-900 text-white dark:bg-white dark:text-zinc-950 hover:bg-zinc-800 dark:hover:bg-zinc-50 font-semibold text-[11px] tracking-tight transition flex items-center gap-1.2 shadow-sm cursor-pointer shrink-0"
            >
              <span>Get Proposal</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Mobile Hamburguer */}
          <div className="flex md:hidden items-center gap-2">
            <div className="flex p-0.5 bg-zinc-100 dark:bg-zinc-900 rounded-lg border border-zinc-200/50 dark:border-zinc-800/10 scale-95 mr-1 shrink-0 select-none">
              <button
                onClick={onThemeToggle}
                className={`p-1 rounded transition-all cursor-pointer ${
                  !isDark 
                    ? 'bg-white dark:bg-zinc-850 text-amber-500 shadow-xs' 
                    : 'text-zinc-550'
                }`}
                title="Light Mode"
              >
                <Sun className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={onThemeToggle}
                className={`p-1 rounded transition-all cursor-pointer ${
                  isDark 
                    ? 'bg-zinc-200 dark:bg-zinc-800 text-indigo-400 shadow-xs' 
                    : 'text-zinc-400'
                }`}
                title="Dark Mode"
              >
                <Moon className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={onCustomizerToggle}
              className={`p-2 rounded-lg relative ${
                hasCustomizations ? 'bg-brand-accent/10 text-brand-accent' : 'bg-zinc-100 text-zinc-700 dark:bg-zinc-900 dark:text-zinc-300'
              }`}
            >
              <Settings2 className="w-4 h-4" />
              {hasCustomizations && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-brand-accent rounded-full" />
              )}
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-zinc-100 text-zinc-700 dark:bg-zinc-900 dark:text-zinc-300"
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="md:hidden border-b border-zinc-200 dark:border-zinc-850 bg-white/95 dark:bg-zinc-950/95 backdrop-blur-md px-4 pt-2 pb-6 space-y-3 shadow-lg"
          >
            <div className="flex flex-col gap-2 pt-2">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => handleScrollTo(e, link.href)}
                  className="px-3 py-2 text-sm font-medium rounded-lg text-zinc-700 hover:bg-zinc-150 hover:text-zinc-950 dark:text-zinc-300 dark:hover:bg-zinc-900 dark:hover:text-zinc-100 transition"
                >
                  {link.label}
                </a>
              ))}
              <button
                onClick={() => {
                  onViewResume();
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-sm font-medium rounded-lg text-zinc-700 hover:bg-zinc-150 hover:text-zinc-950 dark:text-zinc-300 dark:hover:bg-zinc-900 dark:hover:text-zinc-100 transition flex items-center gap-2 cursor-pointer"
              >
                <FileText className="w-4 h-4 shrink-0 text-zinc-400" />
                <span>View & Download CV</span>
              </button>

              {onBookCall && (
                <button
                  type="button"
                  onClick={() => {
                    onBookCall();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-sm font-semibold rounded-lg bg-brand-accent/5 border border-brand-accent/15 text-brand-accent hover:bg-brand-accent/10 transition flex items-center gap-2 cursor-pointer"
                >
                  <Calendar className="w-4 h-4 shrink-0" />
                  <span>Book 30min Call (Calendly)</span>
                </button>
              )}

              <hr className="my-2 border-zinc-200 dark:border-zinc-800" />
              <a
                href={`mailto:${contact.email}`}
                className="w-full flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-lg bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 font-semibold text-sm transition"
              >
                <span>Email Discovery Request</span>
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
