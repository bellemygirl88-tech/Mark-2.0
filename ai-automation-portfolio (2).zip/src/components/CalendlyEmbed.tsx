import React, { useEffect, useState, useRef } from 'react';
import { Calendar, ArrowUpRight, RefreshCw } from 'lucide-react';

interface CalendlyEmbedProps {
  url: string;
  height?: string;
  className?: string;
}

export default function CalendlyEmbed({ url, height = "750px", className = "" }: CalendlyEmbedProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const cleanUrl = (url || 'https://calendly.com/gojoswcollab/new-meeting').trim();

  useEffect(() => {
    let active = true;

    // 1. Inject Calendly Stylesheet if not already injected
    let stylesheet = document.getElementById('calendly-style-sheet') as HTMLLinkElement;
    if (!stylesheet) {
      stylesheet = document.createElement('link');
      stylesheet.id = 'calendly-style-sheet';
      stylesheet.rel = 'stylesheet';
      stylesheet.href = 'https://assets.calendly.com/assets/external/widget.css';
      document.head.appendChild(stylesheet);
    }

    // 2. Inject Calendly Javascript
    let script = document.getElementById('calendly-external-script') as HTMLScriptElement;
    
    // Initializer function once script is available
    const initWidget = () => {
      if (!active) return;
      const calendlyObj = (window as any).Calendly;
      if (calendlyObj && calendlyObj.initInlineWidget && containerRef.current) {
        try {
          // Clear container innerHTML to avoid duplications
          containerRef.current.innerHTML = '';
          calendlyObj.initInlineWidget({
            url: cleanUrl,
            parentElement: containerRef.current,
            prefill: {},
            utm: {}
          });
          setIsLoaded(true);
        } catch (err) {
          console.error("Failed to initialize Calendly inline widget:", err);
          setHasError(true);
        }
      } else {
        // Wait and retry
        setTimeout(initWidget, 250);
      }
    };

    if (!script) {
      script = document.createElement('script');
      script.id = 'calendly-external-script';
      script.src = 'https://assets.calendly.com/assets/external/widget.js';
      script.async = true;
      script.onload = () => {
        initWidget();
      };
      script.onerror = () => {
        if (active) setHasError(true);
      };
      document.body.appendChild(script);
    } else {
      // Script exists, check if globally available or wait for it
      if ((window as any).Calendly) {
        initWidget();
      } else {
        script.addEventListener('load', initWidget);
        script.addEventListener('error', () => {
          if (active) setHasError(true);
        });
      }
    }

    // 3. Robust Sandbox Timeout Check
    // If the widget hasn't loaded (no iframe created or active error state) within 4.5 seconds,
    // trigger state error so we render the beautiful professional direct fallback button.
    const safetyCheck = setTimeout(() => {
      if (!active) return;
      const iframe = containerRef.current?.querySelector('iframe');
      if (iframe) {
        setIsLoaded(true);
      } else {
        // Try standard fallback identification
        if (!(window as any).Calendly) {
          setHasError(true);
        }
      }
    }, 4500);

    return () => {
      active = false;
      clearTimeout(safetyCheck);
    };
  }, [cleanUrl]);

  return (
    <div className={`w-full relative flex flex-col justify-center items-center ${className}`}>
      
      {/* Container holding Calendly's official widget markup */}
      <div 
        ref={containerRef}
        className="calendly-inline-widget w-full rounded-2xl overflow-hidden bg-white shadow-sm transition-all duration-300"
        data-url={cleanUrl}
        style={{ minWidth: "320px", height, display: hasError ? 'none' : 'block' }}
      />

      {/* Loading feedback */}
      {!isLoaded && !hasError && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-50 dark:bg-zinc-900 rounded-3xl p-6 min-h-[350px]">
          <RefreshCw className="w-8 h-8 text-brand-accent animate-spin mb-3" />
          <p className="text-xs font-semibold text-zinc-700 dark:text-zinc-300 font-sans">Connecting Secure Booking Portals...</p>
          <p className="text-[10px] text-zinc-450 dark:text-zinc-500 font-mono mt-1">Please wait a brief moment</p>
        </div>
      )}

      {/* Robust, gorgeous fallback layout for sandboxed environments */}
      {hasError && (
        <div className="w-full flex flex-col items-center justify-center p-8 sm:p-12 bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-850 rounded-2xl shadow-lg text-center max-w-xl mx-auto my-4 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-brand-accent/5 rounded-full filter blur-[40px] pointer-events-none" />
          
          <div className="w-12 h-12 bg-brand-accent/10 rounded-full flex items-center justify-center text-brand-accent mb-4 shrink-0">
            <Calendar className="w-6 h-6 animate-pulse" />
          </div>

          <h4 className="text-base font-bold font-display text-zinc-950 dark:text-white mb-2">
            Secure Booking Portal Connection
          </h4>
          <p className="text-xs text-zinc-550 dark:text-zinc-400 mb-6 max-w-md leading-relaxed">
            The booking frame is protected. Open the live scheduler in a secure new browser tab directly below to claim your automation slot.
          </p>
          
          <a
            href={cleanUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="book-call-btn inline-flex items-center gap-2 justify-center"
          >
            Schedule a Call
          </a>

          <span className="text-[9.5px] text-zinc-400 font-mono mt-4 leading-normal select-all">
            Direct Link: {cleanUrl}
          </span>
        </div>
      )}

    </div>
  );
}
