import React from 'react';
import { motion } from 'motion/react';
import { 
  Clock, ShieldCheck, CheckCircle2, TrendingUp, Sparkles, Building2, HelpCircle
} from 'lucide-react';
import { UserProfile } from '../types';

interface AboutProps {
  profile: UserProfile;
}

export default function About({ profile }: AboutProps) {
  
  const values = [
    {
      title: "Commitment to Ownership",
      desc: "I do not operate as an agency, nor do I outsource work to other freelancers. Hiring me is like hiring an active co-founder for your business systems."
    },
    {
      title: "Responsibility & Long-term Partnership",
      desc: "Unlike many transient applicants, I value trust and mutual accountability. I remain on-call to maintain, update, and audit your automation grids."
    },
    {
      title: "True ROI Philosophy",
      desc: "My focus is not simply setting up trigger boxes. I design automations to replace expensive manual processes and yield direct financial returns."
    }
  ];

  const outcomes = [
    { text: "Save Time", desc: "Instantly reclaim hours lost to repetitive entry grids.", color: "text-brand-accent bg-brand-accent/5 border-brand-accent/10" },
    { text: "Reduce Labor Costs", desc: "Empower current workers to handle double the operational throughput.", color: "text-indigo-500 bg-indigo-500/5 border-indigo-500/10" },
    { text: "Eliminate Human Error", desc: "No manual copying mistakes, data formatting hiccups, or lost email replies.", color: "text-amber-500 bg-amber-500/5 border-amber-500/10" },
    { text: "Improve CX System", desc: "Reply to clients within seconds rather than hours, delighting customers instantly.", color: "text-emerald-500 bg-emerald-500/5 border-emerald-500/10" },
    { text: "Increase Top-line Revenue", desc: "Automatically qualify, score, and transition leads to sales calendar bookings.", color: "text-sky-500 bg-sky-500/5 border-sky-500/10" },
    { text: "Deliver Measurable ROI", desc: "Track performance against hard numbers, guaranteeing financial gains.", color: "text-rose-500 bg-rose-500/5 border-rose-500/10" }
  ];

  return (
    <section 
      id="why-me" 
      className="py-20 bg-zinc-50 dark:bg-zinc-900/40 border-y border-zinc-200/50 dark:border-zinc-800/50 transition-colors duration-300"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="max-w-3xl mx-auto text-center space-y-3 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-full">
            <ShieldCheck className="w-3.5 h-3.5 text-brand-accent" />
            <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-650 dark:text-zinc-350 font-mono">The Partnership Advantage</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight font-display text-zinc-900 dark:text-white">
            Why Work With Me?
          </h2>
          <p className="text-xs sm:text-sm text-zinc-500">
            A reliable process developer built for ownership and direct accountability. See how my work strategy differs from outsourcing agencies.
          </p>
        </div>

        {/* Content Structure Split Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* LEFT HALF: Partnership pitch card & Core Values */}
          <div className="lg:col-span-6 space-y-6">
            <h3 className="text-xl sm:text-2xl font-bold font-display tracking-tight text-zinc-900 dark:text-white">
              An Dedicated Partner, Not an Outsourced Agency.
            </h3>
            
            <p className="text-xs sm:text-sm leading-relaxed text-zinc-650 dark:text-zinc-400">
              One thing that sets me apart is my absolute commitment to ownership and direct accountability. I value trust, responsibility, and long-term partnership above all else.
            </p>

            <div className="space-y-5 pt-3">
              {values.map((v, i) => (
                <div key={i} className="flex gap-4 p-4 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200/60 dark:border-zinc-850 shadow-sm hover:translate-x-1 transition duration-300">
                  <div className="w-7 h-7 rounded-lg bg-zinc-900 dark:bg-zinc-100 flex items-center justify-center shrink-0">
                    <span className="font-mono text-xs font-bold text-white dark:text-zinc-900">0{i+1}</span>
                  </div>
                  <div className="space-y-1.5 text-left">
                    <h4 className="font-semibold text-sm text-zinc-900 dark:text-zinc-100">{v.title}</h4>
                    <p className="text-[11px] leading-relaxed text-zinc-500 dark:text-zinc-400">{v.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT HALF: Purpose-built outcomes list */}
          <div className="lg:col-span-6 space-y-6 lg:pl-4">
            <div className="p-5 bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200/60 dark:border-zinc-850 shadow-sm space-y-6">
              
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-brand-accent animate-ping" />
                <h4 className="font-bold text-sm uppercase tracking-wider text-zinc-550 font-mono">My Design Directives</h4>
              </div>

              <p className="text-xs text-zinc-550 dark:text-zinc-400 leading-relaxed">
                I do not simply configure trigger scripts. Every automation pipeline I engineer is aligned to deliver concrete, metrics-driven outcomes:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pb-2">
                {outcomes.map((o, idx) => (
                  <div 
                    key={idx} 
                    className={`p-3.5 rounded-xl border flex flex-col text-left space-y-1.5 transition hover:scale-[1.01] duration-300 ${o.color}`}
                  >
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span className="font-bold text-xs tracking-tight">{o.text}</span>
                    </div>
                    <p className="text-[10px] leading-relaxed opacity-75">{o.desc}</p>
                  </div>
                ))}
              </div>

              {/* Accountability Sign-off Footer */}
              <div className="pt-4 border-t border-zinc-150 dark:border-zinc-800 flex items-center gap-3">
                <img 
                  src={profile.avatarUrl} 
                  alt="Sign off Avatar" 
                  className="w-9 h-9 rounded-full object-cover border border-zinc-200" 
                />
                <div className="text-left leading-tight">
                  <span className="text-xs font-bold block text-zinc-900 dark:text-zinc-200">Remark Antipala</span>
                  <span className="text-[10px] text-zinc-400 font-mono">"I remain accountable for every node I deploy."</span>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
