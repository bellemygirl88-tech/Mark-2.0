import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Printer, Copy, Check, Download, Briefcase, GraduationCap, 
  Layers, Phone, Mail, MapPin, Globe, FileText, Upload, Trash2
} from 'lucide-react';
import { ContactInfo, UserProfile } from '../types';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  contact: ContactInfo;
  customResumeUrl: string;
  setCustomResumeUrl: (url: string) => void;
}

export default function ResumeModal({
  isOpen,
  onClose,
  profile,
  contact,
  customResumeUrl,
  setCustomResumeUrl
}: ResumeModalProps) {
  const [copied, setCopied] = useState(false);
  const [showEmbedInfo, setShowEmbedInfo] = useState(false);

  if (!isOpen) return null;

  // Exact resume plain text for downloading or copying
  const resumeText = `REMARK ANTIPALA
AI Automation Specialist | AI Workflow Engineer | GoHighLevel | Zapier & N8n Expert

CONATCT INFORMATION:
Location: Philippines
Phone: ${contact.mobile || '09244640194'}
Email: ${contact.email || 'gojoswcollab@gmail.com'}
Linkedin: ${contact.linkedin || 'https://www.linkedin.com/in/remark-antipala-00b806355'}
Portfolio: remark-automates.lovable.app
Upwork: ${contact.upwork || 'https://www.upwork.com/freelancers/~0175a6cfbbf553978e'}

PROFESSIONAL SUMMARY:
Results-driven AI Automation Specialist with hands-on experience building scalable AI systems, workflow automations, and operational tools using n8n, Zapier, Make.com, GoHighLevel, OpenAI, Claude AI, and VAPI integrations.
Experienced in designing AI-powered workflows for customer support, appointment automation, CRM systems, document processing, reporting pipelines, and lead management. Strong understanding of how automation improves business efficiency, customer experience, and operational scalability.
Former Tier 2 Technical Support Advocate with over 4 years of experience supporting Microsoft Office and Windows operating system issues in a high-volume BPO environment. Skilled in troubleshooting technical problems, customer communication, process optimization, and delivering reliable solutions under pressure.
Comfortable working independently in fast-paced remote environments and passionate about delivering practical AI solutions with measurable business impact.

CORE COMPETENCIES:
• AI Workflow Automation
• n8n Workflow Development
• Zapier & Make.com Automations
• GoHighLevel CRM Automation
• OpenAI & Claude Integrations
• AI Voice Agents & Chatbots
• Retrieval-Augmented Generation (RAG)
• CRM & Sales Pipeline Automation
• Appointment Scheduling Systems
• Data Pipelines & API Integrations
• Airtable & Google Workspace Automation
• Dashboard & Reporting Automation
• Lead Generation & Follow-Up Systems
• SOP Documentation & Workflow Optimization
• Business Process Automation
• Technical Support & Troubleshooting
• Customer Support Operations

TECHNICAL SKILLS:
* Automation Platforms: n8n, Zapier, Make.com, GoHighLevel
* AI & APIs: OpenAI API, Claude AI, Google Gemini, AI Agents, Webhooks, REST APIs
* CRM & Productivity Tools: Airtable, Google Sheets, Google Calendar, Notion, PandaDoc, Slack, Trello
* Database & Vector Tools: Supabase Vector Store, Embeddings & Semantic Search, RAG Pipelines

PROFESSIONAL EXPERIENCE:

Freelance AI Automation Specialist
• Designed and implemented AI automation systems for agencies and service-based businesses
• Built scalable workflows using n8n, Zapier, Make.com, and GoHighLevel
• Developed AI-powered customer support systems, lead nurturing workflows, and appointment scheduling automations
• Integrated OpenAI, Claude, and Google Gemini AI models into operational workflows
• Automated CRM updates, onboarding systems, reporting dashboards, and business operations
• Created API integrations connecting Airtable, Google Workspace, PandaDoc, calendars, and communication systems
• Improved operational efficiency by reducing repetitive manual processes through automation
• Collaborated directly with founders and teams to identify inefficiencies and deploy scalable AI solutions

Tier 2 Technical Support Advocate — Microsoft Account
Concentrix | Over 4 years of experience
• Provided Tier 2 technical support for Microsoft Office products and Windows operating system issues
• Assisted customers with troubleshooting software installation, activation, login, update, and performance-related concerns
• Resolved complex technical cases involving Microsoft accounts, Office 365, Outlook, Windows OS, and system errors
• Delivered step-by-step technical guidance while maintaining high customer satisfaction in a fast-paced BPO environment
• Escalated critical cases when necessary and collaborated with internal teams for issue resolution
• Managed customer concerns through phone, chat, and remote troubleshooting support
• Developed strong communication, problem-solving, and technical diagnostic skills through high-volume support operations

FEATURED AUTOMATION PROJECTS:
1. AI Facebook Messenger Support Agent (Technologies: n8n, Facebook Messenger, AI Automation, Webhooks)
2. AI Receptionist + VAPI Appointment Automation (Technologies: n8n, VAPI, Airtable, Google Calendar, AI Voice Agents)
3. Retrieval-Augmented Generation (RAG) Pipeline (Technologies: n8n, Supabase, Google Gemini, Vector Embeddings, AI Search Systems)
4. AI Jobs Scraper + Resume Optimizer (Technologies: n8n, AI Automation, Data Processing)

EDUCATION:
AMA Computer Learning Center
Bachelor of Science in Business Administration (BSBA) – Management

ADDITIONAL INFORMATION:
• Strong understanding of agency operations, lead generation, and client workflows
• Comfortable working independently with minimal supervision
• Passionate about scalable AI systems and automation innovation
• Experienced in building practical automation solutions focused on real-world business outcomes
• Strong problem-solving and workflow architecture skills`;

  const handleCopy = () => {
    navigator.clipboard.writeText(resumeText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadTxt = () => {
    const element = document.createElement("a");
    const file = new Blob([resumeText], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `${profile.name.replace(/\s+/g, '_')}_Resume.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handlePrint = () => {
    // If a custom resume URL is set (e.g. google drive pdf link or direct uploaded pdf file)
    if (customResumeUrl) {
      window.open(customResumeUrl, '_blank');
      return;
    }

    // Trigger high-fidelity print window
    const printContent = document.getElementById('printable-resume-card');
    if (!printContent) return;

    const winPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
    if (winPrint) {
      winPrint.document.write(`
        <html>
          <head>
            <title>${profile.name} - Professional Resume</title>
            <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
            <style>
              body { font-family: 'Inter', system-ui, -apple-system, sans-serif; color: #1f2937; line-height: 1.5; padding: 40px; }
              @media print {
                body { padding: 0px; }
                .no-print { display: none; }
              }
              h1, h2, h3 { page-break-after: avoid; }
              .section { page-break-inside: avoid; margin-bottom: 24px; }
            </style>
          </head>
          <body>
            ${printContent.innerHTML}
            <script>
              window.onload = function() {
                window.print();
                window.close();
              }
            </script>
          </body>
        </html>
      `);
      winPrint.document.close();
      winPrint.focus();
    }
  };

  const handleResumeFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 3 * 1024 * 1024) {
        alert("Resume file limit is 3MB to conform to offline local storage guidelines.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setCustomResumeUrl(reader.result as string);
        alert("Custom Resume file embedded successfully! Clients can now download this exact file directly.");
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
      {/* Backdrop overlay */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.6 }}
        className="fixed inset-0 bg-black"
        onClick={onClose}
      />

      {/* Modal Card Content */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="relative bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl z-10"
      >
        
        {/* Top Control Header */}
        <div className="flex flex-wrap items-center justify-between p-4 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-950">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-brand-accent animate-pulse" />
            <span className="font-display font-semibold text-zinc-900 dark:text-zinc-50">Interactive CV & Resume Downloader</span>
            {customResumeUrl && (
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full font-mono font-medium">Custom Embedded File Active</span>
            )}
          </div>
          
          <div className="flex items-center gap-1.5 mt-2 sm:mt-0">
            {/* Copy Text Button */}
            <button
              onClick={handleCopy}
              className="p-2 border border-zinc-200 dark:border-zinc-800 rounded-lg bg-white dark:bg-zinc-900 hover:bg-zinc-50 dark:hover:bg-zinc-850 hover:text-zinc-950 dark:hover:text-zinc-50 text-zinc-500 text-xs flex items-center gap-1.5 transition shadow-sm cursor-pointer"
              title="Copy plain text to clipboard"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  <span className="font-medium text-[11px]">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span className="font-medium text-[11px]">Copy Text</span>
                </>
              )}
            </button>

            {/* Download Text File Button */}
            <button
              onClick={handleDownloadTxt}
              className="p-2 border border-zinc-200 dark:border-zinc-800 rounded-lg bg-white dark:bg-zinc-900 hover:bg-zinc-50 dark:hover:bg-zinc-855 text-zinc-500 hover:text-zinc-950 dark:hover:text-zinc-50 text-xs flex items-center gap-1.5 transition shadow-sm cursor-pointer"
              title="Download as Plain Text file"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="font-medium text-[11px]">Download plain .txt</span>
            </button>

            {/* Printer dynamic flow */}
            <button
              onClick={handlePrint}
              className="p-2 bg-zinc-900 dark:bg-zinc-100 hover:bg-zinc-850 dark:hover:bg-white text-white dark:text-zinc-950 rounded-lg text-xs flex items-center gap-1.5 transition shadow-md ml-1 font-semibold cursor-pointer"
              title="Print resume perfectly or Save as PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{customResumeUrl ? 'Download PDF Attachment' : 'Print / Save PDF'}</span>
            </button>

            {/* Exit Button */}
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition ml-2 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Dynamic Admin Embedding tools */}
        <div className="bg-zinc-100 dark:bg-zinc-850 p-3 px-4 border-b border-zinc-200 dark:border-zinc-800 text-xs flex flex-col md:flex-row md:items-center justify-between gap-2 text-zinc-650 dark:text-zinc-300">
          <p className="font-mono text-[10.5px]">
            ⚙️ <span className="font-bold opacity-80">Developer Embedding Console:</span> You can embed your custom resume PDF/docx file locally here!
          </p>
          <div className="flex gap-2 items-center">
            <label className="p-1 px-2.5 rounded bg-zinc-200 dark:bg-zinc-700 hover:bg-zinc-250 dark:hover:bg-zinc-600 transition text-[10px] font-bold cursor-pointer inline-flex items-center gap-1">
              <Upload className="w-3 h-3" />
              <span>{customResumeUrl ? 'Change Resume File' : 'Embed custom Resume'}</span>
              <input 
                type="file" 
                accept=".pdf,.doc,.docx,image/*" 
                onChange={handleResumeFileSelect} 
                className="hidden" 
              />
            </label>
            {customResumeUrl && (
              <button
                onClick={() => {
                  setCustomResumeUrl('');
                  alert('Restored default interactive dynamic resume.');
                }}
                className="p-1 px-2.5 rounded bg-red-500/10 hover:bg-red-500/20 text-red-500 dark:text-red-400 transition text-[10px] font-bold inline-flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>

        {/* Printable/Scrollable Viewer content container */}
        <div className="flex-1 overflow-y-auto p-6 md:p-10 select-text">
          
          {/* Printable Layout Wrapper */}
          <div 
            id="printable-resume-card"
            className="p-6 md:p-8 bg-white text-zinc-900 border border-zinc-100 rounded-xl shadow-xs max-w-3xl mx-auto dark:bg-white dark:text-zinc-900"
          >
            {/* CV Title Header */}
            <div className="flex flex-col md:flex-row md:justify-between items-start gap-4 border-b-2 border-zinc-800 pb-5">
              <div className="space-y-1">
                <h1 className="text-3xl font-display font-black tracking-tight text-zinc-900 uppercase">{profile.name}</h1>
                <p className="text-xs font-mono font-bold text-indigo-650 text-indigo-700 tracking-wide uppercase">
                  AI Automation Specialist & Workflow Architect
                </p>
              </div>

              {/* Direct Quick Info Links */}
              <div className="space-y-1.5 text-xs text-zinc-600 max-w-sm font-sans">
                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-zinc-700 shrink-0" />
                  <span>Philippines</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-zinc-700 shrink-0" />
                  <span>{contact.mobile || '09244640194'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-zinc-700 shrink-0" />
                  <span className="font-semibold">{contact.email || 'gojoswcollab@gmail.com'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Globe className="w-3.5 h-3.5 text-zinc-700 shrink-0" />
                  <span className="font-mono text-[11px]">remark-automates.lovable.app</span>
                </div>
              </div>
            </div>

            {/* Resume Summary */}
            <div className="section mt-6">
              <h2 className="text-sm font-mono font-bold text-zinc-900 uppercase border-b border-zinc-300 pb-1 mb-2 tracking-wider">Professional Summary</h2>
              <div className="text-xs text-zinc-700 leading-relaxed space-y-3.5 font-sans">
                <p>
                  Results-driven AI Automation Specialist with hands-on experience building scalable AI systems, 
                  workflow automations, and operational tools using <strong>n8n, Zapier, Make.com, GoHighLevel</strong>, 
                  OpenAI, Claude AI, and VAPI integrations.
                </p>
                <p>
                  Experienced in designing AI-powered workflows for customer support, appointment automation, 
                  CRM systems, document processing, reporting pipelines, and lead management. Strong 
                  understanding of how automation improves business efficiency, customer experience, and 
                  operational scalability.
                </p>
                <p>
                  Former Tier 2 Technical Support Advocate with over 4 years of experience supporting Microsoft 
                  Office and Windows operating system issues in a high-volume BPO environment. Skilled in 
                  troubleshooting technical problems, customer communication, process optimization, and 
                  delivering reliable solutions under pressure.
                </p>
              </div>
            </div>

            {/* Skills & Platforms Side by Side Grid */}
            <div className="section mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-sm font-mono font-bold text-zinc-900 uppercase border-b border-zinc-300 pb-1 mb-2 tracking-wider">Core Competencies</h3>
                <ul className="text-xs text-zinc-700 space-y-1 pl-4 list-disc font-sans">
                  <li>AI Workflow Automation</li>
                  <li>n8n Workflow Development</li>
                  <li>Zapier & Make.com Automations</li>
                  <li>GoHighLevel CRM Automation</li>
                  <li>OpenAI & Claude Integrations</li>
                  <li>AI Voice Agents & Chatbots</li>
                  <li>Retrieval-Augmented Generation (RAG)</li>
                  <li>CRM & Sales Pipeline Automation</li>
                  <li>Appointment Scheduling Systems</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-sm font-mono font-bold text-zinc-900 uppercase border-b border-zinc-300 pb-1 mb-2 tracking-wider">Technical Skills</h3>
                <div className="space-y-2.5 text-xs text-zinc-700 font-sans">
                  <div>
                    <span className="font-bold block text-zinc-800">Automation Platforms:</span>
                    <span className="text-zinc-600 block leading-tight">n8n, Zapier, Make.com, GoHighLevel</span>
                  </div>
                  <div>
                    <span className="font-bold block text-zinc-800">AI & APIs:</span>
                    <span className="text-zinc-600 block leading-tight">OpenAI API, Claude AI, Google Gemini, Webhooks, REST APIs</span>
                  </div>
                  <div>
                    <span className="font-bold block text-zinc-800">CRM & Productivity:</span>
                    <span className="text-zinc-600 block leading-tight">Airtable, Google Sheets, Google Calendar, Notion, PandaDoc, Slack, Trello</span>
                  </div>
                  <div>
                    <span className="font-bold block text-zinc-800">Database & Vector Tools:</span>
                    <span className="text-zinc-600 block leading-tight">Supabase Vector Store, Embeddings & Semantic Search, RAG Pipelines</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Experience timeline */}
            <div className="section mt-6">
              <h2 className="text-sm font-mono font-bold text-zinc-900 uppercase border-b border-zinc-300 pb-1 mb-3.5 tracking-wider">Professional Experience</h2>
              
              {/* Job 1 */}
              <div className="space-y-1 mb-4">
                <div className="flex justify-between items-start">
                  <h4 className="text-xs font-bold text-zinc-900">Freelance AI Automation Specialist</h4>
                  <span className="text-[10px] text-zinc-500 font-mono">Present</span>
                </div>
                <p className="text-[10px] text-brand-dark/70 font-sans italic">Delivering operations leverage and smart API connections</p>
                <ul className="text-xs text-zinc-700 pl-4 list-disc space-y-1 font-sans">
                  <li>Designed and implemented AI automation systems for agencies and service-based businesses.</li>
                  <li>Built scalable workflows using <strong>n8n, Zapier, Make.com, and GoHighLevel</strong>.</li>
                  <li>Developed AI-powered customer support systems, lead nurturing, and appointment scheduling systems.</li>
                  <li>Integrated OpenAI, Claude, and Google Gemini AI models into operational pipelines.</li>
                  <li>Automated CRM updates, onboarding systems, reporting dashboards, and general business processes.</li>
                  <li>Created API integrations connecting Airtable, Google Workspace, calendaring tools, and Slack communication channels.</li>
                  <li>Improved operational efficiency by reducing repetitive manual processes, saving clients averages of 30+ hours/month.</li>
                </ul>
              </div>

              {/* Job 2 */}
              <div className="space-y-1">
                <div className="flex justify-between items-start">
                  <h4 className="text-xs font-bold text-zinc-900">Tier 2 Technical Support Advocate — Microsoft Account</h4>
                  <span className="text-[10px] text-zinc-500 font-mono">Over 4 Years</span>
                </div>
                <p className="text-[10px] text-zinc-500 font-sans font-medium">Concentrix BPO Services</p>
                <ul className="text-xs text-zinc-700 pl-4 list-disc space-y-1 font-sans">
                  <li>Provided Tier 2 technical support for Microsoft Office products and Windows operating system issues.</li>
                  <li>Assisted clients with troubleshooting software installations, licensing, update schedules, and login issues.</li>
                  <li>Resolved complex technical cases involving enterprise Microsoft Accounts, Office 365 Exchange, and system error states.</li>
                  <li>Delivered step-by-step guidance while maintaining high customer satisfaction in a fast-paced environment.</li>
                </ul>
              </div>
            </div>

            {/* Experience timeline */}
            <div className="section mt-6">
              <h2 className="text-sm font-mono font-bold text-zinc-900 uppercase border-b border-zinc-300 pb-1 mb-2.5 tracking-wider">Education</h2>
              <div className="font-sans text-xs">
                <div className="flex justify-between items-start font-bold text-zinc-950">
                  <span>AMA Computer Learning Center</span>
                  <span className="text-[10px] font-normal text-zinc-500 font-mono">Philippines</span>
                </div>
                <p className="text-zinc-700 text-xs mt-0.5">Bachelor of Science in Business Administration (BSBA) – Management</p>
              </div>
            </div>

            {/* Additional Info Footer */}
            <div className="section mt-6 pb-2">
              <h2 className="text-sm font-mono font-bold text-zinc-900 uppercase border-b border-zinc-300 pb-1 mb-2.5 tracking-wider">Additional Information</h2>
              <ul className="text-xs text-zinc-700 pl-4 list-disc space-y-1 font-sans">
                <li>Comfortable working independently in fast-paced remote environments under high autonomy.</li>
                <li>Strong understanding of outbound lead generation, agency delivery, and multi-channel marketing workflows.</li>
                <li>Passionate about scalable AI systems and automation innovations.</li>
              </ul>
            </div>

          </div>

        </div>

      </motion.div>
    </div>
  );
}
