import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, Send, X, Bot, User, Loader2, Sparkles, AlertCircle, Calendar, MessageCircle, ExternalLink } from 'lucide-react';

interface Message {
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  isError?: boolean;
}

export default function AIChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem('portfolio-chat-history');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback to default
      }
    }
    return [
      {
        sender: 'bot',
        text: "Hi there! 👋 I'm Remark's virtual AI assistant. Ask me anything about his expertise in **N8N**, **Zapier**, **GoHighLevel**, **Voice AI (VAPI)**, or his featured case studies. \n\nHow can I help optimize your business today?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ];
  });
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Save history to local storage
  useEffect(() => {
    localStorage.setItem('portfolio-chat-history', JSON.stringify(messages));
  }, [messages]);

  // Scroll to bottom on new message
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isLoading]);

  const handleSend = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMessage: Message = {
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: textToSend,
          history: messages.slice(-10) // Send last 10 messages for context
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch response from the AI assistant.');
      }

      const botMessage: Message = {
        sender: 'bot',
        text: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (error: any) {
      console.error('AIChat error:', error);
      const errorMessage: Message = {
        sender: 'bot',
        text: `⚠️ **Session Notice:** ${error.message || 'We could not connect to the assistant right now. Please verify your connection or refresh the page.'}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: true
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    const initialMessage: Message = {
      sender: 'bot',
      text: "Hi there! 👋 I'm Remark's virtual AI assistant. Ask me anything about his expertise in **N8N**, **Zapier**, **GoHighLevel**, **Voice AI (VAPI)**, or his featured case studies. \n\nHow can I help optimize your business today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages([initialMessage]);
  };

  // Safe minimal HTML/Markdown parsing helper
  const renderMessageContent = (text: string) => {
    // Escape standard regex markers and replace bold text **txt**
    // Replace markdown links [title](url) to beautiful anchors with target="_blank"
    const parts = text.split(/(\*\*.*?\*\*|https:\/\/[\w.-]+(?:\/[\w./?%&=-]*)?|mailto:[\w.-]+@[\w.-]+)/g);

    return parts.map((part, index) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={index} className="font-semibold text-blue-900 dark:text-blue-200">{part.slice(2, -2)}</strong>;
      }
      if (part.startsWith('http://') || part.startsWith('https://')) {
        // Render Google Calendar link with a special icon CTA button if it matches Google Calendar
        const isCalendar = part.includes('calendar.google.com') || part.includes('google.com/calendar');
        const isWhatsapp = part.includes('wa.me') || part.includes('whatsapp.com');
        return (
          <a
            key={index}
            href={part}
            target="_blank"
            referrerPolicy="no-referrer"
            rel="noopener noreferrer"
            className={`inline-flex items-center gap-1 font-medium underline transition ${
              isCalendar 
                ? 'text-brand-accent hover:text-brand-accent/80' 
                : isWhatsapp 
                  ? 'text-emerald-500 hover:text-emerald-400' 
                  : 'text-indigo-600 dark:text-indigo-400 hover:opacity-80'
            }`}
          >
            {isCalendar ? '📅 View Calendar' : isWhatsapp ? '💬 Message WhatsApp' : 'Link'}
            <ExternalLink className="w-2.5 h-2.5 shrink-0" />
          </a>
        );
      }
      if (part.startsWith('mailto:')) {
        return (
          <a
            key={index}
            href={part}
            className="text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1 font-medium"
          >
            {part.slice(7)}
            <ExternalLink className="w-2.5 h-2.5 shrink-0" />
          </a>
        );
      }
      // Handle simple line break replacement
      return part.split('\n').map((subPart, subIdx, array) => (
        <React.Fragment key={`${index}-${subIdx}`}>
          {subPart}
          {subIdx < array.length - 1 && <br />}
        </React.Fragment>
      ));
    });
  };

  const suggestionChips = [
    { label: "🛠️ Key Skills & Tools", query: "What are Remark's key technical skills and automation tools?" },
    { label: "🚀 Facebook AI Agent", query: "Tell me about his Facebook Messenger AI Support Agent project." },
    { label: "📞 Book discovery call", query: "What's the best way to book an automation discovery call / meeting with him?" },
    { label: "💰 Cost & Rates", query: "What is his typical hourly rate or pricing model?" },
  ];

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end pointer-events-none">
      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="pointer-events-auto mb-4 w-[360px] max-w-[calc(100vw-2rem)] h-[520px] max-h-[80vh] flex flex-col rounded-2xl bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-850 shadow-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3.5 bg-zinc-900 text-white dark:bg-zinc-900 border-b border-zinc-805">
              <div className="flex items-center gap-2.5">
                <div className="relative">
                  <div className="w-9 h-9 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-brand-accent">
                    <Sparkles className="w-4.5 h-4.5" />
                  </div>
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border border-zinc-900 animate-pulse" />
                </div>
                <div className="text-left">
                  <h3 className="text-xs font-semibold text-zinc-100 flex items-center gap-1.5 font-sans leading-none">
                    Remark's AI Assistant
                  </h3>
                  <span className="text-[10px] font-mono text-zinc-400">Online • Live Support</span>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={clearChat}
                  className="p-1 px-1.5 text-[9px] font-mono uppercase tracking-wider text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition cursor-pointer"
                  title="Reset conversation"
                >
                  Clear history
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Message Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-zinc-50 dark:bg-zinc-900/40">
              {messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {/* Bot Logo / User Icon */}
                  {msg.sender === 'bot' && (
                    <div className="w-7.5 h-7.5 rounded-full bg-zinc-250 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300 shrink-0 text-xs">
                      <Bot className="w-4 h-4" />
                    </div>
                  )}

                  {/* Message Bubble */}
                  <div className="max-w-[80%] flex flex-col">
                    <div
                      className={`px-3.5 py-2.5 rounded-2xl text-[12.5px] leading-relaxed text-left shadow-xs ${
                        msg.sender === 'user'
                          ? 'bg-zinc-900 text-blue-200 rounded-tr-none'
                          : msg.isError
                            ? 'bg-red-50 dark:bg-red-950/20 text-red-600 dark:text-red-400 border border-red-200/55 dark:border-red-900/30 rounded-tl-none'
                            : 'bg-white dark:bg-zinc-850 text-blue-600 dark:text-blue-400 border border-zinc-200/40 dark:border-zinc-800/10 rounded-tl-none'
                      }`}
                    >
                      {renderMessageContent(msg.text)}
                    </div>
                    <span className={`text-[9px] text-zinc-400 dark:text-zinc-500 mt-1 ${msg.sender === 'user' ? 'text-right' : 'text-left'}`}>
                      {msg.timestamp}
                    </span>
                  </div>

                  {msg.sender === 'user' && (
                    <div className="w-7.5 h-7.5 rounded-full bg-zinc-900 text-white flex items-center justify-center shrink-0 text-xs font-semibold">
                      <User className="w-4.5 h-4.5" />
                    </div>
                  )}
                </div>
              ))}

              {isLoading && (
                <div className="flex gap-2.5 justify-start">
                  <div className="w-7.5 h-7.5 rounded-full bg-zinc-250 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300 shrink-0 text-xs animate-spin">
                    <Loader2 className="w-4 h-4" />
                  </div>
                  <div className="max-w-[80%] flex flex-col">
                    <div className="px-3.5 py-2.5 rounded-2xl rounded-tl-none text-[12.5px] bg-white dark:bg-zinc-850 text-blue-500 dark:text-blue-400 border border-zinc-200/40 dark:border-zinc-800/10 flex items-center gap-2">
                      <span>Analyzing credentials & draft queries</span>
                      <span className="flex gap-0.5">
                        <span className="w-1 h-1 bg-zinc-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                        <span className="w-1 h-1 bg-zinc-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                        <span className="w-1 h-1 bg-zinc-400 rounded-full animate-bounce" />
                      </span>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Suggestions (Horizontal Scroll) */}
            <div className="bg-white dark:bg-zinc-950 border-t border-zinc-100 dark:border-zinc-900 px-3 py-2 flex gap-1.5 overflow-x-auto scrollbar-none select-none shrink-0">
              {suggestionChips.map((chip, i) => (
                <button
                  key={i}
                  onClick={() => handleSend(chip.query)}
                  disabled={isLoading}
                  className="px-2.5 py-1.5 text-[11px] font-sans font-medium hover:font-semibold bg-zinc-100 dark:bg-zinc-850 hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 rounded-full border border-zinc-200/40 dark:border-zinc-800/20 whitespace-nowrap transition cursor-pointer disabled:opacity-50"
                >
                  {chip.label}
                </button>
              ))}
            </div>

            {/* Input Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend(input);
              }}
              className="p-3 border-t border-zinc-200/60 dark:border-zinc-850/30 bg-zinc-50 dark:bg-zinc-950 flex items-center gap-2 shrink-0"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="How experienced is Remark in N8N?"
                disabled={isLoading}
                className="flex-1 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 focus:border-zinc-650 text-[12.5px] rounded-xl px-3.5 py-2 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-zinc-400/40"
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="p-2 rounded-xl bg-zinc-900 text-white dark:bg-white dark:text-zinc-900 hover:opacity-90 disabled:opacity-40 transition cursor-pointer flex items-center justify-center shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="pointer-events-auto p-4 rounded-full shadow-2xl bg-zinc-900 hover:bg-black dark:bg-white dark:text-zinc-900 text-white flex items-center justify-center relative cursor-pointer group active:scale-95 transition-all duration-300 md:scale-100 hover:shadow-brand-accent/20 border border-zinc-200/5"
        id="ai-chatbot-toggle-button"
        title="Ask Remark's Assistant"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              <X className="w-6 h-6 text-white dark:text-zinc-900" />
            </motion.div>
          ) : (
            <motion.div
              key="chat"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="relative"
            >
              <MessageCircle className="w-6 h-6 text-white dark:text-zinc-900" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-brand-accent rounded-full animate-bounce" />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Floating suggestion hover popup (desktop only, shown when chat is closed) */}
        {!isOpen && (
          <div className="absolute right-16 top-1/2 -translate-y-1/2 bg-zinc-900/90 text-[10.5px] font-sans font-medium text-white px-3 py-1.5 rounded-lg border border-zinc-800 backdrop-blur-sm whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 translate-x-2 group-hover:translate-x-0 hidden sm:block shadow-md">
            ✉️ Quick automated portfolio chat
          </div>
        )}
      </button>
    </div>
  );
}
