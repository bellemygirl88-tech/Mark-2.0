import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mail, Calendar, MessageSquare, Linkedin, Briefcase, Phone, Send, CheckCircle2, AlertOctagon, Sparkles, Copy, Check, ArrowUpRight
} from 'lucide-react';
import { ContactInfo } from '../types';
import CalendlyEmbed from './CalendlyEmbed';

interface ContactProps {
  contact: ContactInfo;
}

export default function Contact({ contact }: ContactProps) {
  const [contactTab, setContactTab] = useState<'proposal' | 'calendar'>('proposal');
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [useCase, setUseCase] = useState('N8N AI Agent Integration');
  const [proposalBodyText, setProposalBodyText] = useState('');
  const [copiedProposal, setCopiedProposal] = useState(false);
  const [hoursSpent, setHoursSpent] = useState(15);
  const [message, setMessage] = useState('');

  const computedLaborSavings = hoursSpent * 25; // default rate of $25

  const handleCopyProposal = () => {
    if (!proposalBodyText) return;
    navigator.clipboard.writeText(proposalBodyText);
    setCopiedProposal(true);
    setTimeout(() => setCopiedProposal(false), 2500);
  };


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) {
      alert("Please provide your name and email address so I can get back to you!");
      return;
    }

    const compiledBody = `Hi Remark,

My name is ${name} (${email}).

I clicked through your portfolio website. I'm interested in implementing: ${useCase}.

Currently, we spend around ${hoursSpent} hours per month on these manual tasks (Estimated potential labor leakage: $${computedLaborSavings}/mo).

Additional details:
"${message}"

Let's organize a Discovery Call!`;

    setProposalBodyText(compiledBody);
    setFormSubmitted(true);

    // Formulate a beautiful mailto hyperlink containing metadata to facilitate easy human dispatch
    const subject = encodeURIComponent(`AI Automation Inquiry from ${name}`);
    const body = encodeURIComponent(compiledBody);
    
    // Smooth delay before launching email dispatcher
    setTimeout(() => {
      window.location.href = `mailto:${contact.email}?subject=${subject}&body=${body}`;
    }, 1500);
  };

  const socialButtons = [
    {
      id: "soc-email",
      label: "Direct Email Inbox",
      value: contact.email,
      href: `mailto:${contact.email}`,
      icon: <Mail className="w-5 h-5 text-brand-accent" />,
      desc: "Get an engineering proposal within 12 hours"
    },
    {
      id: "soc-linkedin",
      label: "Corporate LinkedIn",
      value: "Remark Antipala",
      href: contact.linkedin,
      icon: <Linkedin className="w-5 h-5 text-indigo-500" />,
      desc: "Connect for enterprise inquiries & networking"
    },
    {
      id: "soc-whatsapp",
      label: "Instant WhatsApp",
      value: "+639772727335",
      href: contact.whatsapp,
      icon: <MessageSquare className="w-5 h-5 text-emerald-500" />,
      desc: "Chat directly with me about workflows"
    },
    {
      id: "soc-upwork",
      label: "Upwork Client Portal",
      value: "Verified Freelancer",
      href: contact.upwork,
      icon: <Briefcase className="w-5 h-5 text-sky-500" />,
      desc: "Manage projects under escrow agreements"
    }
  ];

  return (
    <section 
      id="contact" 
      className="py-20 bg-white dark:bg-brand-dark transition-colors duration-300 relative"
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,79,0,0.02),transparent_40%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center space-y-3 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-full">
            <Mail className="w-3.5 h-3.5 text-brand-accent" />
            <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-600 dark:text-zinc-300 font-mono">Get in Touch</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight font-display text-zinc-900 dark:text-white">
            Ready to Automate Your Operations?
          </h2>
          <p className="text-xs sm:text-sm text-zinc-500">
            Let's discuss how intelligent software workflows can reduce cost, reclaim hours, and help your enterprise scale securely.
          </p>
        </div>

        {/* Contact Split layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start max-w-6xl mx-auto">
          
          {/* L: Info Cards and Direct links (5 columns) */}
          <div className="lg:col-span-5 space-y-6 text-left">
            <div className="space-y-2">
              <h3 className="text-xl sm:text-2xl font-bold font-display tracking-tight text-zinc-900 dark:text-white">
                Launch a conversation
              </h3>
              <p className="text-xs text-zinc-500 leading-relaxed">
                Click any direct gateway to get help. I manage my own inbox, schedule, and client relationships with zero intermediaries. You work directly with me.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4 pt-2">
              {socialButtons.map((soc) => (
                <a
                  key={soc.id}
                  href={soc.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-4 bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-200/50 dark:border-zinc-850 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-900 flex gap-4 transition duration-300 transform hover:translate-x-0.5"
                >
                  <div className="p-2.5 bg-white dark:bg-zinc-800 border border-zinc-200/40 dark:border-zinc-700/50 rounded-xl shrink-0 h-fit">
                    {soc.icon}
                  </div>
                  <div className="text-left space-y-1">
                    <span className="text-[10px] uppercase tracking-wider font-semibold text-zinc-400 font-mono block">
                      {soc.label}
                    </span>
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100 block">
                      {soc.value}
                    </span>
                    <p className="text-[10.5px] leading-relaxed text-zinc-500 dark:text-zinc-450">
                      {soc.desc}
                    </p>
                  </div>
                </a>
              ))}
            </div>

            {/* Direct Phone / Call info container */}
            <div className="p-4 bg-zinc-900/5 dark:bg-zinc-900/50 rounded-xl border border-zinc-150 dark:border-zinc-800 flex items-center justify-between text-left">
              <div className="space-y-1">
                <span className="text-[9px] uppercase tracking-wider font-mono text-zinc-400 block">Immediate Calling Connection</span>
                <span className="text-xs font-bold font-mono text-zinc-850 dark:text-zinc-100">{contact.mobile}</span>
              </div>
              <Phone className="w-4 h-4 text-zinc-400" />
            </div>
          </div>

          {/* R: Interactive Estimation Contact Form or Embedded Calendly (7 columns) */}
          <div className="lg:col-span-7 bg-zinc-50 dark:bg-zinc-900 p-4 sm:p-6 rounded-2xl border border-zinc-200/60 dark:border-zinc-850 text-left relative overflow-hidden flex flex-col">
            
            {/* Header Tabs */}
            <div className="flex border-b border-zinc-200 dark:border-zinc-800 pb-3 mb-5 gap-5 select-none shrink-0">
              <button
                type="button"
                onClick={() => setContactTab('proposal')}
                className={`pb-1.5 border-b-2 font-display font-bold text-xs sm:text-xs tracking-wider uppercase transition cursor-pointer select-none focus:outline-none ${
                  contactTab === 'proposal'
                    ? 'border-brand-accent text-zinc-900 dark:text-white'
                    : 'border-transparent text-zinc-400 hover:text-zinc-650 dark:hover:text-zinc-350'
                }`}
              >
                📊 Custom System Proposal
              </button>
              <button
                type="button"
                onClick={() => setContactTab('calendar')}
                className={`pb-1.5 border-b-2 font-display font-bold text-xs sm:text-xs tracking-wider uppercase transition cursor-pointer select-none flex items-center gap-1.5 focus:outline-none ${
                  contactTab === 'calendar'
                    ? 'border-brand-accent text-zinc-900 dark:text-white'
                    : 'border-transparent text-zinc-400 hover:text-zinc-650 dark:hover:text-zinc-350'
                }`}
              >
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-accent opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-brand-accent"></span>
                </span>
                📅 Instant calendar scheduling
              </button>
            </div>

            <AnimatePresence mode="wait">
              {contactTab === 'proposal' ? (
                !formSubmitted ? (
                  <motion.form 
                    key="contact-form"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    onSubmit={handleSubmit}
                    className="space-y-5 flex-1"
                  >
                    <div className="border-b border-zinc-200 dark:border-zinc-800 pb-3">
                      <h4 className="font-bold text-sm tracking-tight text-zinc-900 dark:text-zinc-100">
                        Formulate system request
                      </h4>
                      <p className="text-[11px] text-zinc-500 mt-1">
                        Fill out basic project parameters to estimate monthly labor cost leakage instantly!
                      </p>
                    </div>

                    {/* Name field */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-300">Your Full Name</label>
                        <input 
                          type="text" 
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="John Doe"
                          className="w-full px-3 py-2 text-xs bg-white dark:bg-zinc-850 border border-zinc-300 dark:border-zinc-700/60 rounded-xl focus:outline-none focus:ring-1 focus:ring-brand-accent text-zinc-900 dark:text-zinc-100"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-300">Contact Email</label>
                        <input 
                          type="email" 
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="john@organization.com"
                          className="w-full px-3 py-2 text-xs bg-white dark:bg-zinc-850 border border-zinc-300 dark:border-zinc-700/60 rounded-xl focus:outline-none focus:ring-1 focus:ring-brand-accent text-zinc-900 dark:text-zinc-100"
                        />
                      </div>
                    </div>

                    {/* Use Case selection */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-300">Target Core Requirement</label>
                      <select 
                        value={useCase}
                        onChange={(e) => setUseCase(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white dark:bg-zinc-850 border border-zinc-300 dark:border-zinc-700/60 rounded-xl focus:outline-none focus:ring-1 focus:ring-brand-accent text-zinc-900 dark:text-zinc-200"
                      >
                        <option value="N8N AI Agent Integration">N8N AI Agent/Messenger Integration</option>
                        <option value="Voice GHL Receptionist Bot">VAPI + Phone Voice Agent Bot</option>
                        <option value="Zapier Leads Enrichment System">Zapier Leadi Enrichment / Score Pipeline</option>
                        <option value="Multi-channel CRM GHL Funnel">GoHighLevel Inbound SMS Sequence Funnels</option>
                        <option value="General Consultation & System Audit">General Consultation / System Audit</option>
                      </select>
                    </div>

                    {/* Dynamic slider for hours spent manually */}
                    <div className="space-y-2 p-3 bg-white dark:bg-zinc-850 rounded-xl border border-zinc-200/50 dark:border-zinc-800">
                      <div className="flex justify-between text-xs">
                        <span className="font-semibold text-zinc-650 dark:text-zinc-300">Hours spent on these manual tasks monthly:</span>
                        <strong className="font-mono text-zinc-900 dark:text-zinc-50">{hoursSpent} hrs</strong>
                      </div>
                      <input 
                        type="range" 
                        min="5" 
                        max="160" 
                        value={hoursSpent}
                        onChange={(e) => setHoursSpent(Number(e.target.value))}
                        className="w-full h-1 bg-zinc-200 dark:bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-brand-accent focus:outline-none"
                      />
                      <div className="flex justify-between text-[9px] text-zinc-500 font-mono pt-1">
                        <span>5 hrs/mo</span>
                        <span className="text-emerald-500 font-bold">ESTIMATED LOSS: ${computedLaborSavings.toLocaleString()}/mo</span>
                        <span>160 hrs/mo</span>
                      </div>
                    </div>

                    {/* Message details */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-300">Brief Message / Tech Specifications</label>
                      <textarea 
                        rows={3}
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="Describe which databases or endpoints you need linked..."
                        className="w-full px-3 py-2 text-xs bg-white dark:bg-zinc-850 border border-zinc-300 dark:border-zinc-700/60 rounded-xl focus:outline-none focus:ring-1 focus:ring-brand-accent text-zinc-900 dark:text-zinc-100"
                      />
                    </div>

                    {/* Submit Button */}
                    <button
                      type="submit"
                      className="w-full px-5 py-3 rounded-xl bg-zinc-900 hover:bg-zinc-850 dark:bg-zinc-100 dark:hover:bg-zinc-200 text-white dark:text-zinc-950 font-bold text-xs tracking-tight transition flex items-center justify-center gap-2 shadow-md cursor-pointer"
                    >
                      <span>Submit Request Proposal</span>
                      <Send className="w-3.5 h-3.5" />
                    </button>

                    <p className="text-[10px] text-zinc-500 text-center leading-relaxed">
                      Clicking dispatch will automatically configure your local system email client with details formatted for instant dispatch.
                    </p>
                  </motion.form>
                ) : (
                  <motion.div 
                    key="success-form"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="py-6 flex flex-col items-center justify-center text-center space-y-4 flex-1"
                  >
                    <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-500">
                      <CheckCircle2 className="w-6 h-6 animate-pulse" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-bold text-sm text-zinc-900 dark:text-white">Connecting Local Email Client...</h4>
                      <p className="text-xs text-zinc-500 max-w-sm">
                        Your system email client has been triggered. Please review, finalize, and dispatch the generated blueprint script to <strong>{contact.email}</strong>!
                      </p>
                    </div>

                    {/* Copy to Clipboard Backup */}
                    <div className="w-full max-w-sm p-3 bg-zinc-100 dark:bg-zinc-850 border border-zinc-200 dark:border-zinc-800 rounded-xl space-y-2 mt-2">
                      <p className="text-[10px] text-zinc-500 leading-tight">
                        Email client didn't open automatically? No worries! Click below to copy the system request proposal directly to your clipboard:
                      </p>
                      <button
                        type="button"
                        onClick={handleCopyProposal}
                        className="w-full py-1.5 px-3 bg-white dark:bg-zinc-900 hover:bg-zinc-50 dark:hover:bg-zinc-800 border border-zinc-350 dark:border-zinc-700/60 rounded-lg text-xs font-semibold text-zinc-700 dark:text-zinc-200 flex items-center justify-center gap-1.5 transition cursor-pointer"
                      >
                        {copiedProposal ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-500" />
                            <span className="text-emerald-500">Proposal Script Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5 text-zinc-400" />
                            <span>Copy Proposal Script text</span>
                          </>
                        )}
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => setFormSubmitted(false)}
                      className="px-4 py-1.5 bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-xs font-semibold rounded-lg hover:bg-zinc-300 dark:hover:bg-zinc-700 transition cursor-pointer"
                    >
                      Back to Form
                    </button>
                  </motion.div>
                )
              ) : (
                <motion.div 
                  key="calendar-embed"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="flex flex-col flex-1 h-[420px] w-full"
                >
                  <p className="text-[11.5px] text-zinc-500 dark:text-zinc-400 mb-2 leading-relaxed text-left font-semibold">
                    📅 Interactive Scheduling Tool:
                  </p>
                  <div className="flex-1 w-full relative">
                    <CalendlyEmbed 
                      url={contact.calendly || "https://calendly.com/gojoswcollab/new-meeting"} 
                      height="370px" 
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}
