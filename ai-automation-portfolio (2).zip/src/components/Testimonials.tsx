import React from 'react';
import { motion } from 'motion/react';
import { Star, MessageSquareQuote, Quote } from 'lucide-react';
import { TESTIMONIALS } from '../data/portfolioData';

export default function Testimonials() {
  return (
    <section 
      id="testimonials" 
      className="py-20 bg-zinc-50 dark:bg-zinc-900/40 border-y border-zinc-200/50 dark:border-zinc-800/50 transition-colors duration-300 relative"
    >
      <div className="absolute inset-0 bg-[linear-gradient(to_bottom,transparent,#80808001_50%,transparent)]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center space-y-3 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-full">
            <MessageSquareQuote className="w-3.5 h-3.5 text-brand-accent" />
            <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-650 dark:text-zinc-350 font-mono">Client Endorsements</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight font-display text-zinc-900 dark:text-white">
            Future & Live Client Success Stories
          </h2>
          <p className="text-xs sm:text-sm text-zinc-500">
            Read comments from enterprise managers and business operators who streamlined their operations with our high-value systems.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto text-left">
          {TESTIMONIALS.map((t, idx) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: idx * 0.1 }}
              className="p-6 bg-white dark:bg-zinc-950 border border-zinc-200/50 dark:border-zinc-850 rounded-2xl shadow-sm hover:shadow-md transition duration-300 flex flex-col justify-between relative group"
            >
              {/* Absolutes Quote Mark */}
              <div className="absolute top-4 right-4 text-zinc-100 dark:text-zinc-900 group-hover:text-brand-accent/5 transition duration-300 pointer-events-none">
                <Quote className="w-12 h-12 fill-current stroke-none" />
              </div>

              {/* Stars representation */}
              <div className="space-y-4 relative z-10">
                <div className="flex gap-0.5 text-amber-500">
                  {Array.from({ length: t.rating }).map((_, sIdx) => (
                    <Star key={sIdx} className="w-3.5 h-3.5 fill-current" />
                  ))}
                </div>

                <p className="text-xs shrink-0 leading-relaxed italic text-zinc-600 dark:text-zinc-300">
                  "{t.text}"
                </p>
              </div>

              {/* Client bio row footer */}
              <div className="flex items-center gap-3 pt-6 border-t border-zinc-100 dark:border-zinc-850 mt-6 relative z-10 w-full">
                {/* Simulated colorful initials badge since avatar image holds standard default gradient path */}
                <div className="w-8 h-8 rounded-full bg-brand-accent/10 border border-brand-accent/20 flex items-center justify-center font-display font-bold text-xs text-brand-accent">
                  {t.name.split(' ').map(token => token[0]).join('')}
                </div>
                
                <div className="text-left leading-tight">
                  <span className="text-xs font-bold block text-zinc-900 dark:text-zinc-100">
                    {t.name}
                  </span>
                  <span className="text-[10px] text-zinc-400 font-medium">
                    {t.role} • <span className="text-zinc-500">{t.company}</span>
                  </span>
                </div>
              </div>

            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
