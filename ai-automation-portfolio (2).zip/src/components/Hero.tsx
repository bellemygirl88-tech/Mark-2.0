import React from 'react';
import { motion } from 'motion/react';
import { 
  ArrowRight, Calendar, Sparkles, FolderGit, Clock, Phone, Layers, ShieldCheck, FileText, Download
} from 'lucide-react';
import { UserProfile, ContactInfo } from '../types';

interface HeroProps {
  profile: UserProfile;
  contact: ContactInfo;
  onViewResume: () => void;
  onBookCall: () => void;
}

export default function Hero({ profile, contact, onViewResume, onBookCall }: HeroProps) {
  
  const handleDownloadPhoto = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    const url = profile.avatarUrl;
    const filename = `${profile.name.replace(/\s+/g, '_')}_headshot.jpg`;

    if (url.startsWith('data:')) {
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      return;
    }
    
    // Cross-origin safe fetch
    fetch(url, { referrerPolicy: 'no-referrer' })
      .then(response => response.blob())
      .then(blob => {
        const blobURL = window.URL.createObjectURL(blob);
        const tempLink = document.createElement('a');
        tempLink.style.display = 'none';
        tempLink.href = blobURL;
        tempLink.download = filename;
        document.body.appendChild(tempLink);
        tempLink.click();
        document.body.removeChild(tempLink);
        window.URL.revokeObjectURL(blobURL);
      })
      .catch(() => {
        window.open(url, '_blank');
      });
  };

  const handleScrollToProjects = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    const element = document.querySelector('#projects');
    if (element) {
      const topOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - topOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const metrics = [
    { 
      value: "20+", 
      label: "Workflows Built", 
      desc: "Robust customized flows", 
      icon: <FolderGit className="w-4 h-4 text-brand-accent" /> 
    },
    { 
      value: "100+", 
      label: "Hours Saved Monthly", 
      desc: "Instant labor leverage", 
      icon: <Clock className="w-4 h-4 text-emerald-500" /> 
    },
    { 
      value: "Active AI", 
      label: "Agents & Voice Systems", 
      desc: "VAPI + Gemini engines", 
      icon: <Sparkles className="w-4 h-4 text-indigo-500" /> 
    },
    { 
      value: "Enterprise CRM", 
      label: "Lead Automation Expert", 
      desc: "GoHighLevel & API Syncs", 
      icon: <Layers className="w-4 h-4 text-amber-500" /> 
    }
  ];

  return (
    <section 
      id="hero-root" 
      className="relative min-h-screen pt-24 pb-16 flex items-center overflow-hidden bg-white dark:bg-brand-dark transition-colors duration-300"
    >
      {/* Decorative Grid and Background Ornaments */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:14px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />
      
      {/* Radial soft color blur glows */}
      <div className="absolute top-24 left-1/4 w-[400px] h-[400px] bg-brand-accent/5 rounded-full filter blur-[100px] animate-pulse-glow pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-[350px] h-[350px] bg-violet-600/5 rounded-full filter blur-[100px] animate-pulse-glow pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* LEFT COLUMN: Headshot & Profile card */}
          <div className="lg:col-span-5 flex justify-center order-2 lg:order-1">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="relative group"
            >
              {/* Outer Glow Halo Ring */}
              <div className="absolute -inset-1.5 bg-gradient-to-r from-brand-accent via-indigo-500 to-amber-500 rounded-2xl opacity-10 blur group-hover:opacity-20 transition duration-1000 group-hover:duration-200" />
              
              {/* Active container card */}
              <div className="relative bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-4 rounded-2xl shadow-xl w-full max-w-[340px] text-center">
                <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 border border-zinc-200/50 dark:border-zinc-700/50 group/img">
                  <img 
                    src={profile.avatarUrl} 
                    alt={profile.name} 
                    className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  {/* Floating download photo hover button */}
                  <button
                    onClick={handleDownloadPhoto}
                    className="absolute top-2 right-2 p-1.5 rounded-lg bg-zinc-950/80 hover:bg-zinc-900 text-white backdrop-blur-md border border-zinc-700 text-[9.5px] font-mono transition-all opacity-0 group-hover/img:opacity-100 flex items-center gap-1 shadow-md select-none cursor-pointer"
                    title="Download headshot photo"
                  >
                    <Download className="w-3 h-3" />
                    <span>Download Photo</span>
                  </button>

                  <div className="absolute bottom-2 left-2 bg-zinc-900/80 backdrop-blur-md text-[10px] text-zinc-100 font-mono px-2 py-0.5 rounded flex items-center gap-1 border border-zinc-700">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
                    <span>AVAILABLE FOR INTEGRATIONS</span>
                  </div>
                </div>

                <div className="mt-4 text-left space-y-1">
                  <h3 className="font-bold text-lg leading-tight font-display text-zinc-900 dark:text-zinc-50">{profile.name}</h3>
                  <p className="text-xs text-zinc-500 font-mono flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-zinc-700 dark:text-zinc-300" />
                    <span>Verified Automation Partner</span>
                  </p>
                  
                  {/* Quick socials bar */}
                  <div className="flex flex-wrap gap-2 pt-3.5 mt-3 border-t border-zinc-100 dark:border-zinc-800">
                    <a 
                      href={contact.linkedin} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="p-1 px-1.5 rounded bg-zinc-50 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 transition text-[10px] text-zinc-600 dark:text-zinc-300 font-medium"
                    >
                      LinkedIn ✓
                    </a>
                    <a 
                      href={contact.facebook} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="p-1 px-1.5 rounded bg-zinc-50 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 transition text-[10px] text-zinc-600 dark:text-zinc-300 font-medium"
                    >
                      Facebook
                    </a>
                    <button 
                      onClick={handleDownloadPhoto}
                      className="p-1 px-1.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-450 dark:bg-amber-500/5 hover:bg-amber-500/20 dark:hover:bg-amber-500/10 border border-amber-500/20 dark:border-amber-500/10 transition text-[10px] font-bold font-mono tracking-tight flex items-center gap-1 cursor-pointer"
                    >
                      <Download className="w-3 h-3 shrink-0" />
                      <span>Download Photo</span>
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* RIGHT COLUMN: Headlines & CTAs */}
          <div className="lg:col-span-7 space-y-7 text-left order-1 lg:order-2">
            
            {/* Soft badge */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="inline-flex items-center gap-1.5 px-3 py-1 bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-full"
            >
              <Sparkles className="w-3.5 h-3.5 text-brand-accent" />
              <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-600 dark:text-zinc-300 font-mono">Operations Escalated</span>
            </motion.div>

            {/* Principal Heading */}
            <div className="space-y-4">
              <motion.h1
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="text-4xl sm:text-5xl lg:text-5xl font-bold tracking-tight font-display text-zinc-900 dark:text-white leading-[1.1]"
              >
                {profile.headline}
              </motion.h1>
              
              {/* Detailed Subheading */}
              <motion.p
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="text-sm sm:text-base leading-relaxed text-zinc-600 dark:text-zinc-400 max-w-xl"
              >
                {profile.subheadline}
              </motion.p>
            </div>

            {/* Click Call-to-Actions (CTAs) */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-3.5 pt-2"
            >
              <button
                onClick={handleScrollToProjects}
                className="px-6 py-3 rounded-xl bg-zinc-900 text-white dark:bg-white dark:text-zinc-950 inline-flex items-center justify-center gap-2 font-semibold text-xs tracking-tight hover:bg-zinc-800 dark:hover:bg-zinc-50 transition shadow-lg cursor-pointer shrink-0"
              >
                <span>View Portfolio Workflows</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onViewResume}
                className="px-6 py-3 rounded-xl bg-brand-accent text-white dark:bg-indigo-650 inline-flex items-center justify-center gap-2 font-semibold text-xs tracking-tight hover:bg-brand-accent/90 dark:hover:bg-indigo-700 transition shadow-lg cursor-pointer shrink-0"
                title="Open Dynamic Interactive Resume and Download Files"
              >
                <FileText className="w-4 h-4 text-white" />
                <span>View & Download CV</span>
              </button>
              
              <button
                onClick={onBookCall}
                className="px-6 py-3 rounded-xl bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-850 inline-flex items-center justify-center gap-2 font-semibold text-xs tracking-tight text-zinc-800 dark:text-zinc-200 transition border border-zinc-200/50 dark:border-zinc-800/50 shrink-0 cursor-pointer"
              >
                <Calendar className="w-4 h-4 text-brand-accent/85" />
                <span>Book a Discovery Call</span>
              </button>
            </motion.div>

            {/* Divided Grid Metrics container */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-8 border-t border-zinc-150 dark:border-zinc-850"
            >
              {metrics.map((m, idx) => (
                <div key={idx} className="space-y-1 text-left">
                  <div className="flex items-center gap-1.5">
                    {m.icon}
                    <span className="font-bold text-base sm:text-lg font-mono tracking-tight text-zinc-900 dark:text-zinc-100">{m.value}</span>
                  </div>
                  <h4 className="text-[11px] font-semibold text-zinc-800 dark:text-zinc-200 leading-tight">{m.label}</h4>
                  <p className="text-[9px] text-zinc-500 leading-none">{m.desc}</p>
                </div>
              ))}
            </motion.div>

          </div>

        </div>
      </div>
    </section>
  );
}
