import React, { useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Settings2, X, Save, Undo, Upload, 
  Linkedin, Facebook, MessageCircle, Mail, Phone, 
  Calendar, FileVideo, ShieldAlert, Check, DollarSign,
  Briefcase, FileText
} from 'lucide-react';
import { Project, ContactInfo, UserProfile } from '../types';

interface CustomizerDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  setProfile: (p: UserProfile) => void;
  contact: ContactInfo;
  setContact: (c: ContactInfo) => void;
  projects: Project[];
  setProjects: (p: Project[]) => void;
  hourlyRate: number;
  setHourlyRate: (r: number) => void;
  onReset: () => void;
  showWallpaper: boolean;
  setShowWallpaper: (b: boolean) => void;
  bgStreamPinned: boolean;
  setBgStreamPinned: (b: boolean) => void;
  wallpaperOpacity: number;
  setWallpaperOpacity: (n: number) => void;
  wallpaperType: 'video' | 'pinterest';
  setWallpaperType: (t: 'video' | 'pinterest') => void;
  wallpaperVideoUrl: string;
  setWallpaperVideoUrl: (u: string) => void;
  pinterestPinId: string;
  setPinterestPinId: (id: string) => void;
  customResumeUrl: string;
  setCustomResumeUrl: (url: string) => void;
}

export default function CustomizerDrawer({
  isOpen,
  onClose,
  profile,
  setProfile,
  contact,
  setContact,
  projects,
  setProjects,
  hourlyRate,
  setHourlyRate,
  onReset,
  showWallpaper,
  setShowWallpaper,
  bgStreamPinned,
  setBgStreamPinned,
  wallpaperOpacity,
  setWallpaperOpacity,
  wallpaperType,
  setWallpaperType,
  wallpaperVideoUrl,
  setWallpaperVideoUrl,
  pinterestPinId,
  setPinterestPinId,
  customResumeUrl,
  setCustomResumeUrl
}: CustomizerDrawerProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [successMsg, setSuccessMsg] = useState('');
  const [selectedProjectId, setSelectedProjectId] = useState<string>(projects[0]?.id || '');

  // Handle personal avatar upload
  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("Image size should be less than 2MB for storage limit guidelines");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfile({ ...profile, avatarUrl: reader.result as string });
        showSuccess("Profile photo updated successfully!");
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle individual project screenshot upload
  const handleScreenshotUpload = (projectId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("Image size should be less than 2MB for storage limit guidelines");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const updated = projects.map(p => 
          p.id === projectId ? { ...p, screenshotUrl: reader.result as string } : p
        );
        setProjects(updated);
        showSuccess(`Screenshot for project updated!`);
      };
      reader.readAsDataURL(file);
    }
  };

  // Update a single Loom URL
  const handleLoomUrlChange = (projectId: string, url: string) => {
    const updated = projects.map(p => 
      p.id === projectId ? { ...p, loomUrl: url } : p
    );
    setProjects(updated);
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => {
      setSuccessMsg('');
    }, 3000);
  };

  // Selected project for specific edit
  const activeProject = projects.find(p => p.id === selectedProjectId);

  return (
    <>
      {/* Drawer Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black z-50 pointer-events-auto"
            id="customizer-overlay"
          />
        )}
      </AnimatePresence>

      {/* Drawer Body */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="customizer-drawer"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 h-full w-full sm:w-[480px] bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 z-50 shadow-2xl flex flex-col border-l border-zinc-200 dark:border-zinc-800"
          >
            {/* Header */}
            <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between bg-zinc-50 dark:bg-zinc-900">
              <div className="flex items-center gap-2">
                <Settings2 className="w-5 h-5 text-brand-accent" />
                <h2 className="font-semibold text-lg font-display">Live Website Customizer</h2>
              </div>
              <button 
                onClick={onClose}
                className="p-1 rounded-md hover:bg-zinc-200 dark:hover:bg-zinc-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Area (Scrollable) */}
            <div className="flex-1 overflow-y-auto p-5 space-y-6">
              {successMsg && (
                <div className="p-3 text-xs bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-lg flex items-center gap-2">
                  <Check className="w-4 h-4 shrink-0" />
                  <span>{successMsg}</span>
                </div>
              )}

              {/* Developer Note */}
              <div className="p-3.5 bg-brand-accent/5 rounded-xl border border-brand-accent/10 space-y-2">
                <div className="flex items-center gap-2 text-brand-accent font-medium text-xs">
                  <ShieldAlert className="w-4 h-4" />
                  <span>MEMBER TEMPLATE TOOLS</span>
                </div>
                <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
                  Customize the developer profile, uploaded credentials, screenshot values, or video clips instantly. All information remains local in your browser storage.
                </p>
              </div>

              {/* 1. Global Financial Parameters */}
              <div className="space-y-3">
                <h3 className="font-semibold text-xs uppercase tracking-wider text-zinc-500">Calculator & Background Parameters</h3>
                
                <div className="p-3.5 bg-zinc-50 dark:bg-zinc-900/50 rounded-xl space-y-4 border border-zinc-200/50 dark:border-zinc-800/50">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-200">Global Hourly Labor Rate (USD/hr)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-zinc-400 text-sm font-mono">$</span>
                      <input 
                        type="number"
                        value={hourlyRate}
                        onChange={(e) => setHourlyRate(Math.max(1, Number(e.target.value)))}
                        className="w-full pl-7 pr-3 py-1.5 text-xs bg-white dark:bg-zinc-850 border border-zinc-200 dark:border-zinc-850 rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-accent font-mono"
                      />
                    </div>
                  </div>

                  <div className="border-t border-zinc-200/60 dark:border-zinc-800/60 my-2 pt-3 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-zinc-700 dark:text-zinc-200">Show Ambient Background Wallpaper</span>
                      <input 
                        type="checkbox"
                        checked={showWallpaper}
                        onChange={(e) => setShowWallpaper(e.target.checked)}
                        className="w-4 h-4 rounded text-brand-accent border-zinc-300 focus:ring-brand-accent cursor-pointer"
                      />
                    </div>

                    {showWallpaper && (
                      <div className="space-y-4 pt-1 border-t border-zinc-200/40 dark:border-zinc-800/40 mt-2">
                        {/* Wallpaper Type Switcher */}
                        <div className="space-y-1.5">
                          <span className="block text-[10.5px] font-bold text-zinc-500 dark:text-zinc-400">Backdrop Media Engine</span>
                          <div className="grid grid-cols-2 gap-1.5 p-1 bg-zinc-100 dark:bg-zinc-800 rounded-lg">
                            <button
                              type="button"
                              onClick={() => setWallpaperType('video')}
                              className={`py-1 text-[10px] font-medium rounded-md transition ${
                                wallpaperType === 'video'
                                  ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-sm'
                                  : 'text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'
                              }`}
                            >
                              🎬 HD Video Loop
                            </button>
                            <button
                              type="button"
                              onClick={() => setWallpaperType('pinterest')}
                              className={`py-1 text-[10px] font-medium rounded-md transition ${
                                wallpaperType === 'pinterest'
                                  ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-sm'
                                  : 'text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'
                              }`}
                            >
                              📌 Pinterest Embed
                            </button>
                          </div>
                        </div>

                        {/* Content customization depending on Type */}
                        {wallpaperType === 'video' ? (
                          <div className="space-y-2">
                            <span className="block text-[10.5px] font-bold text-zinc-500 dark:text-zinc-400">Preset High-Fidelity Video Loops</span>
                            <div className="flex flex-wrap gap-1.5">
                              <button
                                type="button"
                                onClick={() => setWallpaperVideoUrl('https://cdn.pixabay.com/video/2021/08/21/85732-591461947_large.mp4')}
                                className={`px-2 py-1 text-[9.5px] rounded transition font-medium ${
                                  wallpaperVideoUrl === 'https://cdn.pixabay.com/video/2021/08/21/85732-591461947_large.mp4'
                                    ? 'bg-brand-accent/20 text-brand-accent border border-brand-accent/30'
                                    : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-650 dark:text-zinc-300 border border-transparent'
                                }`}
                              >
                                ⚡ Amber Tech server room (New default)
                              </button>
                              <button
                                type="button"
                                onClick={() => setWallpaperVideoUrl('https://assets.mixkit.co/videos/preview/mixkit-cyberpunk-neon-tunnel-31952-large.mp4')}
                                className={`px-2 py-1 text-[9.5px] rounded transition font-medium ${
                                  wallpaperVideoUrl === 'https://assets.mixkit.co/videos/preview/mixkit-cyberpunk-neon-tunnel-31952-large.mp4'
                                    ? 'bg-brand-accent/20 text-brand-accent border border-brand-accent/30'
                                    : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-650 dark:text-zinc-300 border border-transparent'
                                }`}
                              >
                                🌌 Cyber Matrix grid corridor
                              </button>
                            </div>

                            <div className="space-y-1 mt-1">
                              <label className="text-[9.5px] text-zinc-500 font-mono">Custom MP4 Looping Video URL:</label>
                              <input 
                                type="text"
                                value={wallpaperVideoUrl}
                                onChange={(e) => setWallpaperVideoUrl(e.target.value)}
                                placeholder="https://example.com/loop.mp4"
                                className="w-full px-2 py-1 text-[10px] bg-white dark:bg-zinc-850 border border-zinc-200 dark:border-zinc-800 rounded font-mono text-zinc-700 dark:text-zinc-200"
                              />
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <span className="block text-[10.5px] font-bold text-zinc-500 dark:text-zinc-400">Preset Pinterest Stream</span>
                            <div className="flex flex-wrap gap-1.5">
                              <button
                                type="button"
                                onClick={() => setPinterestPinId('1037516832923726528')}
                                className={`px-2 py-1 text-[9.5px] rounded transition font-medium ${
                                  pinterestPinId === '1037516832923726528'
                                    ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-550/20'
                                    : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-650 dark:text-zinc-300'
                                }`}
                              >
                                💼 Brand Stream (1037516832923726528)
                              </button>
                              <button
                                type="button"
                                onClick={() => setPinterestPinId('342062534216906522')}
                                className={`px-2 py-1 text-[9.5px] rounded transition font-medium ${
                                  pinterestPinId === '342062534216906522'
                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-550/20'
                                    : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-650 dark:text-zinc-300'
                                }`}
                              >
                                📌 Pinterest Inspiration (342062534216906522)
                              </button>
                            </div>

                            <div className="space-y-1 mt-1">
                              <label className="text-[9.5px] text-zinc-500 font-mono">Pinterest Video Pin ID:</label>
                              <input 
                                type="text"
                                value={pinterestPinId}
                                onChange={(e) => setPinterestPinId(e.target.value.trim())}
                                placeholder="1037516832923726528"
                                className="w-full px-2 py-1 text-[10px] bg-white dark:bg-zinc-850 border border-zinc-200 dark:border-zinc-800 rounded font-mono text-zinc-700 dark:text-zinc-200"
                              />
                            </div>
                          </div>
                        )}

                        <div className="space-y-3 pt-2 border-t border-zinc-200/40 dark:border-zinc-800/40">
                          <div className="flex items-center justify-between">
                            <span className="text-[10.5px] text-zinc-500">Backdrop Opacity: {Math.round(wallpaperOpacity * 100)}%</span>
                            <input 
                              type="range" 
                              min="0.05" 
                              max="0.80" 
                              step="0.05"
                              value={wallpaperOpacity}
                              onChange={(e) => setWallpaperOpacity(Number(e.target.value))}
                              className="w-28 h-1 bg-zinc-250 dark:bg-zinc-805 rounded-lg accent-brand-accent cursor-pointer"
                            />
                          </div>

                          <div className="flex items-center justify-between">
                            <span className="text-[10.5px] text-zinc-555 dark:text-zinc-400">Wallpaper Pin Mode</span>
                            <button
                              type="button"
                              onClick={() => setBgStreamPinned(!bgStreamPinned)}
                              className={`px-2 py-1 text-[9.5px] font-mono rounded font-bold cursor-pointer transition ${
                                bgStreamPinned 
                                  ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-550/20' 
                                  : 'bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300'
                              }`}
                            >
                              {bgStreamPinned ? '📌 Under Backdrop' : '📱 Floated TV'}
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* 2. Personal Photo Upload */}
              <div className="space-y-3">
                <h3 className="font-semibold text-xs uppercase tracking-wider text-zinc-500">Headshot & Primary Info</h3>
                <div className="p-4 bg-zinc-50 dark:bg-zinc-900/50 rounded-xl space-y-4 border border-zinc-200/50 dark:border-zinc-800/50">
                  <div className="flex items-center gap-4">
                    <img 
                      src={profile.avatarUrl} 
                      alt="Avatar Preview" 
                      className="w-14 h-14 rounded-full object-cover border-2 border-brand-accent"
                    />
                    <div className="flex-1 space-y-2">
                      <p className="text-xs font-medium">Professional Headshot</p>
                      <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleAvatarUpload} 
                        accept="image/*"
                        className="hidden"
                      />
                      <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="px-3 py-1.5 bg-brand-accent text-white rounded-lg text-xs font-semibold hover:bg-brand-accent/90 transition flex items-center gap-2"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload Photo File</span>
                      </button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs text-zinc-500 mb-1">Headline Name</label>
                      <input 
                        type="text" 
                        value={profile.name}
                        onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                        className="w-full px-3 py-2 text-sm bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-accent"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-zinc-500 mb-1">Intro Title</label>
                      <input 
                        type="text" 
                        value={profile.headline}
                        onChange={(e) => setProfile({ ...profile, headline: e.target.value })}
                        className="w-full px-3 py-2 text-sm bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-accent"
                      />
                    </div>

                    <div className="pt-3 border-t border-zinc-200 dark:border-zinc-800">
                      <label className="block text-xs font-semibold text-zinc-650 dark:text-zinc-350 mb-1.5 flex items-center gap-1">
                        <FileText className="w-3.5 h-3.5 text-zinc-400" />
                        <span>Resume Document Link / Attachment</span>
                      </label>
                      <div className="p-2.5 bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-lg space-y-2">
                        {customResumeUrl ? (
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-mono text-emerald-500 font-bold flex items-center gap-1 select-none">
                              <span className="inline-block w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                              ✓ Custom CV PDF Embedded
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                setCustomResumeUrl('');
                                showSuccess('Embedded resume removed. Standard Dynamic interactive CV is now active.');
                              }}
                              className="text-[10px] text-red-500 hover:underline font-mono focus:outline-none cursor-pointer"
                            >
                              Remove
                            </button>
                          </div>
                        ) : (
                          <p className="text-[10px] text-zinc-500 leading-tight">Currently using the built-in, dynamic high-fidelity interactive CV viewer.</p>
                        )}
                        
                        <div className="flex gap-2">
                          <label className="w-full flex items-center justify-center gap-1 px-3 py-1.5 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-750 dark:hover:bg-zinc-700 rounded transition text-[10px] font-bold cursor-pointer text-zinc-700 dark:text-zinc-200">
                            <Upload className="w-3.5 h-3.5 text-zinc-455" />
                            <span>{customResumeUrl ? 'Replace Resume PDF' : 'Upload Resume File'}</span>
                            <input 
                              type="file" 
                              accept=".pdf,.doc,.docx,image/*" 
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  if (file.size > 2 * 1024 * 1024) {
                                    alert("Oops! The browser file size limit for localStorage storage is 2MB. Please compress your PDF file or use a smaller resume file.");
                                    return;
                                  }
                                  const reader = new FileReader();
                                  reader.onloadend = () => {
                                    setCustomResumeUrl(reader.result as string);
                                    showSuccess("Custom resume file successfully uploaded & embedded!");
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }} 
                              className="hidden" 
                            />
                          </label>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>

              {/* 3. Socials & Contact Connections */}
              <div className="space-y-3">
                <h3 className="font-semibold text-xs uppercase tracking-wider text-zinc-500">Contact Details & Social Profiles</h3>
                <div className="p-4 bg-zinc-50 dark:bg-zinc-900/50 rounded-xl space-y-3 border border-zinc-200/50 dark:border-zinc-800/50">
                  <div>
                    <label className="text-xs text-zinc-500 mb-1 flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5" /> Email
                    </label>
                    <input 
                      type="text" 
                      value={contact.email}
                      onChange={(e) => setContact({ ...contact, email: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-zinc-500 mb-1 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5" /> WhatsApp Link
                    </label>
                    <input 
                      type="text" 
                      value={contact.whatsapp}
                      onChange={(e) => setContact({ ...contact, whatsapp: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-zinc-500 mb-1 flex items-center gap-1.5">
                      <Linkedin className="w-3.5 h-3.5" /> LinkedIn URL
                    </label>
                    <input 
                      type="text" 
                      value={contact.linkedin}
                      onChange={(e) => setContact({ ...contact, linkedin: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-zinc-500 mb-1 flex items-center gap-1.5">
                      <Facebook className="w-3.5 h-3.5" /> Facebook Link
                    </label>
                    <input 
                      type="text" 
                      value={contact.facebook}
                      onChange={(e) => setContact({ ...contact, facebook: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-zinc-500 mb-1 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5" /> Phone Number
                    </label>
                    <input 
                      type="text" 
                      value={contact.mobile}
                      onChange={(e) => setContact({ ...contact, mobile: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-zinc-500 mb-1 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5" /> Calendly Call Booking URL
                    </label>
                    <input 
                      type="text" 
                      value={contact.calendly}
                      onChange={(e) => setContact({ ...contact, calendly: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-zinc-500 mb-1 flex items-center gap-1.5">
                      <Briefcase className="w-3.5 h-3.5" /> Upwork Profile URL
                    </label>
                    <input 
                      type="text" 
                      value={contact.upwork}
                      onChange={(e) => setContact({ ...contact, upwork: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* 4. Projects Screen uploads & Loom Videos */}
              <div className="space-y-3">
                <h3 className="font-semibold text-xs uppercase tracking-wider text-zinc-500">Project Videos & Screenshots</h3>
                <div className="p-4 bg-zinc-50 dark:bg-zinc-900/50 rounded-xl space-y-4 border border-zinc-200/50 dark:border-zinc-800/50">
                  <div>
                    <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">Select Project</label>
                    <select 
                      value={selectedProjectId}
                      onChange={(e) => setSelectedProjectId(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg focus:outline-none"
                    >
                      {projects.map(p => (
                        <option key={p.id} value={p.id}>{p.title}</option>
                      ))}
                    </select>
                  </div>

                  {activeProject && (
                    <div className="space-y-4 pt-2 border-t border-zinc-200 dark:border-zinc-800">
                      <div>
                        <label className="text-xs text-zinc-500 mb-1 flex items-center gap-1.5">
                          <FileVideo className="w-3.5 h-3.5" /> Loom Embed URL (or share link)
                        </label>
                        <input 
                          type="text" 
                          value={activeProject.loomUrl}
                          onChange={(e) => handleLoomUrlChange(activeProject.id, e.target.value)}
                          placeholder="e.g. https://www.loom.com/embed/..."
                          className="w-full px-2 py-1.5 text-xs bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg focus:outline-none font-mono"
                        />
                      </div>

                      <div>
                        <label className="text-xs text-zinc-500 mb-1 flex items-center gap-1.5">
                          <Upload className="w-3.5 h-3.5" /> Upload Workflow Screenshot
                        </label>
                        <div className="flex items-center gap-3">
                          {activeProject.screenshotUrl ? (
                            <img 
                              src={activeProject.screenshotUrl} 
                              alt="Proj Scrn" 
                              className="w-12 h-12 object-cover rounded border border-zinc-300"
                            />
                          ) : (
                            <div className="w-12 h-12 bg-zinc-200 dark:bg-zinc-800 rounded flex items-center justify-center text-zinc-400 text-[9px] text-center">
                              No Scan
                            </div>
                          )}
                          <div className="flex-1">
                            <input 
                              type="file" 
                              id={`file-p-${activeProject.id}`}
                              onChange={(e) => handleScreenshotUpload(activeProject.id, e)}
                              accept="image/*"
                              className="hidden"
                            />
                            <button 
                              onClick={() => document.getElementById(`file-p-${activeProject.id}`)?.click()}
                              className="px-2.5 py-1.5 bg-zinc-200 dark:bg-zinc-800 rounded text-xs font-medium hover:bg-zinc-300 dark:hover:bg-zinc-700 transition"
                            >
                              Browse Image File
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Footer containing save/dismiss feedback and Reset button */}
            <div className="p-4 bg-zinc-50 dark:bg-zinc-900 border-t border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-3 shrink-0">
              <button 
                onClick={onReset}
                className="px-3 py-2 bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 rounded-lg text-xs font-semibold hover:bg-zinc-300 dark:hover:bg-zinc-700 transition flex items-center gap-1"
              >
                <Undo className="w-3.5 h-3.5" />
                <span>Reset Defaults</span>
              </button>
              <button 
                onClick={onClose}
                className="px-4 py-2 bg-brand-accent text-white rounded-lg text-xs font-semibold hover:bg-brand-accent/90 transition flex items-center gap-1"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save & Finish</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
