import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Infinity, Zap, Layers, Sparkles, Database, PhoneCall, Calendar, Slack, 
  MessageSquareText, Grid, CheckCircle2, ArrowUpRight, Search, Cpu, 
  Workflow, DollarSign, FileText, HardDrive, ShieldCheck, Mail, Briefcase, Bot, Settings
} from 'lucide-react';

interface TechItem {
  name: string;
  desc: string;
  level: 'Expert' | 'Advanced' | 'Standard';
  icon: any;
  category: string;
}

export default function TechStack() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('All');

  // Categorized high-fidelity Tech Stack dataset
  const techCategories = [
    { id: 'all', name: 'All' },
    { id: 'automation', name: 'Workflow Automation' },
    { id: 'crm', name: 'CRM & Sales Systems' },
    { id: 'pm', name: 'Project Management' },
    { id: 'finance', name: 'Accounting & Finance' },
    { id: 'db', name: 'Databases & Data' },
    { id: 'forms', name: 'Forms & Lead Capture' },
    { id: 'schedule', name: 'Scheduling & Audio' },
    { id: 'ai', name: 'AI & LLMs' },
    { id: 'marketing', name: 'Marketing Automation' },
    { id: 'api', name: 'Integrations & APIs' },
    { id: 'cloud', name: 'Cloud & Storage' }
  ];

  const techItems: TechItem[] = useMemo(() => [
    // Workflow Automation
    {
      name: "n8n",
      desc: "Advanced workflow automation, complex API integrations, stateful AI orchestration, and custom business processes.",
      level: "Expert",
      icon: Infinity,
      category: "Workflow Automation"
    },
    {
      name: "Zapier",
      desc: "No-code enterprise automation, secure cloud-to-cloud integrations, lead routing, and instant task automation.",
      level: "Expert",
      icon: Zap,
      category: "Workflow Automation"
    },
    {
      name: "GoHighLevel (GHL)",
      desc: "Comprehensive CRM automation, sales pipelines, lead nurturing, appointment booking, and multi-channel email/SMS campaigns.",
      level: "Expert",
      icon: Layers,
      category: "Workflow Automation"
    },

    // CRM & Sales Systems
    {
      name: "GoHighLevel CRM",
      desc: "Robust contact lifecycle monitoring, trigger automations, sales deal tagging, and operational funnels setup.",
      level: "Expert",
      icon: Layers,
      category: "CRM & Sales Systems"
    },
    {
      name: "HubSpot",
      desc: "Automated inbound enterprise CRM tracking, precise customer pipeline updates, and deal synchronization setups.",
      level: "Expert",
      icon: Grid,
      category: "CRM & Sales Systems"
    },
    {
      name: "Salesforce",
      desc: "Basic contact record updates, standard CRM integrations, and secure API data mapping workflows.",
      level: "Standard",
      icon: Briefcase,
      category: "CRM & Sales Systems"
    },
    {
      name: "Pipedrive",
      desc: "Agile sales progression pipelines, direct task reminders, automated contact registers, and visual deals movement.",
      level: "Expert",
      icon: Workflow,
      category: "CRM & Sales Systems"
    },

    // Project Management
    {
      name: "Asana",
      desc: "Automated task creation, visual project progress tracking, custom status triggers, and visual team workflows.",
      level: "Expert",
      icon: Workflow,
      category: "Project Management"
    },
    {
      name: "Trello",
      desc: "Status boards custom automation, visual cards moving triggers, and instant lists update callbacks.",
      level: "Expert",
      icon: ColumnsIcon, // will define or fallback below
      category: "Project Management"
    },
    {
      name: "ClickUp",
      desc: "Custom workspace integration grids, task updates, status transformations, and checklists templates automation.",
      level: "Expert",
      icon: CheckCircle2,
      category: "Project Management"
    },
    {
      name: "Monday.com",
      desc: "Custom board trigger notifications, structured dashboards updates, and workflow boards synchronization.",
      level: "Expert",
      icon: Grid,
      category: "Project Management"
    },

    // Accounting & Finance
    {
      name: "Xero",
      desc: "Invoice issuance automation, multi-currency payment workflows, and financial analytics data synchronization.",
      level: "Expert",
      icon: DollarSign,
      category: "Accounting & Finance"
    },
    {
      name: "QuickBooks",
      desc: "Standard transaction updates, digital invoicing sync, custom receipts logs, and billing ledger triggers.",
      level: "Standard",
      icon: DollarSign,
      category: "Accounting & Finance"
    },

    // Databases & Data Management
    {
      name: "Airtable",
      desc: "Dynamic relational databases, customized CRM tables, automated triggers dashboards, and script extensions.",
      level: "Expert",
      icon: Database,
      category: "Databases & Data Management"
    },
    {
      name: "Google Sheets",
      desc: "Spreadsheets instant row calculations, sheets database updates, and cloud trigger gateways.",
      level: "Expert",
      icon: FileText,
      category: "Databases & Data Management"
    },
    {
      name: "Notion",
      desc: "Structured team workspace pages, interactive knowledge wikis, and database tables synchronization.",
      level: "Expert",
      icon: FileText,
      category: "Databases & Data Management"
    },
    {
      name: "Gmail / GSuite",
      desc: "Automating customized transactional emails, structured draft assemblies, and advanced receipt triggers.",
      level: "Expert",
      icon: Mail,
      category: "Databases & Data Management"
    },
    {
      name: "Slack",
      desc: "Interactive status channels, instant team alerts feeds, custom workflow pings, and rich modal integrations.",
      level: "Expert",
      icon: Slack,
      category: "Databases & Data Management"
    },

    // Forms & Lead Capture
    {
      name: "Typeform",
      desc: "Conversational question routing structures, custom response webhook pipelines, and data enrichment mapping.",
      level: "Expert",
      icon: FileText,
      category: "Forms & Lead Capture"
    },
    {
      name: "Jotform",
      desc: "Complex document collections, custom PDF receipt creations, encryption security, and database triggers.",
      level: "Expert",
      icon: FileText,
      category: "Forms & Lead Capture"
    },
    {
      name: "Google Forms",
      desc: "Simple data capture sync, instant sheets tables recording, and notifications email reminders.",
      level: "Expert",
      icon: FileText,
      category: "Forms & Lead Capture"
    },
    {
      name: "youform",
      desc: "Highly flexible, low-latency form layouts, customer questionnaires, and Webhook callback variables.",
      level: "Expert",
      icon: FileText,
      category: "Forms & Lead Capture"
    },
    {
      name: "HighLevel Forms",
      desc: "CRM contact validation matching, instant triggers setup, and responsive modal embeds formatting.",
      level: "Expert",
      icon: Layers,
      category: "Forms & Lead Capture"
    },

    // Scheduling & Calendar Systems
    {
      name: "Calendly",
      desc: "Automated booking notifications webhooks, slots check scheduling, and payment gateways routing.",
      level: "Expert",
      icon: Calendar,
      category: "Scheduling & Calendar Systems"
    },
    {
      name: "Google Calendar",
      desc: "Dynamic booking allocations, double-booking prevention, meeting links insertions, and confirmation logs.",
      level: "Expert",
      icon: Calendar,
      category: "Scheduling & Calendar Systems"
    },
    {
      name: "eleven labs",
      desc: "Advanced vocal speech model clones, sub-second sound generation APIs, and realistic text-to-speech outputs.",
      level: "Advanced",
      icon: PhoneCall,
      category: "Scheduling & Calendar Systems"
    },

    // AI & Large Language Models
    {
      name: "OpenAI",
      desc: "Logical text formatting instructions, structured system JSON responses, embeddings matching, and text transcripts.",
      level: "Expert",
      icon: Bot,
      category: "AI & Large Language Models"
    },
    {
      name: "Google Gemini",
      desc: "Deep technical semantics reading, multi-modal context summaries, vector calculations, and fast content generations.",
      level: "Expert",
      icon: Sparkles,
      category: "AI & Large Language Models"
    },
    {
      name: "Claude AI",
      desc: "Advanced logic reasoning steps, documents analysis, customized prompts mapping, and precise context formatting.",
      level: "Expert",
      icon: Cpu,
      category: "AI & Large Language Models"
    },

    // Marketing Automation
    {
      name: "nedzo AI",
      desc: "Specialized lead amplification nodes, responsive AI sales agents, and automated outreach logs enrichment.",
      level: "Advanced",
      icon: Sparkles,
      category: "Marketing Automation"
    },
    {
      name: "ConvertKit",
      desc: "Custom email newsletter schedules, contact tag allocations, interest-based trigger funnels, and landing pages.",
      level: "Expert",
      icon: Mail,
      category: "Marketing Automation"
    },

    // Integrations & APIs
    {
      name: "REST APIs",
      desc: "Custom HTTP endpoint parameters routing, token authorization management, and deep nesting objects handling.",
      level: "Expert",
      icon: Settings,
      category: "Integrations & APIs"
    },
    {
      name: "Webhooks",
      desc: "Custom callback listeners assembly, request header authentications, and payload parsing formatting.",
      level: "Expert",
      icon: Settings,
      category: "Integrations & APIs"
    },
    {
      name: "OAuth Authentication",
      desc: "Setting up secure user oauth tokens, automatic cron-based token refreshes, and API gateways authorization.",
      level: "Expert",
      icon: ShieldCheck,
      category: "Integrations & APIs"
    },
    {
      name: "JSON Data Processing",
      desc: "Custom arrays schema mappings, conditional keys filtering, and deep data structures transformation scripts.",
      level: "Expert",
      icon: Cpu,
      category: "Integrations & APIs"
    },
    {
      name: "API Data Mapping",
      desc: "Bi-directional database fields mapping instructions, multi-application structures matching, and sync logs.",
      level: "Expert",
      icon: Workflow,
      category: "Integrations & APIs"
    },

    // Cloud & Storage
    {
      name: "Google Drive",
      desc: "Real-time folder tree monitors, automated downloads, metadata renaming parameters, and file sorting nodes.",
      level: "Expert",
      icon: HardDrive,
      category: "Cloud & Storage"
    },
    {
      name: "OneDrive",
      desc: "Structured Microsoft cloud sync blocks, business backup logs, and team document folders updates.",
      level: "Expert",
      icon: HardDrive,
      category: "Cloud & Storage"
    },
    {
      name: "Dropbox",
      desc: "Automated shared folders links, assets catalog upload tracking, and metadata databases synchronizations.",
      level: "Expert",
      icon: HardDrive,
      category: "Cloud & Storage"
    }
  ], []);

  // Filter items based on active category and search queries
  const filteredTechItems = useMemo(() => {
    return techItems.filter(item => {
      const matchesCategory = activeCategory === 'All' || item.category === activeCategory;
      const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            item.desc.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            item.category.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, searchQuery, techItems]);

  const coreExpertises = [
    "n8n Workflow Development",
    "Zapier Automation Systems",
    "GoHighLevel CRM Automation",
    "Airtable Database Design",
    "Asana Workflow Automation",
    "Xero Accounting Integrations",
    "AI-Powered Business Automation",
    "Lead Management & Sales Pipeline Automation",
    "Appointment Booking & Calendar Automation",
    "Custom API Integrations"
  ];

  return (
    <section 
      id="tech-stack" 
      className="py-24 bg-white dark:bg-brand-dark transition-colors duration-300 relative border-t border-zinc-100 dark:border-zinc-900"
    >
      {/* Background radial highlight */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full pointer-events-none bg-[radial-gradient(ellipse_at_top,transparent_60%,#00000001_100%)]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* SECTION HEADER */}
        <div className="max-w-3xl mx-auto text-center space-y-3 mb-20">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-full">
            <Layers className="w-3.5 h-3.5 text-brand-accent" />
            <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-600 dark:text-zinc-300 font-mono">Expert Stack & Core Mastery</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight font-display text-zinc-900 dark:text-white">
            Supported Business Integrations
          </h2>
          <p className="text-xs sm:text-sm text-zinc-550 dark:text-zinc-400">
            Highly qualified expertise across leading customer relationship, artificial intelligence, and API gateway protocols. 
          </p>
        </div>

        {/* 1. PORTFOLIO CORE EXPERTISE HEADER & GRID */}
        <div className="mb-20">
          <div className="p-8 sm:p-10 rounded-3xl bg-zinc-50 dark:bg-zinc-950/40 border border-zinc-200/60 dark:border-zinc-850 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-brand-accent/5 rounded-full filter blur-[80px] pointer-events-none" />
            
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 border-b border-zinc-200/50 dark:border-zinc-900 pb-6">
              <div className="text-left space-y-1">
                <h3 className="text-lg sm:text-xl font-bold font-display text-zinc-950 dark:text-white flex items-center gap-2">
                  <ShieldCheck className="w-5.5 h-5.5 text-brand-accent" />
                  Portfolio Core Expertise
                </h3>
                <p className="text-xs text-zinc-500">
                  Targeted business optimizations aligned with master-level workflow implementation.
                </p>
              </div>
              <div className="flex items-center gap-1.5 self-start md:self-auto bg-brand-accent/5 border border-brand-accent/15 px-3 py-1 rounded-full text-[10px] uppercase font-mono font-bold text-brand-accent">
                <Sparkles className="w-3 h-3 animate-pulse" />
                100% Fully Functional Deployments
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-y-4 gap-x-6">
              {coreExpertises.map((exp, index) => (
                <div 
                  key={index} 
                  className="flex items-center gap-3 p-3 bg-white dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-850/65 rounded-xl hover:shadow-md hover:translate-y-[-1px] transition-all duration-200 group text-left"
                >
                  <div className="w-7 h-7 rounded-lg bg-emerald-500/10 dark:bg-emerald-500/5 border border-emerald-500/20 flex items-center justify-center text-emerald-500 shrink-0 group-hover:scale-110 transition-transform">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-semibold text-zinc-800 dark:text-zinc-200 tracking-tight leading-snug">
                    {exp}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 2. SEARCH & FILTER DIRECTORY */}
        <div className="space-y-6">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-zinc-150 dark:border-zinc-910 pb-5">
            <h3 className="text-lg sm:text-xl font-bold font-display text-zinc-950 dark:text-white text-left flex items-center gap-2">
              <Workflow className="w-5 h-5 text-indigo-500" />
              Technology Portfolio Directory
            </h3>
            
            {/* Search Input bar */}
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400 pointer-events-none" />
              <input
                type="text"
                placeholder="Search tools (e.g. n8n, Airtable, Xero)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-zinc-50 dark:bg-zinc-90 w-full rounded-xl border border-zinc-200 dark:border-zinc-800 py-2.5 pl-9 pr-4 text-xs dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-brand-accent/50 focus:border-brand-accent"
              />
            </div>
          </div>

          {/* Horizontal Category Selector Scrollbar */}
          <div className="flex gap-1.5 overflow-x-auto pb-4 scrollbar-thin scrollbar-track-transparent scrollbar-thumb-zinc-200 dark:scrollbar-thumb-zinc-800 select-none">
            {techCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.name)}
                className={`px-4 py-2 text-xs font-sans font-medium rounded-full cursor-pointer transition whitespace-nowrap border shrink-0 ${
                  activeCategory === cat.name
                    ? 'bg-zinc-950 text-white dark:bg-white dark:text-zinc-950 border-zinc-950 dark:border-white font-bold'
                    : 'bg-zinc-50 dark:bg-zinc-900 border-zinc-200/50 dark:border-zinc-850 text-zinc-650 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          {/* Grid dynamic renderer block */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 pt-2">
            <AnimatePresence mode="popLayout">
              {filteredTechItems.map((tech) => {
                const IconComponent = tech.icon;
                return (
                  <motion.div
                    layout
                    initial={{ opacity: 0, scale: 0.97 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.2 }}
                    key={tech.name}
                    className="p-4 bg-zinc-50/70 dark:bg-zinc-950/20 rounded-2xl border border-zinc-200/60 dark:border-zinc-850 hover:bg-zinc-100/30 dark:hover:bg-zinc-900/30 hover:shadow-md transition-all duration-300 flex flex-col justify-between group text-left"
                  >
                    <div className="space-y-3.5">
                      <div className="flex items-center justify-between">
                        <div className="p-2 w-9 h-9 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-sm flex items-center justify-center text-zinc-700 dark:text-zinc-300 group-hover:scale-105 transition-all">
                          <IconComponent className="w-4.5 h-4.5 text-zinc-900 dark:text-zinc-200" />
                        </div>
                        <span className={`text-[9px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                          tech.level === 'Expert' 
                            ? 'bg-brand-accent/5 text-brand-accent border border-brand-accent/10' 
                            : tech.level === 'Advanced'
                              ? 'bg-indigo-500/5 text-indigo-400 border border-indigo-500/10'
                              : 'bg-zinc-150 dark:bg-zinc-800 text-zinc-500'
                        }`}>
                          {tech.level}
                        </span>
                      </div>

                      <div className="space-y-1">
                        <h4 className="font-bold text-xs uppercase tracking-wide text-zinc-500 dark:text-zinc-400 font-mono">
                          {tech.category}
                        </h4>
                        <h3 className="font-bold text-sm text-zinc-900 dark:text-zinc-50 font-display">
                          {tech.name}
                        </h3>
                        <p className="text-[11px] leading-relaxed text-zinc-550 dark:text-zinc-400">
                          {tech.desc}
                        </p>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-zinc-150 dark:border-zinc-850 mt-4 flex items-center justify-between opacity-50 group-hover:opacity-100 transition duration-200">
                      <span className="text-[9px] font-mono text-zinc-450 dark:text-zinc-500">Service Deployment Ready</span>
                      <ArrowUpRight className="w-3 h-3 text-brand-accent group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>

            {/* Empty view state indicator */}
            {filteredTechItems.length === 0 && (
              <div className="col-span-full py-12 text-center space-y-3 bg-zinc-50/50 dark:bg-zinc-900/10 rounded-2xl border border-dashed border-zinc-200 dark:border-zinc-800">
                <Search className="w-8 h-8 text-zinc-400 mx-auto animate-pulse" />
                <div className="space-y-1">
                  <p className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">No integration tools found</p>
                  <p className="text-xs text-zinc-400 max-w-xs mx-auto">Try typing another query or clear search terms to see full integration list.</p>
                </div>
                <button 
                  onClick={() => { setSearchQuery(''); setActiveCategory('All'); }}
                  className="px-3.5 py-1.5 text-xs font-semibold bg-zinc-900 text-white dark:bg-white dark:text-zinc-900 rounded-lg hover:opacity-90 active:scale-95 transition"
                >
                  Reset filters
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Outer custom CTA info foot */}
        <p className="text-[11.5px] text-zinc-455 dark:text-zinc-400 mt-10 leading-relaxed italic text-center max-w-2xl mx-auto">
          🔧 Need custom scripting or advanced API synchronization protocols? I design bespoke Node.js / Python servers, custom vector indexing services, and bi-directional CRMs integration routines matching specific commercial environments.
        </p>

      </div>
    </section>
  );
}

// Fallback column board visual icon generator
function ColumnsIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <path d="M12 3v18" />
    </svg>
  );
}
